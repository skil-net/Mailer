/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_VK_SERVICE_TOKEN?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
