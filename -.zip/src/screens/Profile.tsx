import { memo, useCallback, useMemo, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowDownToLine, ArrowUpFromLine, ChevronRight, Download, Loader2, LogOut, RefreshCw, Shield, Ticket, WifiOff, type LucideIcon } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { Avatar } from "@/components/Avatar";
import { EmptyState } from "@/components/EmptyState";
import { NumberTicker } from "@/components/NumberTicker";
import { PAGE_CLASS, ScreenHeader } from "@/components/ScreenHeader";
import { TransactionRow } from "@/components/TransactionRow";
import { VirtualList } from "@/components/VirtualList";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { exportStorageJson } from "@/store/storage";
import { Wallet } from "lucide-react";
import type { Transaction } from "@/types";

interface RowProps {
  icon: LucideIcon;
  label: string;
  hint?: ReactNode;
  danger?: boolean;
  onClick: () => void;
}

const SettingRow = memo(function SettingRow({ icon: Icon, label, hint, danger, onClick }: RowProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex h-14 w-full min-w-0 items-center gap-3 border-b border-line px-4 text-left transition-colors duration-150 last:border-b-0 active:bg-sand"
    >
      <Icon size={22} strokeWidth={1.5} className={`shrink-0 ${danger ? "text-bad" : "text-gold-dark"}`} />
      <span className={`min-w-0 flex-1 truncate text-[15px] font-semibold ${danger ? "text-bad" : ""}`}>{label}</span>
      {hint && <span className="shrink-0 text-[12px] text-mute">{hint}</span>}
      <ChevronRight size={18} strokeWidth={1.5} className="shrink-0 text-mute" />
    </button>
  );
});

const getKey = (t: Transaction) => t.id;
const renderTx = (t: Transaction) => <TransactionRow tx={t} />;

function Profile() {
  const navigate = useNavigate();
  const auth = useAuthStore((s) => s.auth);
  const loading = useAuthStore((s) => s.loading);
  const refreshProfile = useAuthStore((s) => s.refreshProfile);
  const logout = useAuthStore((s) => s.logout);
  const balance = useDataStore((s) => s.balance);
  const transactions = useDataStore(useShallow((s) => s.transactions));
  const openSheet = useUiStore((s) => s.openSheet);
  const toast = useUiStore((s) => s.toast);

  const profile = auth.profile;
  const fullName = profile ? `${profile.firstName} ${profile.lastName}` : "";
  const history = useMemo(() => transactions.filter((t) => t.status !== "expired" || t.type !== "deposit"), [transactions]);

  const deposit = useCallback(() => openSheet({ type: "deposit" }), [openSheet]);
  const withdraw = useCallback(() => openSheet({ type: "withdraw" }), [openSheet]);
  const promo = useCallback(() => openSheet({ type: "promo" }), [openSheet]);
  const admin = useCallback(() => navigate("/admin"), [navigate]);
  const refresh = useCallback(() => void refreshProfile(), [refreshProfile]);

  const exportJson = useCallback(() => {
    const blob = new Blob([exportStorageJson()], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `rassylka-export-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    toast("Данные экспортированы", "success");
  }, [toast]);

  return (
    <>
      <ScreenHeader>
        <h1 className="truncate font-display text-[26px] font-semibold">Профиль</h1>
      </ScreenHeader>

      <div className={PAGE_CLASS}>
        <section className="card p-5">
          <div className="flex min-w-0 items-center gap-4">
            <Avatar src={profile?.photo200} name={fullName} monogram={profile?.monogram} size={72} />
            <div className="min-w-0 flex-1">
              <h2 className="truncate font-display text-[24px] font-semibold leading-tight">{fullName}</h2>
              <div className="truncate text-[14px] text-mute">@{profile?.screenName ?? "samadluk"}</div>
              <div className="mt-1.5 flex min-w-0 items-center gap-2">
                {auth.role === "admin" && <span className="badge bg-gold/20 text-gold-dark">Администратор</span>}
                <span className="truncate text-[11px] text-mute tabular-nums">ID {auth.vkId}</span>
              </div>
            </div>
          </div>

          {auth.profileSource === "local" && (
            <div className="mt-4 flex items-center gap-3 rounded-2xl bg-sand px-3 py-2.5">
              <WifiOff size={18} strokeWidth={1.5} className="shrink-0 text-mute" />
              <span className="min-w-0 flex-1 truncate text-[13px] font-semibold text-mute">Профиль загружен локально</span>
              <button type="button" className="btn btn-outline btn-sm shrink-0 !h-9" onClick={refresh} disabled={loading}>
                {loading ? <Loader2 size={16} strokeWidth={1.5} className="animate-spin" /> : <RefreshCw size={16} strokeWidth={1.5} />}
                Обновить
              </button>
            </div>
          )}
        </section>

        <section className="card mt-4 bg-gradient-to-br from-ink to-[#4a3f36] p-5 text-white">
          <div className="flex items-center gap-2 text-[13px] font-semibold text-white/70">
            <Wallet size={18} strokeWidth={1.5} /> Баланс
          </div>
          <div className="mt-1 truncate font-display text-[40px] font-bold leading-tight">
            <NumberTicker value={balance} suffix={"\u00A0₽"} />
          </div>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <button type="button" className="btn btn-primary" onClick={deposit}>
              <ArrowDownToLine size={18} strokeWidth={1.5} /> Пополнить
            </button>
            <button type="button" className="btn bg-white/10 text-white" onClick={withdraw}>
              <ArrowUpFromLine size={18} strokeWidth={1.5} /> Вывести
            </button>
          </div>
        </section>

        <section className="mt-6">
          <h3 className="section-title mb-2 px-1">История операций</h3>
          {history.length === 0 ? (
            <div className="card">
              <EmptyState icon={Wallet} title="Операций пока нет" text="Пополнения, выплаты и списания за рассылки появятся здесь." />
            </div>
          ) : (
            <div className="card">
              <VirtualList items={history} renderItem={renderTx} getKey={getKey} estimateSize={64} gap={0} />
            </div>
          )}
        </section>

        <section className="mt-6">
          <h3 className="section-title mb-2 px-1">Настройки</h3>
          <div className="card">
            {auth.role === "admin" && <SettingRow icon={Shield} label="Админка" hint="Заявки и экономика" onClick={admin} />}
            <SettingRow icon={Ticket} label="Промокод" hint="Активировать" onClick={promo} />
            <SettingRow icon={Download} label="Экспорт данных (JSON)" onClick={exportJson} />
            <SettingRow icon={LogOut} label="Выйти" danger onClick={logout} />
          </div>
        </section>
      </div>
    </>
  );
}

export default memo(Profile);
