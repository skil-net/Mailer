import { useCallback, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Send, Users, Wallet, type LucideIcon } from "lucide-react";
import { useAuthStore } from "@/store/useAuthStore";

interface Slide {
  icon: LucideIcon;
  title: string;
  text: string;
}

const SLIDES: Slide[] = [
  { icon: Send, title: "Рассылки в пару касаний", text: "Создавайте сообщения с персонализацией, вложениями и кнопками — и отправляйте сразу в несколько сообществ." },
  { icon: Users, title: "База из ваших диалогов", text: "Подключите сообщество по ключу доступа — мы соберём подписчиков, которые писали вам, с учётом пола и согласия." },
  { icon: Wallet, title: "Партнёры и баланс", text: "Пополняйте баланс, размещайтесь у партнёров и зарабатывайте на своих сообществах." },
];

const EASE: [number, number, number, number] = [0.32, 0.72, 0, 1];

export default function Onboarding() {
  const complete = useAuthStore((s) => s.completeOnboarding);
  const [i, setI] = useState(0);
  const [dir, setDir] = useState(1);
  const last = i === SLIDES.length - 1;

  const go = useCallback(
    (d: number) => {
      setDir(d);
      setI((p) => Math.min(SLIDES.length - 1, Math.max(0, p + d)));
    },
    []
  );
  const next = () => (last ? complete() : go(1));
  const Icon = SLIDES[i].icon;

  return (
    <div className="fixed inset-0 flex flex-col overflow-hidden" style={{ height: "100dvh" }}>
      <div className="flex shrink-0 justify-end px-5" style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 16px)" }}>
        <button type="button" className="h-10 px-3 text-[14px] font-semibold text-mute transition-transform active:scale-[0.97]" onClick={complete}>
          Пропустить
        </button>
      </div>

      <div className="relative mx-auto flex w-full min-h-0 max-w-[480px] flex-1 items-center overflow-hidden px-6">
        <AnimatePresence mode="wait" custom={dir}>
          <motion.div
            key={i}
            className="flex w-full cursor-grab flex-col items-center text-center active:cursor-grabbing"
            initial={{ opacity: 0, x: 48 * dir }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -48 * dir }}
            transition={{ duration: 0.2, ease: EASE }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.25}
            onDragEnd={(_, info) => {
              if (info.offset.x < -60 || info.velocity.x < -400) go(1);
              else if (info.offset.x > 60 || info.velocity.x > 400) go(-1);
            }}
          >
            <div className="mb-10 flex size-36 items-center justify-center rounded-[44px] bg-gradient-to-br from-gold to-gold-dark text-white shadow-[0_24px_48px_-20px_rgba(184,147,74,0.8)]">
              <Icon size={64} strokeWidth={1.5} />
            </div>
            <h1 className="max-w-full text-balance font-display text-[32px] font-semibold leading-tight">{SLIDES[i].title}</h1>
            <p className="mt-4 max-w-[360px] text-balance text-[16px] leading-relaxed text-mute">{SLIDES[i].text}</p>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="mx-auto w-full max-w-[480px] shrink-0 px-6" style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 24px)" }}>
        <div className="mb-6 flex justify-center gap-2" aria-hidden>
          {SLIDES.map((_, idx) => (
            <span key={idx} className={`h-2 rounded-full transition-[width,background-color] duration-300 ${idx === i ? "w-6 bg-gold" : "w-2 bg-line"}`} />
          ))}
        </div>
        <button type="button" className="btn btn-primary w-full" onClick={next}>
          {last ? "Начать" : "Далее"}
        </button>
      </div>
    </div>
  );
}
