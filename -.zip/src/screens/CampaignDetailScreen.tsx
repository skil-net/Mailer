import { memo, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, FileX } from "lucide-react";
import { CampaignDetail } from "@/components/CampaignDetail";
import { StatusBadge } from "@/components/CampaignCard";
import { EmptyState } from "@/components/EmptyState";
import { goBack } from "@/components/nav";
import { ScreenHeader } from "@/components/ScreenHeader";
import { useDataStore } from "@/store/useDataStore";
import { pluralGroups } from "@/lib/format";
import type { Campaign } from "@/types";

function CampaignDetailScreen({ id }: { id: string }) {
  const navigate = useNavigate();
  const campaign = useDataStore((s) => s.campaigns.find((c) => c.id === id));
  // сохраняем последнюю версию, чтобы экран не «мигал» пустым при удалении во время выхода
  const last = useRef<Campaign | undefined>(undefined);
  if (campaign) last.current = campaign;
  const c = campaign ?? last.current;

  const back = useCallback(() => goBack(navigate), [navigate]);
  const onGone = useCallback(() => undefined, []);

  return (
    <>
      <ScreenHeader>
        <div className="flex items-center gap-3">
          <button type="button" className="icon-btn" onClick={back} aria-label="Назад">
            <ArrowLeft size={20} strokeWidth={1.5} />
          </button>
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-[20px] font-semibold leading-tight">{c?.title ?? "Рассылка"}</h1>
            {c && c.groupIds.length > 1 && <div className="truncate text-[12px] font-semibold text-gold-dark">{pluralGroups(c.groupIds.length)}</div>}
          </div>
          {c && <StatusBadge status={c.status} />}
        </div>
      </ScreenHeader>

      <div className="mx-auto w-full max-w-[720px] px-4 pt-4 tab:px-6">
        {c ? (
          <CampaignDetail key={c.id} campaign={c} onGone={onGone} />
        ) : (
          <EmptyState
            icon={FileX}
            title="Рассылка не найдена"
            text="Возможно, она была удалена."
            action={
              <button type="button" className="btn btn-soft" onClick={back}>
                Назад
              </button>
            }
          />
        )}
      </div>
    </>
  );
}

export default memo(CampaignDetailScreen);
