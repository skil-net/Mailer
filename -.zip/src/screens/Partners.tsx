import { memo, useCallback, useMemo, useState } from "react";
import { Handshake, Plus, Store } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { ChipBar } from "@/components/ChipBar";
import { EmptyState } from "@/components/EmptyState";
import { PartnerCard } from "@/components/PartnerCard";
import { PAGE_CLASS, ScreenHeader } from "@/components/ScreenHeader";
import { VirtualList } from "@/components/VirtualList";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { TOPIC_FILTER_OPTIONS, type TopicFilter } from "@/lib/topics";
import { partnerNetPrice } from "@/lib/pricing";
import type { Group } from "@/types";

type Tab = "all" | "mine";
type Sort = "popular" | "price_asc" | "price_desc" | "discount" | "topic";

const TABS: ReadonlyArray<{ value: Tab; label: string }> = [
  { value: "all", label: "Все партнёры" },
  { value: "mine", label: "Мои партнёрские группы" },
];
const SORTS: ReadonlyArray<{ value: Sort; label: string }> = [
  { value: "popular", label: "По популярности" },
  { value: "price_asc", label: "По цене ↑" },
  { value: "price_desc", label: "По цене ↓" },
  { value: "discount", label: "По скидке" },
  { value: "topic", label: "По тематике" },
];

interface Entry {
  group: Group;
  pending: boolean;
}
const getKey = (e: Entry) => e.group.id;

function Partners() {
  const groups = useDataStore(useShallow((s) => s.groups));
  const requests = useDataStore(useShallow((s) => s.partnerRequests));
  const commission = useDataStore((s) => s.settings.serviceCommissionPercent);
  const updateGroup = useDataStore((s) => s.updateGroup);
  const openSheet = useUiStore((s) => s.openSheet);
  const toast = useUiStore((s) => s.toast);

  const [tab, setTab] = useState<Tab>("all");
  const [topic, setTopic] = useState<TopicFilter>("all");
  const [sort, setSort] = useState<Sort>("popular");

  const market = useMemo<Entry[]>(() => {
    const list = groups.filter((g) => g.isPartner && !g.blocked && (topic === "all" || g.topic === topic));
    const sorted = [...list].sort((a, b) => {
      switch (sort) {
        case "price_asc":
          return partnerNetPrice(a) - partnerNetPrice(b);
        case "price_desc":
          return partnerNetPrice(b) - partnerNetPrice(a);
        case "discount":
          return b.partnerDiscount - a.partnerDiscount;
        case "topic":
          return a.topic.localeCompare(b.topic, "ru") || b.subscriberCount - a.subscriberCount;
        default:
          return b.subscriberCount - a.subscriberCount;
      }
    });
    return sorted.map((group) => ({ group, pending: false }));
  }, [groups, topic, sort]);

  const mine = useMemo<Entry[]>(() => {
    const pendingIds = new Set(requests.filter((r) => r.status === "pending").map((r) => r.groupId));
    return groups.filter((g) => g.isPartner || pendingIds.has(g.id)).map((group) => ({ group, pending: !group.isPartner }));
  }, [groups, requests]);

  const select = useCallback(
    (id: string) => {
      const g = useDataStore.getState().groups.find((x) => x.id === id);
      if (g) openSheet({ type: "wizard", partnerGroupId: g.vkGroupId });
    },
    [openSheet]
  );
  const edit = useCallback((id: string) => openSheet({ type: "editPartner", mode: "edit", groupId: id }), [openSheet]);
  const unlist = useCallback(
    (id: string) => {
      updateGroup(id, { isPartner: false });
      toast("Группа снята с партнёрской программы", "info");
    },
    [updateGroup, toast]
  );
  const apply = useCallback(() => openSheet({ type: "editPartner", mode: "apply" }), [openSheet]);

  const renderMarket = useCallback(
    (e: Entry) => <PartnerCard group={e.group} variant="market" commission={commission} onAction={select} />,
    [commission, select]
  );
  const renderMine = useCallback(
    (e: Entry) => <PartnerCard group={e.group} variant="own" commission={commission} pending={e.pending} onAction={edit} onSecondary={unlist} />,
    [commission, edit, unlist]
  );

  const applyButton = (
    <button type="button" className="btn btn-primary" onClick={apply}>
      <Plus size={20} strokeWidth={1.5} /> Стать партнёром
    </button>
  );

  return (
    <>
      <ScreenHeader>
        <div className="flex items-center gap-3">
          <h1 className="min-w-0 flex-1 truncate font-display text-[26px] font-semibold">Партнёры</h1>
          <button type="button" className="btn btn-soft btn-sm shrink-0" onClick={apply}>
            <Handshake size={18} strokeWidth={1.5} /> Стать партнёром
          </button>
        </div>
      </ScreenHeader>

      <div className={PAGE_CLASS}>
        <ChipBar options={TABS} value={tab} onChange={setTab} className="mb-4" />

        {tab === "all" ? (
          <>
            <div className="mb-4 flex flex-col gap-3">
              <ChipBar options={TOPIC_FILTER_OPTIONS} value={topic} onChange={setTopic} />
              <ChipBar options={SORTS} value={sort} onChange={setSort} />
            </div>
            {market.length === 0 ? (
              <EmptyState icon={Store} title="Нет партнёров" text="Партнёрские группы появятся здесь после одобрения заявок." action={applyButton} />
            ) : (
              <VirtualList items={market} renderItem={renderMarket} getKey={getKey} estimateSize={200} gap={12} />
            )}
          </>
        ) : mine.length === 0 ? (
          <EmptyState icon={Store} title="Нет партнёрских групп" text="Добавьте свою группу в партнёрскую программу и получайте заказы на рассылки." action={applyButton} />
        ) : (
          <VirtualList items={mine} renderItem={renderMine} getKey={getKey} estimateSize={200} gap={12} />
        )}
      </div>
    </>
  );
}

export default memo(Partners);
