import { memo, useCallback, useEffect, useMemo, useState } from "react";
import { Loader2, RefreshCw, Search, ShieldCheck, UserX, Users } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { ChipBar } from "@/components/ChipBar";
import { EmptyState } from "@/components/EmptyState";
import { PAGE_CLASS, ScreenHeader } from "@/components/ScreenHeader";
import { SubscriberRow } from "@/components/SubscriberRow";
import { VirtualList } from "@/components/VirtualList";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { collectBase, describeVkError } from "@/lib/vkApi";
import { TOPIC_FILTER_OPTIONS, type TopicFilter } from "@/lib/topics";
import { formatDateTime, formatNum } from "@/lib/format";
import type { Subscriber, TargetSex } from "@/types";

const PAGE_SIZE = 50;
type StateFilter = "active" | "excluded";

const getKey = (s: Subscriber) => s.id;

function Subscribers() {
  const groups = useDataStore(useShallow((s) => s.groups));
  const subscribers = useDataStore(useShallow((s) => s.subscribers));
  const setConsent = useDataStore((s) => s.setSubscriberConsent);
  const openSheet = useUiStore((s) => s.openSheet);
  const toast = useUiStore((s) => s.toast);

  const [groupId, setGroupId] = useState("all");
  const [topic, setTopic] = useState<TopicFilter>("all");
  const [sex, setSex] = useState<TargetSex>("all");
  const [state, setState] = useState<StateFilter>("active");
  const [query, setQuery] = useState("");
  const [debounced, setDebounced] = useState("");
  const [page, setPage] = useState(1);
  const [progress, setProgress] = useState<string | null>(null);

  // debounce поиска 300 мс
  useEffect(() => {
    const t = setTimeout(() => {
      setDebounced(query.trim().toLowerCase());
      setPage(1);
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  useEffect(() => setPage(1), [groupId, topic, sex, state]);

  const topicsUsed = useMemo(() => new Set(groups.map((g) => g.topic)), [groups]);
  const showTopics = topicsUsed.size > 1;

  const topicGroups = useMemo(() => (topic === "all" ? groups : groups.filter((g) => g.topic === topic)), [groups, topic]);
  const groupOptions = useMemo(
    () => [{ value: "all", label: "Все группы" }, ...topicGroups.map((g) => ({ value: String(g.vkGroupId), label: g.name }))],
    [topicGroups]
  );
  // если выбранная группа выпала из фильтра по тематике — сбрасываем
  const activeGroup = groupId === "all" || topicGroups.some((g) => String(g.vkGroupId) === groupId) ? groupId : "all";

  const scope = useMemo(() => {
    const ids = new Set(activeGroup === "all" ? topicGroups.map((g) => g.vkGroupId) : [Number(activeGroup)]);
    return subscribers.filter((s) => ids.has(s.groupId));
  }, [subscribers, topicGroups, activeGroup]);

  const excludedTotal = useMemo(() => scope.reduce((n, s) => n + (s.excluded ? 1 : 0), 0), [scope]);

  // кто реально получит рассылку: с согласием и без запрета на сообщения
  const eligibleTotal = useMemo(() => scope.reduce((n, s) => n + (!s.excluded && s.consent ? 1 : 0), 0), [scope]);

  const stateOptions = useMemo<{ value: StateFilter; label: string }[]>(
    () => [
      { value: "active", label: `В рассылке · ${formatNum(eligibleTotal)}` },
      { value: "excluded", label: `Не учитываются · ${formatNum(excludedTotal)}` },
    ],
    [eligibleTotal, excludedTotal]
  );

  const inState = useMemo(
    () => scope.filter((s) => (state === "active" ? !s.excluded : !!s.excluded)).sort((a, b) => b.lastMessageAt - a.lastMessageAt),
    [scope, state]
  );

  const sexSegments = useMemo(() => {
    let f = 0;
    let m = 0;
    for (const s of inState) {
      if (s.sex === 1) f++;
      else if (s.sex === 2) m++;
    }
    return [
      { value: "all" as TargetSex, label: "Все" },
      { value: "female" as TargetSex, label: `Ж ${formatNum(f)}` },
      { value: "male" as TargetSex, label: `М ${formatNum(m)}` },
    ];
  }, [inState]);

  const filteredSubscribers = useMemo(() => {
    const want = sex === "female" ? 1 : sex === "male" ? 2 : 0;
    return inState.filter((s) => {
      if (want && s.sex !== want) return false;
      if (debounced) {
        const hay = `${s.firstName} ${s.lastName} ${s.screenName ?? ""} ${s.vkUserId}`.toLowerCase();
        if (!hay.includes(debounced)) return false;
      }
      return true;
    });
  }, [inState, sex, debounced]);

  // ленивая подгрузка пачками по 50
  const shown = useMemo(() => filteredSubscribers.slice(0, page * PAGE_SIZE), [filteredSubscribers, page]);
  const onEnd = useCallback(() => setPage((p) => (p * PAGE_SIZE < filteredSubscribers.length ? p + 1 : p)), [filteredSubscribers.length]);

  const updatedAt = useMemo(() => {
    const times = topicGroups.map((g) => g.baseUpdatedAt ?? 0);
    if (!times.length || times.some((t) => t <= 0)) return null;
    return Math.min(...times);
  }, [topicGroups]);

  const caption = progress
    ? progress
    : topicGroups.length === 0
      ? null
      : updatedAt
        ? `База обновлена ${formatDateTime(updatedAt)}`
        : "Обновите базу, чтобы проверить, кто закрыл сообщения";

  const refresh = async () => {
    const targets = activeGroup === "all" ? topicGroups : topicGroups.filter((g) => String(g.vkGroupId) === activeGroup);
    if (!targets.length) return;
    let ok = 0;
    for (let i = 0; i < targets.length; i++) {
      const g = targets[i];
      setProgress(`${g.name} · ${i + 1} из ${targets.length}`);
      try {
        useDataStore.getState().applyCollectedBase(g.vkGroupId, await collectBase(g));
        ok++;
      } catch (e) {
        toast(`${g.name}: ${describeVkError(e)}`, "error");
      }
    }
    setProgress(null);
    if (ok) toast("База обновлена", "success");
  };

  const renderItem = useCallback((s: Subscriber) => <SubscriberRow sub={s} onConsent={setConsent} />, [setConsent]);
  const connect = useCallback(() => openSheet({ type: "createGroup" }), [openSheet]);

  return (
    <>
      <ScreenHeader>
        <div className="flex items-center gap-3">
          <div className="min-w-0 flex-1">
            <h1 className="truncate font-display text-[26px] font-semibold leading-tight">База</h1>
            {caption && <div className="truncate text-[12px] font-semibold text-mute">{caption}</div>}
          </div>
          <button type="button" className="btn btn-soft btn-sm shrink-0" onClick={refresh} disabled={!!progress || topicGroups.length === 0}>
            {progress ? <Loader2 size={18} strokeWidth={1.5} className="animate-spin" /> : <RefreshCw size={18} strokeWidth={1.5} />}
            Обновить базу
          </button>
        </div>
      </ScreenHeader>

      <div className={PAGE_CLASS}>
        {groups.length === 0 ? (
          <EmptyState
            icon={Users}
            title="Нет подключённых групп"
            text="Подключите сообщество, чтобы собрать базу получателей из диалогов."
            action={
              <button type="button" className="btn btn-primary" onClick={connect}>
                Подключить группу
              </button>
            }
          />
        ) : (
          <>
            <div className="flex flex-col gap-2.5">
              <ChipBar options={stateOptions} value={state} onChange={setState} />
              <ChipBar options={groupOptions} value={activeGroup} onChange={setGroupId} />
              {showTopics && <ChipBar options={TOPIC_FILTER_OPTIONS} value={topic} onChange={setTopic} />}
              <div className="relative">
                <Search size={18} strokeWidth={1.5} className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-mute" />
                <input className="input !pl-11" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Поиск по имени или ID" type="search" />
              </div>
            </div>

            {state === "excluded" && excludedTotal > 0 && (
              <p className="mt-3 rounded-2xl bg-sand/70 px-4 py-3 text-[12px] leading-relaxed text-mute">
                Не получают сообщения от сообщества: запретили сообщения, закрыты приватностью, в чёрном списке или заблокированы. Проверяется при
                обновлении базы и во время отправки.
              </p>
            )}

            <div className="mb-2 mt-4 flex items-center justify-between gap-2">
              <span className="min-w-0 truncate text-[12px] font-semibold text-mute">Показано: {formatNum(filteredSubscribers.length)}</span>
              <div className="flex shrink-0 gap-1" role="group" aria-label="Пол">
                {sexSegments.map((s) => (
                  <button
                    key={s.value}
                    type="button"
                    onClick={() => setSex(s.value)}
                    className={`h-8 rounded-full px-3 text-[12px] font-bold tabular-nums transition-[transform,background-color,color] duration-150 active:scale-[0.95] ${
                      sex === s.value ? "bg-ink text-white" : "border border-line bg-white text-mute"
                    }`}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            {scope.length === 0 ? (
              <EmptyState icon={UserX} title="База пуста" text="Нажмите «Обновить базу», чтобы собрать подписчиков из диалогов сообщества." />
            ) : filteredSubscribers.length === 0 ? (
              <EmptyState
                icon={state === "excluded" ? ShieldCheck : UserX}
                title={state === "excluded" && excludedTotal === 0 ? "Исключённых нет" : "Никого не найдено"}
                text={state === "excluded" && excludedTotal === 0 ? "Все подписчики из собранной базы могут получать сообщения." : "Измените поиск или фильтры."}
              />
            ) : (
              <div className="card">
                <VirtualList items={shown} renderItem={renderItem} getKey={getKey} estimateSize={64} gap={0} onEndReached={onEnd} />
              </div>
            )}
          </>
        )}
      </div>
    </>
  );
}

export default memo(Subscribers);
