import { Loader2, LogIn, Send } from "lucide-react";
import { useAuthStore } from "@/store/useAuthStore";

export default function Auth() {
  const login = useAuthStore((s) => s.login);
  const loading = useAuthStore((s) => s.loading);

  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center overflow-y-auto overflow-x-hidden px-6" style={{ height: "100dvh" }}>
      <div className="anim-fade-up flex w-full max-w-[400px] flex-col items-center py-10 text-center">
        <div className="mb-8 flex size-24 items-center justify-center rounded-[32px] bg-gradient-to-br from-gold to-gold-dark text-white shadow-[0_24px_48px_-20px_rgba(184,147,74,0.8)]">
          <Send size={44} strokeWidth={1.5} />
        </div>
        <h1 className="font-display text-[36px] font-semibold leading-tight">Рассыльщик</h1>
        <p className="mt-3 max-w-[320px] text-balance text-[15px] leading-relaxed text-mute">
          Рассылки для сообществ ВКонтакте: база, персонализация, партнёрская программа.
        </p>

        <button type="button" className="btn btn-primary mt-10 w-full !h-14" onClick={() => void login()} disabled={loading}>
          {loading ? <Loader2 size={22} strokeWidth={1.5} className="animate-spin" /> : <LogIn size={22} strokeWidth={1.5} />}
          <span className="truncate">Войти как @samadluk</span>
        </button>
        <p className="mt-4 text-[12px] text-mute">Профиль загрузится из ВКонтакте. Если сеть недоступна — вход продолжится с локальным профилем.</p>
      </div>
    </div>
  );
}
