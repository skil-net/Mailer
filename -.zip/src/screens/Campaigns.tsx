import { memo, useCallback, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Plus, Send, Settings, Wallet } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { Avatar } from "@/components/Avatar";
import { CampaignCard } from "@/components/CampaignCard";
import { ChipBar } from "@/components/ChipBar";
import { EmptyState } from "@/components/EmptyState";
import { NumberTicker } from "@/components/NumberTicker";
import { PAGE_CLASS, ScreenHeader } from "@/components/ScreenHeader";
import { VirtualList } from "@/components/VirtualList";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { formatNum } from "@/lib/format";
import type { Campaign } from "@/types";

type Filter = "all" | "draft" | "sent" | "scheduled" | "multi";

const FILTERS: ReadonlyArray<{ value: Filter; label: string }> = [
  { value: "all", label: "Все" },
  { value: "draft", label: "Черновики" },
  { value: "sent", label: "Отправленные" },
  { value: "scheduled", label: "Запланированные" },
  { value: "multi", label: "Мультикампании" },
];

const getKey = (c: Campaign) => c.id;

function Campaigns() {
  const navigate = useNavigate();
  const profile = useAuthStore((s) => s.auth.profile);
  const balance = useDataStore((s) => s.balance);
  const campaigns = useDataStore(useShallow((s) => s.campaigns));
  const groups = useDataStore(useShallow((s) => s.groups));
  const openSheet = useUiStore((s) => s.openSheet);
  const [filter, setFilter] = useState<Filter>("all");

  const names = useMemo(() => new Map(groups.map((g) => [g.vkGroupId, g.name])), [groups]);

  const filtered = useMemo(() => {
    switch (filter) {
      case "draft":
        return campaigns.filter((c) => c.status === "draft");
      case "sent":
        return campaigns.filter((c) => c.status === "sent");
      case "scheduled":
        return campaigns.filter((c) => c.status === "scheduled");
      case "multi":
        return campaigns.filter((c) => c.groupIds.length > 1);
      default:
        return campaigns;
    }
  }, [campaigns, filter]);

  const totalSent = useMemo(() => campaigns.reduce((s, c) => s + c.sentCount, 0), [campaigns]);

  const open = useCallback((id: string) => navigate(`/campaign/${id}`), [navigate]);
  const create = useCallback(() => openSheet({ type: "wizard" }), [openSheet]);
  const deposit = useCallback(() => openSheet({ type: "deposit" }), [openSheet]);
  const toProfile = useCallback(() => navigate("/profile"), [navigate]);

  const renderItem = useCallback(
    (c: Campaign) => (
      <CampaignCard
        campaign={c}
        groupsLabel={c.groupIds.map((id) => names.get(id) ?? `Группа ${id}`).join(", ")}
        onOpen={open}
      />
    ),
    [names, open]
  );

  const fullName = profile ? `${profile.firstName} ${profile.lastName}` : "";

  return (
    <>
      <ScreenHeader>
        <div className="flex items-center gap-3">
          <Avatar src={profile?.photo200} name={fullName} monogram={profile?.monogram} size={44} />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[15px] font-bold">{fullName}</div>
            <button type="button" onClick={deposit} className="flex max-w-full items-center gap-1.5 text-[13px] font-semibold text-gold-dark transition-transform active:scale-[0.97]">
              <Wallet size={15} strokeWidth={1.5} className="shrink-0" />
              <span className="truncate">
                <NumberTicker value={balance} suffix={"\u00A0₽"} />
              </span>
            </button>
          </div>
          <button type="button" className="icon-btn" onClick={toProfile} aria-label="Настройки">
            <Settings size={20} strokeWidth={1.5} />
          </button>
        </div>
      </ScreenHeader>

      <div className={PAGE_CLASS}>
        <div className="mb-4 flex items-end justify-between gap-3">
          <h1 className="min-w-0 truncate font-display text-[30px] font-semibold leading-tight">Рассылки</h1>
          <span className="shrink-0 pb-1 text-[13px] font-semibold text-mute">Отправлено: {formatNum(totalSent)}</span>
        </div>

        <ChipBar options={FILTERS} value={filter} onChange={setFilter} className="mb-4" />

        {filtered.length === 0 ? (
          <EmptyState
            icon={Send}
            title={campaigns.length === 0 ? "Рассылок пока нет" : "Ничего не найдено"}
            text={campaigns.length === 0 ? "Создайте первую рассылку: выберите группы, аудиторию и текст сообщения." : "В этой категории рассылок нет."}
            action={
              campaigns.length === 0 ? (
                <button type="button" className="btn btn-primary" onClick={create}>
                  <Plus size={20} strokeWidth={1.5} /> Создать рассылку
                </button>
              ) : undefined
            }
          />
        ) : (
          <VirtualList items={filtered} renderItem={renderItem} getKey={getKey} estimateSize={150} gap={12} />
        )}
      </div>

    </>
  );
}

export default memo(Campaigns);
