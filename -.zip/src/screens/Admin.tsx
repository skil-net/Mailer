import { memo, useCallback, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Lock } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { ChipBar } from "@/components/ChipBar";
import { EmptyState } from "@/components/EmptyState";
import { ScreenHeader } from "@/components/ScreenHeader";
import { goBack } from "@/components/nav";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { AdminDeposits, AdminWithdrawals } from "./admin/AdminPayments";
import { AdminBlocks, AdminPartners, AdminPromos } from "./admin/AdminCatalog";
import { AdminEconomy } from "./admin/AdminEconomy";
import { AdminPromocodes } from "./admin/AdminPromocodes";
import { AdminStats } from "./admin/AdminStats";

type Section = "deposits" | "withdrawals" | "partners" | "promos" | "promocodes" | "blocks" | "economy" | "stats";

function Admin() {
  const navigate = useNavigate();
  const role = useAuthStore((s) => s.auth.role);
  const transactions = useDataStore(useShallow((s) => s.transactions));
  const requests = useDataStore(useShallow((s) => s.partnerRequests));
  const [section, setSection] = useState<Section>("deposits");

  const options = useMemo(() => {
    const dep = transactions.filter((t) => t.type === "deposit" && (t.status === "awaiting_confirmation" || t.status === "pending")).length;
    const wd = transactions.filter((t) => t.type === "withdraw" && t.status === "pending").length;
    const pr = requests.filter((r) => r.status === "pending").length;
    const n = (c: number) => (c > 0 ? ` · ${c}` : "");
    return [
      { value: "deposits" as Section, label: `Пополнения${n(dep)}` },
      { value: "withdrawals" as Section, label: `Выводы${n(wd)}` },
      { value: "partners" as Section, label: `Партнёры${n(pr)}` },
      { value: "promos" as Section, label: "Акции" },
      { value: "promocodes" as Section, label: "Промокоды" },
      { value: "blocks" as Section, label: "Блокировки" },
      { value: "economy" as Section, label: "Экономика" },
      { value: "stats" as Section, label: "Статистика" },
    ];
  }, [transactions, requests]);

  const back = useCallback(() => goBack(navigate, "/profile"), [navigate]);

  return (
    <>
      <ScreenHeader>
        <div className="flex items-center gap-3">
          <button type="button" className="icon-btn" onClick={back} aria-label="Назад">
            <ArrowLeft size={20} strokeWidth={1.5} />
          </button>
          <h1 className="min-w-0 flex-1 truncate font-display text-[24px] font-semibold">Админка</h1>
        </div>
        {role === "admin" && (
          <div className="relative -mx-4 mt-3 px-4 tab:-mx-6 tab:px-6">
            <ChipBar options={options} value={section} onChange={setSection} />
            <div className="pointer-events-none absolute inset-y-0 right-0 w-10 bg-gradient-to-l from-paper to-transparent" aria-hidden />
          </div>
        )}
      </ScreenHeader>

      <div className="mx-auto w-full max-w-[720px] px-4 pb-12 pt-4 tab:px-6">
        {role !== "admin" ? (
          <EmptyState icon={Lock} title="Нет доступа" text="Раздел доступен только администраторам." />
        ) : (
          <div key={section} className="anim-fade-up">
            {section === "deposits" && <AdminDeposits />}
            {section === "withdrawals" && <AdminWithdrawals />}
            {section === "partners" && <AdminPartners />}
            {section === "promos" && <AdminPromos />}
            {section === "promocodes" && <AdminPromocodes />}
            {section === "blocks" && <AdminBlocks />}
            {section === "economy" && <AdminEconomy />}
            {section === "stats" && <AdminStats />}
          </div>
        )}
      </div>
    </>
  );
}

export default memo(Admin);
