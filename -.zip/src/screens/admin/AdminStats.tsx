import { memo, useMemo } from "react";
import { useShallow } from "zustand/react/shallow";
import { useDataStore } from "@/store/useDataStore";
import { formatNum, formatRub } from "@/lib/format";
import type { CampaignStatus } from "@/types";

const DAY = 86_400_000;
const DAYS = ["вс", "пн", "вт", "ср", "чт", "пт", "сб"];

interface Bar {
  label: string;
  value: number;
}

const BarChart = memo(function BarChart({ data, color, format }: { data: Bar[]; color: string; format: (n: number) => string }) {
  const W = 320;
  const H = 150;
  const pad = 22;
  const max = Math.max(1, ...data.map((d) => d.value));
  const slot = (W - pad * 2) / data.length;
  const bw = Math.min(30, slot * 0.6);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="block h-auto w-full max-w-full" role="img">
      <line x1={pad} y1={H - 24} x2={W - pad} y2={H - 24} stroke="#EDE4D6" />
      {data.map((d, i) => {
        const h = Math.max(d.value > 0 ? 3 : 0, (d.value / max) * (H - 62));
        const x = pad + slot * i + (slot - bw) / 2;
        return (
          <g key={i}>
            <rect x={x} y={H - 24 - h} width={bw} height={h} rx={6} fill={color} opacity={d.value > 0 ? 1 : 0.25} />
            <text x={x + bw / 2} y={H - 28 - h} textAnchor="middle" fontSize="9" fontWeight="700" fill="#2B2622">
              {d.value > 0 ? format(d.value) : ""}
            </text>
            <text x={x + bw / 2} y={H - 8} textAnchor="middle" fontSize="10" fill="#7A6F63">
              {d.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
});

const STATUS_META: Record<CampaignStatus, { label: string; color: string }> = {
  draft: { label: "Черновики", color: "#B9AE9E" },
  scheduled: { label: "Запланированы", color: "#D4A24C" },
  sending: { label: "Отправляются", color: "#C25E3A" },
  paused: { label: "Пауза", color: "#E0A58E" },
  sent: { label: "Отправлены", color: "#3E8E5A" },
  failed: { label: "Ошибка", color: "#C0392B" },
};

const Donut = memo(function Donut({ parts }: { parts: Array<{ label: string; color: string; value: number }> }) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  const R = 48;
  const C = 2 * Math.PI * R;
  let acc = 0;
  return (
    <div className="flex min-w-0 items-center gap-5">
      <svg viewBox="0 0 120 120" className="size-[120px] shrink-0 -rotate-90" role="img">
        <circle cx="60" cy="60" r={R} fill="none" stroke="#F6EEDF" strokeWidth="16" />
        {total > 0 &&
          parts
            .filter((p) => p.value > 0)
            .map((p) => {
              const len = (p.value / total) * C;
              const el = <circle key={p.label} cx="60" cy="60" r={R} fill="none" stroke={p.color} strokeWidth="16" strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-acc} />;
              acc += len;
              return el;
            })}
      </svg>
      <ul className="flex min-w-0 flex-1 flex-col gap-1.5">
        {parts.map((p) => (
          <li key={p.label} className="flex min-w-0 items-center gap-2 text-[12px]">
            <span className="size-2.5 shrink-0 rounded-full" style={{ background: p.color }} />
            <span className="min-w-0 flex-1 truncate text-mute">{p.label}</span>
            <span className="shrink-0 font-bold tabular-nums">{p.value}</span>
          </li>
        ))}
      </ul>
    </div>
  );
});

export const AdminStats = memo(function AdminStats() {
  const balance = useDataStore((s) => s.balance);
  const transactions = useDataStore(useShallow((s) => s.transactions));
  const campaigns = useDataStore(useShallow((s) => s.campaigns));
  const outbox = useDataStore(useShallow((s) => s.outbox));
  const groups = useDataStore(useShallow((s) => s.groups));
  const subscribers = useDataStore(useShallow((s) => s.subscribers));
  const promoActivations = useDataStore(useShallow((s) => s.promoActivations));

  const stats = useMemo(() => {
    const start = new Date();
    start.setHours(0, 0, 0, 0);
    const days = Array.from({ length: 7 }, (_, i) => start.getTime() - (6 - i) * DAY);
    const bucket = (ts: number) => days.findIndex((d) => ts >= d && ts < d + DAY);
    const deposits = days.map((d) => ({ label: DAYS[new Date(d).getDay()], value: 0 }));
    const sent = days.map((d) => ({ label: DAYS[new Date(d).getDay()], value: 0 }));
    let depositTotal = 0;
    let spendTotal = 0;
    for (const t of transactions) {
      if (t.status !== "confirmed") continue;
      if (t.type === "deposit") {
        depositTotal += t.amountRub;
        const b = bucket(t.processedAt ?? t.createdAt);
        if (b >= 0) deposits[b].value += t.amountRub;
      } else if (t.type === "spend") spendTotal += t.amountRub;
    }
    let promoTotal = 0;
    for (const a of promoActivations) promoTotal += a.amountRub;
    for (const o of outbox) {
      if (o.status !== "sent" || !o.sentAt) continue;
      const b = bucket(o.sentAt);
      if (b >= 0) sent[b].value++;
    }
    const byStatus = (Object.keys(STATUS_META) as CampaignStatus[]).map((k) => ({
      label: STATUS_META[k].label,
      color: STATUS_META[k].color,
      value: campaigns.filter((c) => c.status === k).length,
    }));
    const activeSubs = subscribers.filter((s) => !s.excluded).length;
    return {
      deposits,
      sent,
      byStatus,
      depositTotal,
      spendTotal,
      promoTotal,
      activeSubs,
      excludedSubs: subscribers.length - activeSubs,
      messages: campaigns.reduce((s, c) => s + c.sentCount, 0),
    };
  }, [transactions, campaigns, outbox, subscribers, promoActivations]);

  const kpis = [
    { label: "Пополнено", value: formatRub(stats.depositTotal) },
    { label: "Промокоды", value: formatRub(stats.promoTotal) },
    { label: "Потрачено", value: formatRub(stats.spendTotal) },
    { label: "На балансе", value: formatRub(balance) },
    { label: "В базе", value: formatNum(stats.activeSubs) },
    { label: "Не учитываются", value: formatNum(stats.excludedSubs) },
    { label: "Групп", value: formatNum(groups.length) },
    { label: "Рассылок", value: formatNum(campaigns.length) },
    { label: "Сообщений", value: formatNum(stats.messages) },
  ];

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-2 gap-3 tab:grid-cols-3">
        {kpis.map((k) => (
          <div key={k.label} className="card p-4">
            <div className="truncate text-[12px] font-semibold text-mute">{k.label}</div>
            <div className="mt-1 truncate font-display text-[22px] font-bold tabular-nums">{k.value}</div>
          </div>
        ))}
      </div>
      <section className="card p-4">
        <h3 className="mb-2 font-display text-[16px] font-semibold">Пополнения за 7 дней</h3>
        <BarChart data={stats.deposits} color="#D4A24C" format={formatNum} />
      </section>
      <section className="card p-4">
        <h3 className="mb-2 font-display text-[16px] font-semibold">Отправленные сообщения</h3>
        <BarChart data={stats.sent} color="#C25E3A" format={formatNum} />
      </section>
      <section className="card p-4">
        <h3 className="mb-3 font-display text-[16px] font-semibold">Рассылки по статусам</h3>
        <Donut parts={stats.byStatus} />
      </section>
    </div>
  );
});
