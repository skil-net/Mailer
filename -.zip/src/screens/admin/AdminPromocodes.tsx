import { memo, useCallback, useMemo, useState } from "react";
import { Ban, Check, Copy, Dices, Pencil, Plus, Ticket, Trash2, X } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { EmptyState } from "@/components/EmptyState";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { formatRub, toLocalInputValue } from "@/lib/format";
import {
  activationsLabel,
  generatePromoCode,
  normalizePromoCode,
  promoCodeValid,
  promoExpiryLabel,
  promoStatus,
  PROMO_CODE_MAX,
} from "@/lib/promo";
import type { PromoCode } from "@/types";

interface Form {
  id?: string;
  code: string;
  amount: string;
  limit: string;
  expires: string;
}

const EMPTY: Form = { code: "", amount: "500", limit: "1", expires: "" };

interface CardProps {
  item: PromoCode;
  onToggle: (id: string) => void;
  onEdit: (item: PromoCode) => void;
  onRemove: (id: string) => void;
  onCopy: (code: string) => void;
}

const PromoCodeCard = memo(function PromoCodeCard({ item: c, onToggle, onEdit, onRemove, onCopy }: CardProps) {
  const status = promoStatus(c);
  return (
    <div className="card p-4">
      <div className="flex min-w-0 items-center gap-2">
        <button
          type="button"
          onClick={() => onCopy(c.code)}
          className="flex min-w-0 flex-1 items-center gap-2 text-left transition-transform duration-150 active:scale-[0.97]"
          title="Скопировать код"
        >
          <span className="truncate font-mono text-[18px] font-bold tracking-wide">{c.code}</span>
          <Copy size={16} strokeWidth={1.5} className="shrink-0 text-mute" />
        </button>
        <span className={`badge ${status.cls}`}>{status.label}</span>
      </div>

      <div className="mt-2 flex flex-wrap items-baseline gap-x-3 gap-y-1">
        <span className="font-display text-[24px] font-bold tabular-nums text-ok">+{formatRub(c.amountRub)}</span>
        <span className="truncate text-[13px] text-mute">Активаций: {activationsLabel(c)}</span>
        <span className="truncate text-[13px] text-mute">{promoExpiryLabel(c)}</span>
      </div>

      <div className="mt-3 flex gap-2">
        <button type="button" className={`btn btn-sm flex-1 ${c.active ? "btn-soft" : "btn-ok"}`} onClick={() => onToggle(c.id)}>
          {c.active ? <Ban size={16} strokeWidth={1.5} /> : <Check size={16} strokeWidth={1.5} />}
          {c.active ? "Отключить" : "Включить"}
        </button>
        <button type="button" className="btn btn-outline btn-sm flex-1" onClick={() => onEdit(c)}>
          <Pencil size={16} strokeWidth={1.5} /> Изменить
        </button>
        <button type="button" className="icon-btn" onClick={() => onRemove(c.id)} aria-label="Удалить промокод">
          <Trash2 size={18} strokeWidth={1.5} />
        </button>
      </div>
    </div>
  );
});

export const AdminPromocodes = memo(function AdminPromocodes() {
  const promocodes = useDataStore(useShallow((s) => s.promocodes));
  const toast = useUiStore((s) => s.toast);
  const [form, setForm] = useState<Form>(EMPTY);

  const sorted = useMemo(
    () => [...promocodes].sort((a, b) => Number(promoStatus(b).key === "active") - Number(promoStatus(a).key === "active") || b.createdAt - a.createdAt),
    [promocodes]
  );
  const today = useMemo(() => toLocalInputValue(Date.now()).slice(0, 10), []);

  const save = () => {
    const code = normalizePromoCode(form.code);
    if (!promoCodeValid(code)) {
      toast("Код — от 3 до 24 символов: латиница, цифры, дефис", "error");
      return;
    }
    const amountRub = Math.floor(Number(form.amount) || 0);
    if (amountRub <= 0) {
      toast("Укажите сумму зачисления", "error");
      return;
    }
    const maxActivations = Math.max(0, Math.floor(Number(form.limit) || 0));
    let expiresAt: number | null = null;
    if (form.expires) {
      expiresAt = new Date(`${form.expires}T23:59:59`).getTime();
      if (!Number.isFinite(expiresAt)) {
        toast("Проверьте срок действия", "error");
        return;
      }
    }
    const ok = useDataStore.getState().upsertPromoCode({ id: form.id, code, amountRub, maxActivations, expiresAt });
    if (!ok) {
      toast("Такой промокод уже существует", "error");
      return;
    }
    toast(form.id ? "Промокод обновлён" : "Промокод создан", "success");
    setForm(EMPTY);
  };

  const onToggle = useCallback(
    (id: string) => {
      const c = useDataStore.getState().promocodes.find((x) => x.id === id);
      if (!c) return;
      useDataStore.getState().setPromoCodeActive(id, !c.active);
    },
    []
  );
  const onEdit = useCallback((item: PromoCode) => {
    setForm({
      id: item.id,
      code: item.code,
      amount: String(item.amountRub),
      limit: String(item.maxActivations),
      expires: item.expiresAt ? toLocalInputValue(item.expiresAt).slice(0, 10) : "",
    });
    document.querySelector<HTMLElement>('.screen[data-active="true"]')?.scrollTo({ top: 0, behavior: "smooth" });
  }, []);
  const onRemove = useCallback(
    (id: string) => {
      useDataStore.getState().removePromoCode(id);
      toast("Промокод удалён", "info");
    },
    [toast]
  );
  const onCopy = useCallback(
    (code: string) => {
      void navigator.clipboard?.writeText(code).then(
        () => toast("Промокод скопирован", "success"),
        () => toast("Не удалось скопировать", "error")
      );
    },
    [toast]
  );

  return (
    <div className="flex flex-col gap-4">
      <div className="card flex flex-col gap-3 p-4">
        <h3 className="font-display text-[17px] font-semibold">{form.id ? "Редактирование промокода" : "Новый промокод"}</h3>

        <div>
          <label className="field-label" htmlFor="pc-code">
            Код
          </label>
          <div className="flex gap-2">
            <input
              id="pc-code"
              className="input font-mono font-bold uppercase tracking-wider"
              value={form.code}
              maxLength={PROMO_CODE_MAX}
              onChange={(e) => setForm({ ...form, code: normalizePromoCode(e.target.value) })}
              placeholder="RS-XXXX-XXXX"
              autoCapitalize="characters"
              autoComplete="off"
              spellCheck={false}
            />
            <button
              type="button"
              className="btn btn-soft shrink-0 !px-4"
              onClick={() => setForm({ ...form, code: generatePromoCode() })}
              aria-label="Сгенерировать код"
            >
              <Dices size={18} strokeWidth={1.5} />
              <span className="hidden tab:inline">Сгенерировать</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="min-w-0">
            <label className="field-label" htmlFor="pc-amount">
              Сумма на баланс, ₽
            </label>
            <input
              id="pc-amount"
              className="input"
              inputMode="numeric"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value.replace(/\D/g, "").slice(0, 7) })}
              placeholder="500"
            />
          </div>
          <div className="min-w-0">
            <label className="field-label" htmlFor="pc-limit">
              Число активаций
            </label>
            <input
              id="pc-limit"
              className="input"
              inputMode="numeric"
              value={form.limit}
              onChange={(e) => setForm({ ...form, limit: e.target.value.replace(/\D/g, "").slice(0, 5) })}
              placeholder="1"
            />
            <div className="mt-1 truncate text-[11px] text-mute">0 — без ограничений</div>
          </div>
        </div>

        <div>
          <label className="field-label" htmlFor="pc-expires">
            Срок действия
          </label>
          <div className="flex gap-2">
            <input
              id="pc-expires"
              type="date"
              className="input"
              min={today}
              value={form.expires}
              onChange={(e) => setForm({ ...form, expires: e.target.value })}
            />
            {form.expires && (
              <button type="button" className="btn btn-outline btn-sm shrink-0" onClick={() => setForm({ ...form, expires: "" })}>
                <X size={16} strokeWidth={1.5} /> Убрать
              </button>
            )}
          </div>
        </div>

        <div className="flex gap-2">
          <button type="button" className="btn btn-primary flex-1" onClick={save}>
            <Plus size={18} strokeWidth={1.5} /> {form.id ? "Сохранить" : "Создать промокод"}
          </button>
          {form.id && (
            <button type="button" className="btn btn-outline" onClick={() => setForm(EMPTY)}>
              Отмена
            </button>
          )}
        </div>

        <p className="text-[12px] leading-relaxed text-mute">
          Промокод активируется в «Профиль → Настройки → Промокод». Сумма зачисляется на баланс пользователя.
        </p>
      </div>

      {sorted.length === 0 ? (
        <EmptyState icon={Ticket} title="Промокодов нет" text="Создайте промокод — он зачислит рубли на баланс при активации." />
      ) : (
        sorted.map((c) => <PromoCodeCard key={c.id} item={c} onToggle={onToggle} onEdit={onEdit} onRemove={onRemove} onCopy={onCopy} />)
      )}
    </div>
  );
});
