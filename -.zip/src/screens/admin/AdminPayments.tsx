import { memo, useMemo, useState } from "react";
import { Banknote, Check, Inbox, Landmark, X } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { EmptyState } from "@/components/EmptyState";
import { TxStatusBadge } from "@/components/TransactionRow";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { bankColor } from "@/lib/banks";
import { formatDateTime, formatRub, prettyPhone } from "@/lib/format";
import type { Transaction } from "@/types";

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex min-w-0 items-center justify-between gap-3 text-[13px]">
      <span className="shrink-0 text-mute">{label}</span>
      <span className="min-w-0 truncate text-right font-semibold">{children}</span>
    </div>
  );
}

interface CardProps {
  tx: Transaction;
  user: string;
}

const RejectBox = memo(function RejectBox({ onReject, onCancel }: { onReject: (c: string) => void; onCancel: () => void }) {
  const [comment, setComment] = useState("");
  return (
    <div className="anim-fade-up mt-3 flex flex-col gap-2">
      <input className="input" value={comment} onChange={(e) => setComment(e.target.value)} placeholder="Комментарий для пользователя" />
      <div className="grid grid-cols-2 gap-2">
        <button type="button" className="btn btn-danger btn-sm" onClick={() => onReject(comment)} disabled={!comment.trim()}>
          Отклонить
        </button>
        <button type="button" className="btn btn-outline btn-sm" onClick={onCancel}>
          Отмена
        </button>
      </div>
    </div>
  );
});

const DepositRequestCard = memo(function DepositRequestCard({ tx, user }: CardProps) {
  const toast = useUiStore((s) => s.toast);
  const [opId, setOpId] = useState("");
  const [rejecting, setRejecting] = useState(false);

  const confirm = () => {
    if (useDataStore.getState().confirmDeposit(tx.id, opId)) toast("Пополнение подтверждено, баланс обновлён", "success");
    else toast("Не удалось подтвердить заявку", "error");
  };
  const reject = (c: string) => {
    useDataStore.getState().rejectTransaction(tx.id, c);
    toast("Заявка отклонена", "info");
  };

  return (
    <div className="card p-4">
      <div className="flex min-w-0 items-center justify-between gap-2">
        <span className="min-w-0 truncate font-display text-[22px] font-bold tabular-nums">{formatRub(tx.amountRub)}</span>
        <TxStatusBadge status={tx.status} />
      </div>
      <div className="mt-2 flex flex-col gap-1.5">
        <Row label="Пользователь">{user}</Row>
        <Row label="Банк">
          <span className="inline-flex items-center gap-1" style={{ color: bankColor(tx.bankName) }}>
            <Landmark size={14} strokeWidth={1.5} /> {tx.bankName}
          </span>
        </Row>
        <Row label="Дата">{formatDateTime(tx.createdAt)}</Row>
        <Row label="ID заявки">
          <span className="font-mono text-[12px]">{tx.id}</span>
        </Row>
        {!!tx.bonusPercent && <Row label="Бонус акции">+{tx.bonusPercent}%</Row>}
      </div>

      <label className="field-label mt-4" htmlFor={`op-${tx.id}`}>
        ID операции из банка
      </label>
      <input id={`op-${tx.id}`} className="input" value={opId} onChange={(e) => setOpId(e.target.value)} placeholder="Обязательное поле" />

      {rejecting ? (
        <RejectBox onReject={reject} onCancel={() => setRejecting(false)} />
      ) : (
        <div className="mt-3 grid grid-cols-2 gap-2">
          <button type="button" className="btn btn-ok btn-sm" disabled={!opId.trim()} onClick={confirm}>
            <Check size={18} strokeWidth={1.5} /> Подтвердить
          </button>
          <button type="button" className="btn btn-danger btn-sm" onClick={() => setRejecting(true)}>
            <X size={18} strokeWidth={1.5} /> Отклонить
          </button>
        </div>
      )}
    </div>
  );
});

const WithdrawRequestCard = memo(function WithdrawRequestCard({ tx, user }: CardProps) {
  const toast = useUiStore((s) => s.toast);
  const [rejecting, setRejecting] = useState(false);
  return (
    <div className="card p-4">
      <div className="flex min-w-0 items-center justify-between gap-2">
        <span className="min-w-0 truncate font-display text-[22px] font-bold tabular-nums">{formatRub(tx.amountRub)}</span>
        <TxStatusBadge status={tx.status} />
      </div>
      <div className="mt-2 flex flex-col gap-1.5">
        <Row label="Пользователь">{user}</Row>
        <Row label="Телефон (СБП)">{prettyPhone(tx.phone ?? "")}</Row>
        <Row label="Банк">{tx.bankName}</Row>
        <Row label="Комиссия">{formatRub(tx.feeRub)}</Row>
        <Row label="К выплате">{formatRub(tx.amountRub - tx.feeRub)}</Row>
        <Row label="Дата">{formatDateTime(tx.createdAt)}</Row>
      </div>
      {rejecting ? (
        <RejectBox
          onReject={(c) => {
            useDataStore.getState().rejectTransaction(tx.id, c);
            toast("Заявка отклонена, средства возвращены", "info");
          }}
          onCancel={() => setRejecting(false)}
        />
      ) : (
        <div className="mt-4 grid grid-cols-2 gap-2">
          <button
            type="button"
            className="btn btn-ok btn-sm"
            onClick={() => {
              useDataStore.getState().completeWithdraw(tx.id);
              toast("Выплата отмечена", "success");
            }}
          >
            <Banknote size={18} strokeWidth={1.5} /> Выплачено
          </button>
          <button type="button" className="btn btn-danger btn-sm" onClick={() => setRejecting(true)}>
            <X size={18} strokeWidth={1.5} /> Отклонить
          </button>
        </div>
      )}
    </div>
  );
});

function useUserName() {
  const profile = useAuthStore((s) => s.auth.profile);
  return profile ? `${profile.firstName} ${profile.lastName}` : "Пользователь";
}

export const AdminDeposits = memo(function AdminDeposits() {
  const transactions = useDataStore(useShallow((s) => s.transactions));
  const user = useUserName();
  const list = useMemo(
    () =>
      transactions
        .filter((t) => t.type === "deposit" && (t.status === "awaiting_confirmation" || t.status === "pending"))
        .sort((a, b) => Number(b.status === "awaiting_confirmation") - Number(a.status === "awaiting_confirmation") || b.createdAt - a.createdAt),
    [transactions]
  );
  if (!list.length) return <EmptyState icon={Inbox} title="Заявок нет" text="Новые заявки на пополнение появятся здесь." />;
  return (
    <div className="flex flex-col gap-3">
      {list.map((t) => (
        <DepositRequestCard key={t.id} tx={t} user={user} />
      ))}
    </div>
  );
});

export const AdminWithdrawals = memo(function AdminWithdrawals() {
  const transactions = useDataStore(useShallow((s) => s.transactions));
  const user = useUserName();
  const list = useMemo(() => transactions.filter((t) => t.type === "withdraw" && t.status === "pending"), [transactions]);
  if (!list.length) return <EmptyState icon={Inbox} title="Заявок нет" text="Заявки на вывод появятся здесь." />;
  return (
    <div className="flex flex-col gap-3">
      {list.map((t) => (
        <WithdrawRequestCard key={t.id} tx={t} user={user} />
      ))}
    </div>
  );
});
