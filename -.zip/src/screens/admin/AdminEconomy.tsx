import { memo, useState } from "react";
import { Save } from "lucide-react";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { ALL_BANKS } from "@/lib/banks";
import { maskPhone } from "@/lib/format";

function Field({ id, label, code, children }: { id: string; label: string; code: string; children: React.ReactNode }) {
  return (
    <div className="min-w-0">
      <label className="field-label !mb-1" htmlFor={id}>
        {label}
      </label>
      {children}
      <div className="mt-1 truncate font-mono text-[10px] text-mute/80">{code}</div>
    </div>
  );
}

export const AdminEconomy = memo(function AdminEconomy() {
  const settings = useDataStore((s) => s.settings);
  const toast = useUiStore((s) => s.toast);
  const [base, setBase] = useState(String(settings.baseCampaignPriceRub));
  const [commission, setCommission] = useState(String(settings.serviceCommissionPercent));
  const [phone, setPhone] = useState(maskPhone(settings.depositPhone));
  const [banks, setBanks] = useState<string[]>(settings.depositBanks);
  const [timer, setTimer] = useState(String(settings.paymentTimerMinutes));

  const toggleBank = (b: string) => setBanks((p) => (p.includes(b) ? p.filter((x) => x !== b) : [...p, b]));

  const save = () => {
    const digits = phone.replace(/\D/g, "");
    if (digits.length !== 11) return toast("Введите телефон полностью", "error");
    if (!banks.length) return toast("Выберите хотя бы один банк", "error");
    const t = Math.max(1, Number(timer) || 15);
    useDataStore.getState().updateSettings({
      baseCampaignPriceRub: Math.max(0, Number(base) || 0),
      serviceCommissionPercent: Math.min(100, Math.max(0, Number(commission) || 0)),
      depositPhone: `+${digits}`,
      depositBanks: banks,
      paymentTimerMinutes: t,
    });
    toast("Настройки сохранены", "success");
  };

  return (
    <div className="card flex flex-col gap-4 p-4">
      <div className="grid grid-cols-2 gap-3">
        <Field id="ec-base" label="Цена рассылки, ₽" code="base_campaign_price_rub">
          <input id="ec-base" className="input" inputMode="numeric" value={base} onChange={(e) => setBase(e.target.value.replace(/\D/g, "").slice(0, 6))} />
        </Field>
        <Field id="ec-comm" label="Комиссия, %" code="service_commission_percent">
          <input id="ec-comm" className="input" inputMode="numeric" value={commission} onChange={(e) => setCommission(e.target.value.replace(/\D/g, "").slice(0, 3))} />
        </Field>
      </div>

      <Field id="ec-phone" label="Телефон для пополнения" code="deposit_phone">
        <input id="ec-phone" className="input" inputMode="tel" value={phone} onChange={(e) => setPhone(maskPhone(e.target.value))} />
      </Field>

      <Field id="ec-banks" label="Банки для пополнения (выбор случайный)" code="deposit_banks">
        <div id="ec-banks" className="flex flex-wrap gap-2">
          {ALL_BANKS.map((b) => (
            <button key={b} type="button" className="chip" data-active={banks.includes(b)} onClick={() => toggleBank(b)}>
              {b}
            </button>
          ))}
        </div>
      </Field>

      <Field id="ec-timer" label="Таймер оплаты, мин" code="payment_timer_minutes">
        <input id="ec-timer" className="input" inputMode="numeric" value={timer} onChange={(e) => setTimer(e.target.value.replace(/\D/g, "").slice(0, 3))} />
      </Field>

      <button type="button" className="btn btn-primary w-full" onClick={save}>
        <Save size={18} strokeWidth={1.5} /> Сохранить
      </button>
    </div>
  );
});
