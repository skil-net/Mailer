import { memo, useMemo, useState } from "react";
import { Ban, Check, Handshake, Pencil, Plus, ShieldOff, Tag, Trash2, X } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { Avatar } from "@/components/Avatar";
import { EmptyState } from "@/components/EmptyState";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { formatRub } from "@/lib/format";
import type { Promotion } from "@/types";

/* ───────── Партнёры: заявки ───────── */
export const AdminPartners = memo(function AdminPartners() {
  const requests = useDataStore(useShallow((s) => s.partnerRequests));
  const groups = useDataStore(useShallow((s) => s.groups));
  const toast = useUiStore((s) => s.toast);
  const pending = useMemo(() => requests.filter((r) => r.status === "pending"), [requests]);

  if (!pending.length) return <EmptyState icon={Handshake} title="Заявок нет" text="Заявки на партнёрство появятся здесь." />;

  return (
    <div className="flex flex-col gap-3">
      {pending.map((r) => {
        const g = groups.find((x) => x.id === r.groupId);
        return (
          <div key={r.id} className="card p-4">
            <div className="flex min-w-0 items-center gap-3">
              <Avatar src={g?.photoUrl} name={g?.name} size={44} />
              <div className="min-w-0 flex-1">
                <div className="truncate text-[15px] font-bold">{g?.name ?? "Группа удалена"}</div>
                <div className="truncate text-[12px] text-mute">
                  {r.topic} · {formatRub(r.priceRub)} · скидка {r.discount}%
                </div>
              </div>
            </div>
            {r.description && <p className="mt-3 line-clamp-2 text-[13px] text-mute [overflow-wrap:anywhere]">{r.description}</p>}
            <div className="mt-3 grid grid-cols-2 gap-2">
              <button
                type="button"
                className="btn btn-ok btn-sm"
                disabled={!g}
                onClick={() => {
                  useDataStore.getState().resolvePartnerRequest(r.id, true);
                  toast("Партнёр одобрен", "success");
                }}
              >
                <Check size={18} strokeWidth={1.5} /> Одобрить
              </button>
              <button
                type="button"
                className="btn btn-danger btn-sm"
                onClick={() => {
                  useDataStore.getState().resolvePartnerRequest(r.id, false);
                  toast("Заявка отклонена", "info");
                }}
              >
                <X size={18} strokeWidth={1.5} /> Отклонить
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
});

/* ───────── Акции: CRUD ───────── */
interface PromoForm {
  id?: string;
  title: string;
  bonus: string;
  min: string;
  active: boolean;
}
const EMPTY_FORM: PromoForm = { title: "", bonus: "10", min: "1000", active: true };

export const AdminPromos = memo(function AdminPromos() {
  const promotions = useDataStore(useShallow((s) => s.promotions));
  const toast = useUiStore((s) => s.toast);
  const [form, setForm] = useState<PromoForm>(EMPTY_FORM);

  const save = () => {
    const bonus = Number(form.bonus) || 0;
    if (!form.title.trim() || bonus <= 0) return toast("Заполните название и процент бонуса", "error");
    useDataStore.getState().upsertPromotion({ id: form.id, title: form.title.trim(), bonusPercent: bonus, minAmountRub: Number(form.min) || 0, active: form.active });
    setForm(EMPTY_FORM);
    toast("Акция сохранена", "success");
  };
  const edit = (p: Promotion) => setForm({ id: p.id, title: p.title, bonus: String(p.bonusPercent), min: String(p.minAmountRub), active: p.active });

  return (
    <div className="flex flex-col gap-4">
      <div className="card flex flex-col gap-3 p-4">
        <h3 className="font-display text-[17px] font-semibold">{form.id ? "Редактирование акции" : "Новая акция"}</h3>
        <div>
          <label className="field-label" htmlFor="pr-title">
            Название
          </label>
          <input id="pr-title" className="input" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Например, Весенний бонус" />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="min-w-0">
            <label className="field-label" htmlFor="pr-bonus">
              Бонус, %
            </label>
            <input id="pr-bonus" className="input" inputMode="numeric" value={form.bonus} onChange={(e) => setForm({ ...form, bonus: e.target.value.replace(/\D/g, "").slice(0, 3) })} />
          </div>
          <div className="min-w-0">
            <label className="field-label" htmlFor="pr-min">
              Мин. сумма, ₽
            </label>
            <input id="pr-min" className="input" inputMode="numeric" value={form.min} onChange={(e) => setForm({ ...form, min: e.target.value.replace(/\D/g, "").slice(0, 7) })} />
          </div>
        </div>
        <label className="flex cursor-pointer items-center justify-between gap-3 text-[14px] font-semibold">
          <span className="truncate">Активна</span>
          <input type="checkbox" className="size-5 accent-[#D4A24C]" checked={form.active} onChange={(e) => setForm({ ...form, active: e.target.checked })} />
        </label>
        <div className="flex gap-2">
          <button type="button" className="btn btn-primary flex-1" onClick={save}>
            <Plus size={18} strokeWidth={1.5} /> {form.id ? "Сохранить" : "Добавить"}
          </button>
          {form.id && (
            <button type="button" className="btn btn-outline" onClick={() => setForm(EMPTY_FORM)}>
              Отмена
            </button>
          )}
        </div>
      </div>

      {promotions.length === 0 ? (
        <EmptyState icon={Tag} title="Акций нет" text="Добавьте акцию — бонус начислится при подтверждении пополнения." />
      ) : (
        promotions.map((p) => (
          <div key={p.id} className="card flex min-w-0 items-center gap-3 p-4">
            <div className="min-w-0 flex-1">
              <div className="truncate text-[15px] font-bold">{p.title}</div>
              <div className="truncate text-[12px] text-mute">
                +{p.bonusPercent}% от {formatRub(p.minAmountRub)}
              </div>
            </div>
            <button
              type="button"
              className="chip"
              data-active={p.active}
              onClick={() => useDataStore.getState().upsertPromotion({ ...p, active: !p.active })}
            >
              {p.active ? "Активна" : "Выкл."}
            </button>
            <button type="button" className="icon-btn" onClick={() => edit(p)} aria-label="Изменить">
              <Pencil size={18} strokeWidth={1.5} />
            </button>
            <button type="button" className="icon-btn" onClick={() => useDataStore.getState().removePromotion(p.id)} aria-label="Удалить">
              <Trash2 size={18} strokeWidth={1.5} />
            </button>
          </div>
        ))
      )}
    </div>
  );
});

/* ───────── Блокировки групп ───────── */
export const AdminBlocks = memo(function AdminBlocks() {
  const groups = useDataStore(useShallow((s) => s.groups));
  const toast = useUiStore((s) => s.toast);

  if (!groups.length) return <EmptyState icon={ShieldOff} title="Групп нет" text="Подключённые группы появятся здесь." />;

  return (
    <div className="flex flex-col gap-3">
      {groups.map((g) => (
        <div key={g.id} className="card flex min-w-0 items-center gap-3 p-3">
          <Avatar src={g.photoUrl} name={g.name} size={44} />
          <div className="min-w-0 flex-1">
            <div className="truncate text-[15px] font-bold">{g.name}</div>
            <div className="truncate text-[12px] text-mute">{g.blocked ? "Заблокирована" : g.isPartner ? "Партнёр" : "Активна"}</div>
          </div>
          <button
            type="button"
            className={`btn btn-sm shrink-0 ${g.blocked ? "btn-soft" : "btn-danger"}`}
            onClick={() => {
              useDataStore.getState().setGroupBlocked(g.id, !g.blocked);
              toast(g.blocked ? "Группа разблокирована" : "Группа заблокирована", "info");
            }}
          >
            <Ban size={16} strokeWidth={1.5} /> {g.blocked ? "Разблокировать" : "Заблокировать"}
          </button>
        </div>
      ))}
    </div>
  );
});
