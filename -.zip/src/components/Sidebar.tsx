import { memo, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Plus, Send } from "lucide-react";
import { NAV_ITEMS, tabFor, type NavItem } from "./nav";
import { Avatar } from "./Avatar";
import { NumberTicker } from "./NumberTicker";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";

interface ItemProps {
  item: NavItem;
  active: boolean;
  onGo: (to: string) => void;
}

const SidebarItem = memo(function SidebarItem({ item, active, onGo }: ItemProps) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={() => onGo(item.to)}
      aria-current={active ? "page" : undefined}
      className={`flex h-12 w-full min-w-0 items-center gap-3 rounded-[14px] px-4 text-[15px] font-semibold transition-[transform,background-color] duration-150 active:scale-[0.97] ${
        active ? "bg-gold/20 text-ink" : "text-mute hover:bg-white/70"
      }`}
    >
      <Icon size={22} strokeWidth={1.5} className="shrink-0" />
      <span className="truncate">{item.label}</span>
    </button>
  );
});

export const Sidebar = memo(function Sidebar() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const tab = tabFor(pathname);
  const profile = useAuthStore((s) => s.auth.profile);
  const balance = useDataStore((s) => s.balance);
  const openSheet = useUiStore((s) => s.openSheet);
  const go = useCallback((to: string) => navigate(to), [navigate]);
  const create = useCallback(() => openSheet({ type: "wizard" }), [openSheet]);
  const name = profile ? `${profile.firstName} ${profile.lastName}` : "";

  return (
    <aside className="hidden h-full w-[220px] shrink-0 flex-col gap-6 overflow-hidden border-r border-line bg-white/50 p-4 backdrop-blur tab:flex desk:w-[280px] desk:p-6">
      <div className="flex min-w-0 items-center gap-3 px-1">
        <div className="flex size-11 shrink-0 items-center justify-center rounded-[14px] bg-gradient-to-br from-gold to-gold-dark text-white">
          <Send size={22} strokeWidth={1.5} />
        </div>
        <span className="truncate font-display text-[22px] font-bold">Рассыльщик</span>
      </div>

      <button type="button" className="btn btn-primary w-full" onClick={create}>
        <Plus size={20} strokeWidth={1.5} /> <span className="truncate">Создать рассылку</span>
      </button>

      <nav className="flex flex-col gap-1" aria-label="Основная навигация">
        {NAV_ITEMS.map((item) => (
          <SidebarItem key={item.to} item={item} active={item.to === tab} onGo={go} />
        ))}
      </nav>

      <button
        type="button"
        onClick={() => navigate("/profile")}
        className="card mt-auto flex w-full items-center gap-3 p-3 text-left transition-transform duration-150 active:scale-[0.97]"
      >
        <Avatar src={profile?.photo200} name={name} monogram={profile?.monogram} size={40} />
        <div className="min-w-0 flex-1">
          <div className="truncate text-[14px] font-bold">{name}</div>
          <div className="truncate text-[13px] font-semibold text-gold-dark">
            <NumberTicker value={balance} suffix={"\u00A0₽"} />
          </div>
        </div>
      </button>
    </aside>
  );
});
