import { memo, type ReactNode } from "react";
import type { LucideIcon } from "lucide-react";

interface Props {
  icon: LucideIcon;
  title: string;
  text?: string;
  action?: ReactNode;
}

export const EmptyState = memo(function EmptyState({ icon: Icon, title, text, action }: Props) {
  return (
    <div className="anim-fade-up flex w-full max-w-full flex-col items-center overflow-hidden px-6 py-12 text-center">
      <div className="mb-5 flex size-20 items-center justify-center rounded-[28px] bg-gradient-to-br from-gold/20 to-terra/15 text-gold-dark">
        <Icon size={36} strokeWidth={1.5} />
      </div>
      <h3 className="max-w-full truncate font-display text-xl font-semibold">{title}</h3>
      {text && <p className="mt-2 line-clamp-2 max-w-[320px] text-balance text-[14px] leading-relaxed text-mute">{text}</p>}
      {action && <div className="mt-6 max-w-full">{action}</div>}
    </div>
  );
});
