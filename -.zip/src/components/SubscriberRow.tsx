import { memo } from "react";
import type { Subscriber } from "@/types";
import { EXCLUDE_META } from "@/lib/exclusion";
import { formatDate } from "@/lib/format";
import { Avatar } from "./Avatar";

const SEX_LABEL = ["Не указан", "Женщина", "Мужчина"] as const;

interface Props {
  sub: Subscriber;
  onConsent: (id: string, value: boolean) => void;
}

export const SubscriberRow = memo(function SubscriberRow({ sub, onConsent }: Props) {
  const name = `${sub.firstName} ${sub.lastName}`.trim() || `id${sub.vkUserId}`;
  const excluded = sub.excluded ? EXCLUDE_META[sub.excluded] : null;

  return (
    <div className="grid h-16 w-full max-w-full grid-cols-[40px_minmax(0,1fr)_auto] items-center gap-3 overflow-hidden border-b border-line bg-white px-4">
      <Avatar src={sub.photo100} name={name} size={40} />
      <div className="min-w-0">
        <div className={`truncate text-[14px] font-bold ${excluded ? "text-mute" : ""}`}>{name}</div>
        <div className="truncate text-[12px] text-mute">
          {SEX_LABEL[sub.sex]} · {sub.lastMessageAt ? formatDate(sub.lastMessageAt) : "—"}
        </div>
      </div>
      {excluded ? (
        <span className="badge max-w-[150px] bg-bad/10 text-bad" title={excluded.detail}>
          {excluded.label}
        </span>
      ) : (
        <button
          type="button"
          role="switch"
          aria-checked={sub.consent}
          aria-label="Согласие на рассылку"
          onClick={() => onConsent(sub.id, !sub.consent)}
          className={`relative h-7 w-12 shrink-0 rounded-full transition-colors duration-200 active:scale-[0.95] ${sub.consent ? "bg-ok" : "bg-line"}`}
        >
          <span
            className="absolute left-0.5 top-0.5 size-6 rounded-full bg-white shadow transition-transform duration-200"
            style={{ transform: `translateX(${sub.consent ? 20 : 0}px)` }}
          />
        </button>
      )}
    </div>
  );
});
