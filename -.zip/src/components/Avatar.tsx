import { memo, useEffect, useState } from "react";
import { cn } from "@/utils/cn";

interface Props {
  src?: string | null;
  name?: string;
  monogram?: string;
  size?: number;
  className?: string;
}

function monogramOf(name?: string): string {
  const parts = (name ?? "").trim().split(/\s+/).filter(Boolean);
  const m = (parts[0]?.charAt(0) ?? "") + (parts[1]?.charAt(0) ?? "");
  return m.toUpperCase() || "•";
}

export const Avatar = memo(function Avatar({ src, name, monogram, size = 40, className }: Props) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [src]);

  const box = { width: size, height: size };
  if (src && !failed) {
    return (
      <img
        src={src}
        alt={name ?? ""}
        loading="lazy"
        decoding="async"
        width={size}
        height={size}
        onError={() => setFailed(true)}
        className={cn("shrink-0 rounded-full bg-sand object-cover", className)}
        style={box}
      />
    );
  }
  return (
    <div
      aria-label={name}
      className={cn("flex shrink-0 select-none items-center justify-center rounded-full font-bold text-white", className)}
      style={{ ...box, fontSize: Math.round(size * 0.37), background: "linear-gradient(135deg,#D4A24C,#B8934A)" }}
    >
      {monogram ?? monogramOf(name)}
    </div>
  );
});
