import { memo, useEffect, useLayoutEffect, useRef } from "react";
import { formatNum } from "@/lib/format";
import { cn } from "@/utils/cn";

interface Props {
  value: number;
  suffix?: string;
  className?: string;
}

const DURATION = 400;

/** Анимированный счётчик (400 мс, ease-out). Обновляет DOM напрямую, без ререндеров. */
export const NumberTicker = memo(function NumberTicker({ value, suffix = "", className }: Props) {
  const ref = useRef<HTMLSpanElement>(null);
  const shown = useRef(value);
  const mounted = useRef(false);

  useLayoutEffect(() => {
    if (ref.current) ref.current.textContent = formatNum(value) + suffix;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;
    if (!mounted.current) {
      mounted.current = true;
      shown.current = value;
      return;
    }
    const from = shown.current;
    const to = value;
    if (from === to) {
      node.textContent = formatNum(to) + suffix;
      return;
    }
    const start = performance.now();
    let raf = 0;
    const step = (now: number) => {
      const p = Math.min(1, (now - start) / DURATION);
      const eased = 1 - Math.pow(1 - p, 3);
      shown.current = from + (to - from) * eased;
      node.textContent = formatNum(shown.current) + suffix;
      if (p < 1) raf = requestAnimationFrame(step);
      else shown.current = to;
    };
    raf = requestAnimationFrame(step);
    return () => {
      cancelAnimationFrame(raf);
      shown.current = to;
    };
  }, [value, suffix]);

  return <span ref={ref} className={cn("tabular-nums", className)} aria-label={`${formatNum(value)}${suffix}`} />;
});
