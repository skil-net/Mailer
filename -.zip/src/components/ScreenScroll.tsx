import { createContext, useRef, type ReactNode, type RefObject } from "react";

export const ScrollContext = createContext<RefObject<HTMLDivElement | null>>({ current: null });

interface Props {
  active?: boolean;
  children: ReactNode;
}

/**
 * Прокручиваемый контейнер экрана. Неактивные экраны остаются смонтированными
 * (visibility/opacity), поэтому позиция скролла сохраняется между переходами.
 */
export function ScreenScroll({ active = true, children }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  return (
    <ScrollContext.Provider value={ref}>
      <div ref={ref} className="screen" data-active={active} aria-hidden={!active}>
        {children}
      </div>
    </ScrollContext.Provider>
  );
}
