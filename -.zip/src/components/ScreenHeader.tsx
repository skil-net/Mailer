import type { ReactNode } from "react";

/** Липкий хедер экрана: размытый фон, safe-area сверху, контент ограничен колонкой. */
export function ScreenHeader({ children }: { children: ReactNode }) {
  return (
    <header
      className="sticky top-0 z-20 w-full max-w-full border-b border-line/60 bg-paper/85 backdrop-blur-xl"
      style={{ paddingTop: "env(safe-area-inset-top, 0px)" }}
    >
      <div className="mx-auto w-full max-w-[720px] px-4 py-3 tab:px-6">{children}</div>
    </header>
  );
}

export const PAGE_CLASS = "mx-auto w-full max-w-[720px] px-4 pb-36 pt-4 tab:px-6 tab:pb-12";
