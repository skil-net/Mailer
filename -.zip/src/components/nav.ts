import { Send, Store, UserRound, Users, type LucideIcon } from "lucide-react";
import type { NavigateFunction } from "react-router-dom";

/** Возврат назад; если истории нет (прямая ссылка/перезагрузка) — переход на fallback. */
export function goBack(navigate: NavigateFunction, fallback = "/"): void {
  const idx = (window.history.state as { idx?: number } | null)?.idx ?? 0;
  if (idx > 0) navigate(-1);
  else navigate(fallback, { replace: true });
}

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
}

export const NAV_ITEMS: ReadonlyArray<NavItem> = [
  { to: "/", label: "Рассылки", icon: Send },
  { to: "/base", label: "База", icon: Users },
  { to: "/partners", label: "Партнёры", icon: Store },
  { to: "/profile", label: "Профиль", icon: UserRound },
];

/** Какая вкладка подсвечена для данного пути (детали кампании → Рассылки, админка → Профиль). */
export function tabFor(pathname: string): string {
  if (pathname.startsWith("/base")) return "/base";
  if (pathname.startsWith("/partners")) return "/partners";
  if (pathname.startsWith("/profile") || pathname.startsWith("/admin")) return "/profile";
  return "/";
}
