import { memo, useMemo } from "react";
import { AlertTriangle } from "lucide-react";
import { findUnknownPlaceholders, PLACEHOLDERS, SAMPLE_CONTEXT, segmentTemplate, type TemplateContext } from "@/lib/template";

interface Props {
  text: string;
  mode?: "rendered" | "template";
  ctx?: TemplateContext;
}

const KNOWN_TOKENS = new Set(PLACEHOLDERS.map((p) => p.token));

/**
 * Предпросмотр сообщения. «rendered» — с примером данных, «template» — исходный шаблон.
 * Неизвестные переменные подсвечиваются как «неизвестная переменная».
 */
export const MessagePreview = memo(function MessagePreview({ text, mode = "rendered", ctx = SAMPLE_CONTEXT }: Props) {
  const unknown = useMemo(() => findUnknownPlaceholders(text), [text]);

  const nodes = useMemo(() => {
    if (!text) return null;
    if (mode === "rendered") {
      return segmentTemplate(text, ctx).map((s, i) =>
        s.type === "text" ? (
          <span key={i}>{s.value}</span>
        ) : s.type === "var" ? (
          <span key={i} className="rounded-md bg-gold/20 px-1 font-semibold">
            {s.value}
          </span>
        ) : (
          <span key={i} title="неизвестная переменная" className="rounded-md bg-bad/10 px-1 font-semibold text-bad underline decoration-dotted">
            {s.value}
          </span>
        )
      );
    }
    return text.split(/(\{[A-Za-z_][A-Za-z0-9_]*\})/g).map((part, i) => {
      if (/^\{[A-Za-z_][A-Za-z0-9_]*\}$/.test(part)) {
        const known = KNOWN_TOKENS.has(part);
        return (
          <span
            key={i}
            title={known ? undefined : "неизвестная переменная"}
            className={known ? "rounded-md bg-gold/20 px-1 font-semibold text-gold-dark" : "rounded-md bg-bad/10 px-1 font-semibold text-bad underline decoration-dotted"}
          >
            {part}
          </span>
        );
      }
      return <span key={i}>{part}</span>;
    });
  }, [text, mode, ctx]);

  return (
    <div className="max-w-full overflow-hidden">
      <div className="max-h-56 max-w-full overflow-y-auto whitespace-pre-wrap rounded-[18px] rounded-bl-md border border-line bg-sand px-4 py-3 text-[14px] leading-relaxed [overflow-wrap:anywhere]">
        {nodes ?? <span className="text-mute">Текст сообщения появится здесь</span>}
      </div>
      {unknown.length > 0 && (
        <div className="mt-2 flex items-start gap-2 text-[12px] font-semibold text-bad">
          <AlertTriangle size={16} strokeWidth={1.5} className="mt-px shrink-0" />
          <span className="min-w-0 truncate">Неизвестная переменная: {unknown.join(", ")}</span>
        </div>
      )}
    </div>
  );
});
