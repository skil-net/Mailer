import { memo, useCallback, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { CalendarClock, CheckCircle2, Copy, Pause, Play, Trash2, XCircle } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import type { Campaign, OutboxItem } from "@/types";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { isRunning, pauseCampaign, startCampaign } from "@/lib/sender";
import { parseKeyboardJson } from "@/lib/keyboard";
import { SAMPLE_CONTEXT } from "@/lib/template";
import { formatDateTime, formatNum, formatRub } from "@/lib/format";
import { ChipBar } from "./ChipBar";
import { goBack } from "./nav";
import { MessagePreview } from "./MessagePreview";
import { AttachmentRow } from "./AttachmentRow";
import { KeyboardPreview } from "./KeyboardEditor";

type Mode = "template" | "rendered";
const MODE_OPTIONS: ReadonlyArray<{ value: Mode; label: string }> = [
  { value: "template", label: "Шаблон" },
  { value: "rendered", label: "Пример рендера" },
];
const SEX_LABEL = { all: "Все", female: "Женщины", male: "Мужчины" } as const;

const LogRow = memo(function LogRow({ item }: { item: OutboxItem }) {
  const ok = item.status === "sent";
  return (
    <div className="flex min-w-0 items-start gap-3 border-b border-line px-4 py-3 last:border-b-0">
      {ok ? (
        <CheckCircle2 size={18} strokeWidth={1.5} className="mt-0.5 shrink-0 text-ok" />
      ) : (
        <XCircle size={18} strokeWidth={1.5} className="mt-0.5 shrink-0 text-bad" />
      )}
      <div className="min-w-0 flex-1">
        <div className="flex min-w-0 items-center justify-between gap-2 text-[12px] text-mute">
          <span className="truncate font-semibold">id{item.vkUserId}</span>
          <span className="shrink-0 tabular-nums">{item.sentAt ? formatDateTime(item.sentAt) : ""}</span>
        </div>
        {item.renderedText && <p className="mt-1 line-clamp-2 text-[13px] leading-snug [overflow-wrap:anywhere]">{item.renderedText}</p>}
        {item.error && <p className="mt-1 truncate text-[12px] font-semibold text-bad">{item.error}</p>}
      </div>
    </div>
  );
});

interface Props {
  campaign: Campaign;
  onGone: () => void;
}

export const CampaignDetail = memo(function CampaignDetail({ campaign: c, onGone }: Props) {
  const navigate = useNavigate();
  const groups = useDataStore(useShallow((s) => s.groups));
  const outbox = useDataStore(useShallow((s) => s.outbox));
  const openSheet = useUiStore((s) => s.openSheet);
  const toast = useUiStore((s) => s.toast);

  const [activeGroup, setActiveGroup] = useState(String(c.groupIds[0] ?? ""));
  const [mode, setMode] = useState<Mode>("rendered");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const names = useMemo(() => new Map(groups.map((g) => [g.vkGroupId, g.name])), [groups]);
  const options = useMemo(
    () => c.groupIds.map((id) => ({ value: String(id), label: names.get(id) ?? `Группа ${id}` })),
    [c.groupIds, names]
  );
  const gid = Number(activeGroup);
  const groupName = names.get(gid) ?? `Группа ${gid}`;
  const stat = c.groupStats[gid] ?? { total: 0, sent: 0, failed: 0 };
  const multi = c.groupIds.length > 1;

  const ctx = useMemo(() => ({ ...SAMPLE_CONTEXT, groupName }), [groupName]);
  const keyboard = useMemo(() => parseKeyboardJson(c.keyboardJson), [c.keyboardJson]);
  const log = useMemo(() => outbox.filter((o) => o.campaignId === c.id && o.groupId === gid).slice(-20).reverse(), [outbox, c.id, gid]);

  const done = c.sentCount + c.failedCount;
  const progress = useMemo(() => (c.totalCount > 0 ? Math.min(100, Math.round((done / c.totalCount) * 100)) : 0), [done, c.totalCount]);
  const groupPct = stat.total > 0 ? Math.min(100, Math.round(((stat.sent + stat.failed) / stat.total) * 100)) : 0;
  const running = c.status === "sending" || isRunning(c.id);
  const canStart = c.status === "draft" || c.status === "paused" || c.status === "scheduled" || c.status === "failed";

  const start = async () => {
    const r = await startCampaign(c.id);
    if (!r.ok) {
      if (r.needFunds) {
        toast(`Не хватает ${formatRub(r.needFunds)} — пополните баланс`, "error");
        openSheet({ type: "deposit" });
      } else toast(r.error ?? "Не удалось запустить", "error");
    }
  };

  const duplicate = useCallback(() => openSheet({ type: "wizard", duplicateFrom: c.id }), [openSheet, c.id]);

  const remove = () => {
    if (!confirmDelete) {
      setConfirmDelete(true);
      setTimeout(() => setConfirmDelete(false), 3000);
      return;
    }
    const st = useDataStore.getState();
    pauseCampaign(c.id);
    if (c.paid && c.sentCount + c.failedCount === 0) st.refund(c.priceRub, `Возврат: «${c.title}»`);
    onGone();
    goBack(navigate);
    setTimeout(() => useDataStore.getState().removeCampaign(c.id), 260);
  };

  return (
    <div className="flex flex-col gap-4">
      {multi && (
        <div className="sticky top-[var(--detail-header,64px)] z-10 -mx-4 border-b border-line/60 bg-paper/90 px-4 py-2.5 backdrop-blur-xl tab:-mx-6 tab:px-6">
          <div className="mb-2 text-[12px] font-bold text-mute">{c.groupIds.length} групп</div>
          <ChipBar options={options} value={activeGroup} onChange={setActiveGroup} />
        </div>
      )}

      <section className="card p-4">
        <div className="flex items-baseline justify-between gap-3">
          <div className="min-w-0 truncate font-display text-[28px] font-bold tabular-nums">
            {formatNum(c.sentCount)} <span className="text-[18px] font-medium text-mute">/ {formatNum(c.totalCount)}</span>
          </div>
          <span className="shrink-0 text-[15px] font-bold tabular-nums text-gold-dark">{progress}%</span>
        </div>
        <div className="mt-2 h-2 overflow-hidden rounded-full bg-sand">
          <div className="h-full origin-left rounded-full bg-gradient-to-r from-gold to-gold-dark transition-transform duration-500" style={{ transform: `scaleX(${progress / 100})` }} />
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2 text-center">
          {[
            { label: "Отправлено", value: c.sentCount, cls: "text-ok" },
            { label: "Ошибок", value: c.failedCount, cls: c.failedCount ? "text-bad" : "text-ink" },
            { label: "Осталось", value: Math.max(0, c.totalCount - done), cls: "text-ink" },
          ].map((x) => (
            <div key={x.label} className="min-w-0 rounded-2xl bg-sand/70 px-2 py-2.5">
              <div className={`truncate text-[18px] font-extrabold tabular-nums ${x.cls}`}>{formatNum(x.value)}</div>
              <div className="truncate text-[11px] font-semibold text-mute">{x.label}</div>
            </div>
          ))}
        </div>
        <div className="mt-4 flex flex-col gap-1.5 text-[13px] text-mute">
          <div className="flex min-w-0 items-center gap-2">
            <CalendarClock size={15} strokeWidth={1.5} className="shrink-0" />
            <span className="truncate">{c.status === "scheduled" && c.scheduledAt ? `Отправка: ${formatDateTime(c.scheduledAt)}` : `Создана: ${formatDateTime(c.createdAt)}`}</span>
          </div>
          <div className="truncate">
            Пол: {SEX_LABEL[c.targetSex]} · Стоимость: {formatRub(c.priceRub)}
          </div>
          {(c.excludedCount ?? 0) > 0 && (
            <div className="truncate font-semibold text-terra">
              Исключено из базы при отправке: {formatNum(c.excludedCount)} (запретили сообщения или заблокированы)
            </div>
          )}
          {c.lastError && <div className="line-clamp-2 font-semibold text-bad">{c.lastError}</div>}
        </div>
      </section>

      <section className="card p-4">
        <div className="mb-3 flex min-w-0 items-center justify-between gap-3">
          <h3 className="min-w-0 truncate font-display text-[18px] font-semibold">{multi ? groupName : "Сообщение"}</h3>
          <span className="shrink-0 text-[12px] font-semibold tabular-nums text-mute">
            {stat.sent}/{stat.total} · {groupPct}%
          </span>
        </div>

        <ChipBar options={MODE_OPTIONS} value={mode} onChange={setMode} className="mb-3" />
        <MessagePreview text={c.messageText} mode={mode} ctx={ctx} />

        {c.attachments.length > 0 && (
          <div className="mt-4">
            <h4 className="section-title mb-2">Вложения</h4>
            <div className="flex flex-col gap-2">
              {c.attachments.map((a, i) => (
                <AttachmentRow key={a.attachment} index={i} type={a.type} label={a.label} />
              ))}
            </div>
          </div>
        )}

        {keyboard.buttons.length > 0 && (
          <div className="mt-4">
            <h4 className="section-title mb-2">Клавиатура · {keyboard.kind === "inline" ? "Inline" : "One-time"}</h4>
            <KeyboardPreview buttons={keyboard.buttons} />
          </div>
        )}
      </section>

      <section>
        <h3 className="section-title mb-2 px-1">Последние отправки · {log.length}</h3>
        <div className="card">
          {log.length === 0 ? <p className="px-4 py-6 text-center text-[13px] text-mute">Отправок пока нет</p> : log.map((o) => <LogRow key={o.id} item={o} />)}
        </div>
      </section>

      <div className="sticky bottom-0 z-10 -mx-4 flex flex-col gap-2 border-t border-line/60 bg-paper/90 px-4 pt-3 backdrop-blur-xl tab:-mx-6 tab:px-6" style={{ paddingBottom: "calc(env(safe-area-inset-bottom, 0px) + 12px)" }}>
        {running ? (
          <button type="button" className="btn btn-soft w-full" onClick={() => pauseCampaign(c.id)}>
            <Pause size={20} strokeWidth={1.5} /> Пауза
          </button>
        ) : canStart ? (
          <button type="button" className="btn btn-primary w-full" onClick={start}>
            <Play size={20} strokeWidth={1.5} /> {c.status === "paused" ? "Продолжить" : "Запустить"}
          </button>
        ) : null}
        <div className="grid grid-cols-2 gap-2">
          <button type="button" className="btn btn-outline" onClick={duplicate}>
            <Copy size={18} strokeWidth={1.5} /> Дублировать
          </button>
          <button type="button" className="btn btn-danger" onClick={remove}>
            <Trash2 size={18} strokeWidth={1.5} /> {confirmDelete ? "Подтвердить" : "Удалить"}
          </button>
        </div>
      </div>
    </div>
  );
});
