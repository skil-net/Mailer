import { memo, useCallback, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AlertTriangle, ArrowLeft, Check, Database, Plus, Store, Users } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { BottomSheet } from "./BottomSheet";
import { ChipBar } from "./ChipBar";
import { GroupCard } from "./GroupCard";
import { EmptyState } from "./EmptyState";
import { WizardMessageStep, type WizardDraft } from "./WizardMessageStep";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { TOPIC_FILTER_OPTIONS, type TopicFilter } from "@/lib/topics";
import { buildKeyboardJson, parseKeyboardJson, validateKeyboard } from "@/lib/keyboard";
import { calcCampaignPrice } from "@/lib/pricing";
import { formatDate, formatNum, formatRub, pluralGroups, toLocalInputValue } from "@/lib/format";
import { startCampaign } from "@/lib/sender";
import type { Campaign, Group, GroupStat, Subscriber, TargetSex } from "@/types";

const STEPS = ["Группы", "Аудитория", "Сообщение", "Отправка"] as const;

const SEX_OPTIONS: ReadonlyArray<{ value: TargetSex; label: string }> = [
  { value: "all", label: "Все" },
  { value: "female", label: "Женщины" },
  { value: "male", label: "Мужчины" },
];

interface BaseCount {
  all: number;
  female: number;
  male: number;
  excluded: number;
}

/** Считает получателей, которые учитываются в рассылке (с согласием и без запрета на сообщения). */
function countBase(subs: Subscriber[]): Map<number, BaseCount> {
  const m = new Map<number, BaseCount>();
  for (const s of subs) {
    const c = m.get(s.groupId) ?? { all: 0, female: 0, male: 0, excluded: 0 };
    if (s.excluded) {
      c.excluded++;
      m.set(s.groupId, c);
      continue;
    }
    if (!s.consent) continue;
    c.all++;
    if (s.sex === 1) c.female++;
    if (s.sex === 2) c.male++;
    m.set(s.groupId, c);
  }
  return m;
}

function estimate(g: Group, base: Map<number, BaseCount>, hasBase: Set<number>, sex: TargetSex): number {
  if (hasBase.has(g.vkGroupId)) return base.get(g.vkGroupId)?.[sex === "all" ? "all" : sex] ?? 0;
  return Math.round(g.subscriberCount * (sex === "all" ? 1 : 0.5));
}

interface Props {
  onClose: () => void;
  level: number;
  groupIds?: number[];
  partnerGroupId?: number;
  duplicateFrom?: string;
}

export const CampaignWizard = memo(function CampaignWizard({ onClose, level, groupIds, partnerGroupId, duplicateFrom }: Props) {
  const navigate = useNavigate();
  const closeRef = useRef<(() => void) | null>(null);
  const groups = useDataStore(useShallow((s) => s.groups));
  const subscribers = useDataStore(useShallow((s) => s.subscribers));
  const settings = useDataStore((s) => s.settings);
  const balance = useDataStore((s) => s.balance);
  const openSheet = useUiStore((s) => s.openSheet);
  const toast = useUiStore((s) => s.toast);

  const source = useMemo<Campaign | undefined>(
    () => (duplicateFrom ? useDataStore.getState().campaigns.find((c) => c.id === duplicateFrom) : undefined),
    [duplicateFrom]
  );

  const [step, setStep] = useState(0);
  const [selected, setSelected] = useState<string[]>(() => {
    const ids = source?.groupIds ?? groupIds ?? (partnerGroupId !== undefined ? [partnerGroupId] : []);
    return groups.filter((g) => ids.includes(g.vkGroupId)).map((g) => g.id);
  });
  const [topic, setTopic] = useState<TopicFilter>("all");
  const [sex, setSex] = useState<TargetSex>(source?.targetSex ?? "all");
  const [draft, setDraft] = useState<WizardDraft>(() => {
    const kb = source ? parseKeyboardJson(source.keyboardJson) : { kind: "inline" as const, buttons: [] };
    return {
      title: source ? `${source.title} (копия)` : "",
      text: source?.messageText ?? "",
      attachments: source?.attachments ?? [],
      kbKind: source?.keyboardType ?? kb.kind,
      kbButtons: kb.buttons,
    };
  });
  const [mode, setMode] = useState<"now" | "later">("now");
  const [when, setWhen] = useState(() => toLocalInputValue(Date.now() + 60 * 60 * 1000));
  const [busy, setBusy] = useState(false);

  const patchDraft = useCallback((p: Partial<WizardDraft>) => setDraft((d) => ({ ...d, ...p })), []);
  const toggle = useCallback(
    (id: string) => setSelected((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id])),
    []
  );

  const base = useMemo(() => countBase(subscribers), [subscribers]);
  const hasBase = useMemo(() => new Set(subscribers.map((s) => s.groupId)), [subscribers]);
  const visibleGroups = useMemo(() => (topic === "all" ? groups : groups.filter((g) => g.topic === topic)), [groups, topic]);
  const selectedGroups = useMemo(() => groups.filter((g) => selected.includes(g.id)), [groups, selected]);

  const audienceAllSex = useMemo(() => selectedGroups.reduce((s, g) => s + estimate(g, base, hasBase, "all"), 0), [selectedGroups, base, hasBase]);
  const audience = useMemo(() => selectedGroups.reduce((s, g) => s + estimate(g, base, hasBase, sex), 0), [selectedGroups, base, hasBase, sex]);
  const excludedInBase = useMemo(() => selectedGroups.reduce((n, g) => n + (base.get(g.vkGroupId)?.excluded ?? 0), 0), [selectedGroups, base]);
  const withoutBase = useMemo(() => selectedGroups.filter((g) => !hasBase.has(g.vkGroupId)).length, [selectedGroups, hasBase]);
  const price = useMemo(() => calcCampaignPrice(selectedGroups, partnerGroupId, settings), [selectedGroups, partnerGroupId, settings]);
  const kbError = useMemo(() => validateKeyboard(draft.kbButtons, draft.kbKind), [draft.kbButtons, draft.kbKind]);

  const selectAllVisible = useCallback(() => {
    setSelected((p) => {
      const ids = visibleGroups.filter((g) => !g.blocked && g.tokenValid).map((g) => g.id);
      const all = ids.every((id) => p.includes(id));
      return all ? p.filter((id) => !ids.includes(id)) : [...new Set([...p, ...ids])];
    });
  }, [visibleGroups]);

  const canNext =
    step === 0
      ? selected.length > 0
      : step === 2
        ? (draft.text.trim().length > 0 || draft.attachments.length > 0) && !kbError
        : true;

  const build = (status: Campaign["status"], scheduledAt: number | null): Omit<Campaign, "id" | "createdAt"> => {
    const groupStats: Record<number, GroupStat> = {};
    for (const g of selectedGroups) groupStats[g.vkGroupId] = { total: estimate(g, base, hasBase, sex), sent: 0, failed: 0 };
    return {
      groupIds: selectedGroups.map((g) => g.vkGroupId),
      title: draft.title.trim() || `Рассылка от ${formatDate(Date.now())}`,
      messageText: draft.text,
      attachments: draft.attachments,
      keyboardJson: buildKeyboardJson(draft.kbButtons, draft.kbKind),
      keyboardType: draft.kbKind,
      targetSex: sex,
      scheduledAt,
      status,
      sentCount: 0,
      failedCount: 0,
      excludedCount: 0,
      totalCount: audience,
      priceRub: price.total,
      paid: false,
      partnerGroupId: selectedGroups.some((g) => g.vkGroupId === partnerGroupId) ? partnerGroupId : undefined,
      groupStats,
    };
  };

  const saveDraft = () => {
    const c = useDataStore.getState().addCampaign(build("draft", null));
    toast("Черновик сохранён", "success");
    closeRef.current?.();
    navigate(`/campaign/${c.id}`);
  };

  const create = async () => {
    if (busy) return;
    const at = mode === "later" ? new Date(when).getTime() : null;
    if (mode === "later" && (!at || Number.isNaN(at) || at < Date.now() + 30_000)) {
      toast("Укажите время в будущем", "error");
      return;
    }
    if (price.total > 0 && balance < price.total) {
      toast(`Не хватает ${formatRub(price.total - balance)} — пополните баланс`, "error");
      openSheet({ type: "deposit" });
      return;
    }
    setBusy(true);
    const st = useDataStore.getState();
    const c = st.addCampaign(build(mode === "later" ? "scheduled" : "draft", at));
    if (mode === "later") {
      st.spend(price.total, `Рассылка «${c.title}»`);
      st.patchCampaign(c.id, { paid: true });
      toast("Рассылка запланирована", "success");
    } else {
      const r = await startCampaign(c.id);
      if (!r.ok) {
        toast("Не удалось запустить рассылку", "error");
        setBusy(false);
        return;
      }
      toast("Рассылка запущена", "success");
    }
    setBusy(false);
    closeRef.current?.();
    navigate(`/campaign/${c.id}`);
  };

  const next = () => setStep((s) => Math.min(3, s + 1));
  const prev = () => setStep((s) => Math.max(0, s - 1));

  const footer = (
    <div className="flex gap-3">
      {step > 0 && (
        <button type="button" className="btn btn-outline" onClick={prev} aria-label="Назад">
          <ArrowLeft size={20} strokeWidth={1.5} />
        </button>
      )}
      {step < 3 ? (
        <button type="button" className="btn btn-primary flex-1" disabled={!canNext} onClick={next}>
          Далее
        </button>
      ) : (
        <>
          <button type="button" className="btn btn-soft" onClick={saveDraft} disabled={busy}>
            Черновик
          </button>
          <button type="button" className="btn btn-primary flex-1" onClick={create} disabled={busy}>
            <Check size={20} strokeWidth={1.5} /> <span className="truncate">Создать рассылку</span>
          </button>
        </>
      )}
    </div>
  );

  const firstGroupName = selectedGroups[0]?.name ?? "";

  return (
    <BottomSheet title="Новая рассылка" level={level} tall onClose={onClose} footer={footer} closeRef={closeRef}>
      <div className="mb-4">
        <div className="flex gap-1.5" aria-hidden>
          {STEPS.map((_, i) => (
            <div key={i} className={`h-1 flex-1 rounded-full transition-colors duration-300 ${i <= step ? "bg-gold" : "bg-line"}`} />
          ))}
        </div>
        <div className="mt-2 flex items-center justify-between text-[12px] font-semibold text-mute">
          <span className="truncate">
            Шаг {step + 1} из 4 · {STEPS[step]}
          </span>
        </div>
      </div>

      <div key={step} className="anim-fade-up max-w-full">
        {step === 0 && (
          <div className="flex flex-col gap-3">
            <ChipBar options={TOPIC_FILTER_OPTIONS} value={topic} onChange={setTopic} />
            <div className="flex items-center justify-between gap-3 rounded-2xl bg-sand px-4 py-3">
              <div className="min-w-0 text-[13px] font-semibold">
                <span className="block truncate">
                  Выбрано: {pluralGroups(selected.length)}, ~{formatNum(audienceAllSex)} получателей
                </span>
              </div>
              {visibleGroups.length > 1 && (
                <button type="button" className="shrink-0 text-[13px] font-bold text-gold-dark" onClick={selectAllVisible}>
                  Все
                </button>
              )}
            </div>

            {groups.length === 0 ? (
              <EmptyState icon={Users} title="Нет подключённых групп" text="Подключите сообщество с помощью ключа доступа, чтобы создавать рассылки." />
            ) : visibleGroups.length === 0 ? (
              <p className="py-6 text-center text-[14px] text-mute">В этой тематике групп нет</p>
            ) : (
              visibleGroups.map((g) => <GroupCard key={g.id} group={g} selected={selected.includes(g.id)} onToggle={toggle} />)
            )}

            <button type="button" className="btn btn-outline w-full" onClick={() => openSheet({ type: "createGroup" })}>
              <Plus size={20} strokeWidth={1.5} /> Подключить группу
            </button>
          </div>
        )}

        {step === 1 && (
          <div className="flex flex-col gap-4">
            <section>
              <h3 className="section-title mb-2">Пол получателей</h3>
              <ChipBar options={SEX_OPTIONS} value={sex} onChange={setSex} />
            </section>

            <div className="card bg-gradient-to-br from-gold/15 to-transparent p-4">
              <div className="text-[13px] font-semibold text-mute">Будет отправлено</div>
              <div className="mt-1 truncate font-display text-[30px] font-bold tabular-nums">~{formatNum(audience)} получателям</div>
            </div>

            <div className="card divide-y divide-line">
              {selectedGroups.map((g) => (
                <div key={g.id} className="flex min-w-0 items-center justify-between gap-3 px-4 py-3 text-[14px]">
                  <span className="min-w-0 flex-1 truncate font-semibold">{g.name}</span>
                  <span className="shrink-0 font-bold tabular-nums">{formatNum(estimate(g, base, hasBase, sex))}</span>
                </div>
              ))}
              {excludedInBase > 0 && (
                <div className="flex min-w-0 items-center justify-between gap-3 px-4 py-3 text-[13px] text-mute">
                  <span className="min-w-0 flex-1 truncate">Не учитываются</span>
                  <span className="shrink-0 font-bold tabular-nums">{formatNum(excludedInBase)}</span>
                </div>
              )}
            </div>
            {excludedInBase > 0 && (
              <p className="-mt-2 text-[12px] leading-relaxed text-mute">
                Не попадают в рассылку те, кто запретил сообщения, закрыт приватностью, в чёрном списке или заблокирован.
              </p>
            )}

            {withoutBase > 0 && (
              <div className="flex items-start gap-2 rounded-2xl bg-gold/15 px-4 py-3 text-[13px]">
                <AlertTriangle size={18} strokeWidth={1.5} className="mt-0.5 shrink-0 text-gold-dark" />
                <span className="min-w-0">
                  Для {pluralGroups(withoutBase)} база ещё не собрана — число приблизительное. Она соберётся автоматически перед отправкой.
                </span>
              </div>
            )}

            <section className="card p-4">
              <div className="mb-2 flex items-center gap-2 font-display text-[16px] font-semibold">
                <Database size={18} strokeWidth={1.5} className="shrink-0 text-gold-dark" /> <span className="truncate">Как собирается база</span>
              </div>
              <ul className="flex flex-col gap-1.5 text-[13px] leading-relaxed text-mute">
                <li>• Получатели — люди, которые писали в сообщество: их диалоги запрашиваются через messages.getConversations (по 200).</li>
                <li>• Беседы и чаты пропускаются, дубликаты удаляются.</li>
                <li>• Кто запретил сообщения, закрыт приватностью, в чёрном списке или заблокирован — в рассылку не попадает.</li>
                <li>• Рассылка уходит только тем, у кого включено согласие.</li>
              </ul>
            </section>
          </div>
        )}

        {step === 2 && <WizardMessageStep draft={draft} groupName={firstGroupName} onPatch={patchDraft} />}

        {step === 3 && (
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3">
              {(["now", "later"] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  role="radio"
                  aria-checked={mode === m}
                  onClick={() => setMode(m)}
                  className={`rounded-2xl border p-3 text-left text-[14px] font-bold transition-[transform,border-color,background-color] duration-150 active:scale-[0.97] ${
                    mode === m ? "border-gold bg-gold/10" : "border-line bg-white"
                  }`}
                >
                  <span className="block truncate">{m === "now" ? "Сейчас" : "Запланировать"}</span>
                  <span className="mt-0.5 block truncate text-[12px] font-medium text-mute">{m === "now" ? "Старт сразу" : "Выбрать время"}</span>
                </button>
              ))}
            </div>
            {mode === "later" && (
              <input
                type="datetime-local"
                className="input"
                value={when}
                min={toLocalInputValue(Date.now())}
                onChange={(e) => setWhen(e.target.value)}
                aria-label="Дата и время отправки"
              />
            )}

            <section className="card">
              <div className="border-b border-line px-4 py-3 font-display text-[16px] font-semibold">Итог</div>
              <div className="divide-y divide-line">
                {price.lines.map((l) => (
                  <div key={l.vkGroupId} className="flex min-w-0 items-center justify-between gap-3 px-4 py-3 text-[14px]">
                    <span className="flex min-w-0 flex-1 items-center gap-2">
                      {l.partner && <Store size={15} strokeWidth={1.5} className="shrink-0 text-terra" />}
                      <span className="truncate font-semibold">{l.name}</span>
                    </span>
                    <span className="shrink-0 font-bold tabular-nums">{formatRub(l.priceRub)}</span>
                  </div>
                ))}
                <div className="flex items-center justify-between gap-3 px-4 py-3 text-[14px]">
                  <span className="truncate text-mute">Аудитория</span>
                  <span className="shrink-0 font-bold tabular-nums">~{formatNum(audience)}</span>
                </div>
                {price.lines.some((l) => l.partner) && (
                  <div className="px-4 py-3 text-[12px] text-mute">Для партнёрских групп цена указана с комиссией сервиса {settings.serviceCommissionPercent}%.</div>
                )}
                <div className="flex items-center justify-between gap-3 bg-sand/60 px-4 py-3">
                  <span className="truncate text-[14px] font-bold">К оплате</span>
                  <span className="shrink-0 font-display text-[22px] font-bold tabular-nums">{formatRub(price.total)}</span>
                </div>
                <div className="flex items-center justify-between gap-3 px-4 py-3 text-[13px]">
                  <span className="truncate text-mute">Ваш баланс</span>
                  <span className={`shrink-0 font-bold tabular-nums ${balance < price.total ? "text-bad" : "text-ok"}`}>{formatRub(balance)}</span>
                </div>
              </div>
            </section>

            {balance < price.total && (
              <div className="flex items-start gap-2 rounded-2xl bg-bad/10 px-4 py-3 text-[13px] font-semibold text-bad">
                <AlertTriangle size={18} strokeWidth={1.5} className="mt-0.5 shrink-0" />
                <span className="min-w-0">Недостаточно средств. При создании откроется пополнение баланса.</span>
              </div>
            )}
          </div>
        )}
      </div>
    </BottomSheet>
  );
});
