import { memo, useEffect, useRef, useState } from "react";
import { Timer as TimerIcon } from "lucide-react";
import { mmss } from "@/lib/format";
import { cn } from "@/utils/cn";

interface Props {
  expiresAt: number;
  onExpire?: () => void;
  className?: string;
}

const secondsLeft = (at: number) => Math.max(0, Math.ceil((at - Date.now()) / 1000));

/** Обратный отсчёт MM:SS, обновление раз в секунду (считается от времени окончания, не дрейфует). */
export const Timer = memo(function Timer({ expiresAt, onExpire, className }: Props) {
  const [left, setLeft] = useState(() => secondsLeft(expiresAt));
  const fired = useRef(false);
  const cb = useRef(onExpire);
  cb.current = onExpire;

  useEffect(() => {
    fired.current = false;
    const tick = () => {
      const l = secondsLeft(expiresAt);
      setLeft(l);
      if (l <= 0 && !fired.current) {
        fired.current = true;
        cb.current?.();
      }
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [expiresAt]);

  return (
    <span className={cn("inline-flex items-center gap-1.5 font-bold tabular-nums", left <= 60 && "text-terra", className)}>
      <TimerIcon size={18} strokeWidth={1.5} />
      {mmss(left)}
    </span>
  );
});
