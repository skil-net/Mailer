import { memo } from "react";
import { AlertCircle, CheckCircle2, Info } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { useUiStore } from "@/store/useUiStore";

export const Toasts = memo(function Toasts() {
  const toasts = useUiStore(useShallow((s) => s.toasts));
  return (
    <div
      className="pointer-events-none fixed inset-x-0 top-0 flex flex-col items-center gap-2 px-4"
      style={{ zIndex: 1200, paddingTop: "calc(env(safe-area-inset-top, 0px) + 12px)" }}
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          role="status"
          className="anim-pop pointer-events-auto flex max-w-full items-center gap-2.5 overflow-hidden rounded-2xl border border-line bg-white px-4 py-3 text-[14px] font-semibold shadow-[0_12px_32px_-12px_rgba(43,38,34,0.35)]"
        >
          {t.kind === "success" ? (
            <CheckCircle2 size={20} strokeWidth={1.5} className="shrink-0 text-ok" />
          ) : t.kind === "error" ? (
            <AlertCircle size={20} strokeWidth={1.5} className="shrink-0 text-bad" />
          ) : (
            <Info size={20} strokeWidth={1.5} className="shrink-0 text-gold-dark" />
          )}
          <span className="line-clamp-2 min-w-0">{t.message}</span>
        </div>
      ))}
    </div>
  );
});
