import { memo } from "react";
import { ArrowDownToLine, ArrowUpFromLine, Send, Ticket, Undo2, type LucideIcon } from "lucide-react";
import type { Transaction, TxStatus, TxType } from "@/types";
import { formatDateTime, formatRub } from "@/lib/format";

export const TX_STATUS: Record<TxStatus, { label: string; cls: string }> = {
  pending: { label: "Ожидает", cls: "bg-sand text-mute" },
  awaiting_confirmation: { label: "На проверке", cls: "bg-gold/20 text-gold-dark" },
  confirmed: { label: "Выполнено", cls: "bg-ok/15 text-ok" },
  rejected: { label: "Отклонено", cls: "bg-bad/10 text-bad" },
  expired: { label: "Истекло", cls: "bg-sand text-mute" },
};

const TYPE_META: Record<TxType, { icon: LucideIcon; title: string; sign: 1 | -1; color: string }> = {
  deposit: { icon: ArrowDownToLine, title: "Пополнение", sign: 1, color: "text-ok" },
  withdraw: { icon: ArrowUpFromLine, title: "Вывод", sign: -1, color: "text-ink" },
  spend: { icon: Send, title: "Рассылка", sign: -1, color: "text-ink" },
  refund: { icon: Undo2, title: "Возврат", sign: 1, color: "text-ok" },
  promo: { icon: Ticket, title: "Промокод", sign: 1, color: "text-ok" },
};

export const TxStatusBadge = memo(function TxStatusBadge({ status }: { status: TxStatus }) {
  const s = TX_STATUS[status];
  return <span className={`badge ${s.cls}`}>{s.label}</span>;
});

export const TransactionRow = memo(function TransactionRow({ tx }: { tx: Transaction }) {
  const meta = TYPE_META[tx.type];
  const Icon = meta.icon;
  const inactive = tx.status === "rejected" || tx.status === "expired";
  const total = tx.amountRub + (tx.bonusRub ?? 0);
  return (
    <div className="grid h-16 w-full max-w-full grid-cols-[40px_minmax(0,1fr)_auto] items-center gap-3 overflow-hidden border-b border-line bg-white px-4">
      <div className="flex size-10 items-center justify-center rounded-xl bg-sand text-gold-dark">
        <Icon size={20} strokeWidth={1.5} />
      </div>
      <div className="min-w-0">
        <div className="truncate text-[14px] font-bold">{tx.title ?? meta.title}</div>
        <div className="truncate text-[12px] text-mute">
          {formatDateTime(tx.createdAt)}
          {tx.bankName ? ` · ${tx.bankName}` : ""}
        </div>
      </div>
      <div className="flex max-w-[132px] flex-col items-end gap-1">
        <span className={`max-w-full truncate text-[14px] font-extrabold tabular-nums ${inactive ? "text-mute line-through" : meta.color}`}>
          {meta.sign > 0 ? "+" : "−"}
          {formatRub(meta.sign > 0 && tx.status === "confirmed" ? total : tx.amountRub)}
        </span>
        {tx.type === "spend" || tx.type === "refund" ? null : <TxStatusBadge status={tx.status} />}
      </div>
    </div>
  );
});
