import { createContext, useCallback, useContext, useEffect, useRef, type MutableRefObject, type ReactNode } from "react";
import { X } from "lucide-react";

const SheetCloseContext = createContext<() => void>(() => undefined);
/** Анимированное закрытие текущего листа из дочерних компонентов. */
export const useSheetClose = () => useContext(SheetCloseContext);

let lockCount = 0;
const lockBody = () => {
  if (lockCount++ === 0) document.body.style.overflow = "hidden";
};
const unlockBody = () => {
  if (--lockCount <= 0) {
    lockCount = 0;
    document.body.style.overflow = "";
  }
};

const EASE = "cubic-bezier(0.32, 0.72, 0, 1)";
const SPRING = "cubic-bezier(0.34, 1.56, 0.64, 1)";
const DISMISS_RATIO = 0.3;
const DISMISS_VELOCITY = 0.5; // px/ms

interface Props {
  onClose: () => void;
  title?: string;
  level?: number;
  tall?: boolean;
  /** Фиксированный футер под прокручиваемой областью (с учётом safe-area). */
  footer?: ReactNode;
  /** Получает функцию анимированного закрытия для родителя. */
  closeRef?: MutableRefObject<(() => void) | null>;
  children: ReactNode;
}

interface DragState {
  active: boolean;
  startY: number;
  lastY: number;
  lastT: number;
  velocity: number;
  dy: number;
}

export function BottomSheet({ onClose, title, level = 0, tall = false, footer, closeRef, children }: Props) {
  const sheetRef = useRef<HTMLDivElement>(null);
  const backdropRef = useRef<HTMLDivElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const closing = useRef(false);
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const drag = useRef<DragState>({ active: false, startY: 0, lastY: 0, lastT: 0, velocity: 0, dy: 0 });

  const applyOffset = useCallback((dy: number) => {
    const el = sheetRef.current;
    const bd = backdropRef.current;
    if (!el) return;
    el.style.transform = `translate3d(0, ${dy}px, 0)`;
    // прозрачность backdrop пропорциональна смещению
    if (bd) bd.style.opacity = String(Math.max(0, 1 - dy / (el.offsetHeight || 1)));
  }, []);

  const dismiss = useCallback(() => {
    if (closing.current) return;
    closing.current = true;
    const el = sheetRef.current;
    const bd = backdropRef.current;
    if (!el || !bd) {
      onCloseRef.current();
      return;
    }
    el.style.animation = "none";
    el.style.transition = `transform 280ms ${EASE}`;
    bd.style.animation = "none";
    bd.style.transition = "opacity 280ms ease-out";
    el.style.transform = "translate3d(0, 100%, 0)";
    bd.style.opacity = "0";
    window.setTimeout(() => onCloseRef.current(), 270);
  }, []);

  useEffect(() => {
    if (closeRef) closeRef.current = dismiss;
    return () => {
      if (closeRef) closeRef.current = null;
    };
  }, [closeRef, dismiss]);

  const snapBack = useCallback(() => {
    const el = sheetRef.current;
    const bd = backdropRef.current;
    if (!el) return;
    el.style.transition = `transform 420ms ${SPRING}`;
    el.style.transform = "translate3d(0, 0, 0)";
    if (bd) {
      bd.style.transition = "opacity 300ms ease-out";
      bd.style.opacity = "1";
    }
  }, []);

  const beginDrag = useCallback((y: number) => {
    const el = sheetRef.current;
    const bd = backdropRef.current;
    if (!el || closing.current) return false;
    el.style.animation = "none";
    el.style.transition = "none";
    if (bd) {
      bd.style.animation = "none";
      bd.style.transition = "none";
    }
    const d = drag.current;
    d.active = true;
    d.startY = y;
    d.lastY = y;
    d.lastT = performance.now();
    d.velocity = 0;
    d.dy = 0;
    return true;
  }, []);

  const moveDrag = useCallback(
    (y: number) => {
      const d = drag.current;
      if (!d.active) return;
      const now = performance.now();
      const dt = now - d.lastT;
      if (dt > 0) {
        const inst = (y - d.lastY) / dt;
        d.velocity = d.velocity * 0.6 + inst * 0.4; // сглаживание скорости
      }
      d.lastY = y;
      d.lastT = now;
      d.dy = Math.max(0, y - d.startY);
      applyOffset(d.dy);
    },
    [applyOffset]
  );

  const endDrag = useCallback(() => {
    const d = drag.current;
    if (!d.active) return;
    d.active = false;
    const h = sheetRef.current?.offsetHeight ?? 1;
    if (d.dy > h * DISMISS_RATIO || d.velocity > DISMISS_VELOCITY) dismiss();
    else snapBack();
  }, [dismiss, snapBack]);

  // Drag за хендл/шапку — pointer events
  const onPointerDown = useCallback(
    (e: React.PointerEvent<HTMLDivElement>) => {
      if ((e.target as HTMLElement).closest("button")) return;
      if (e.pointerType === "mouse" && e.button !== 0) return;
      e.currentTarget.setPointerCapture(e.pointerId);
      beginDrag(e.clientY);
    },
    [beginDrag]
  );
  const onPointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => moveDrag(e.clientY), [moveDrag]);
  const onPointerUp = useCallback(() => endDrag(), [endDrag]);

  // Drag из контента — только когда scrollTop === 0 (touch events, passive: false)
  useEffect(() => {
    const sc = scrollRef.current;
    if (!sc) return;
    let startY = 0;
    let armed = false;
    let dragging = false;
    const onStart = (e: TouchEvent) => {
      if (e.touches.length !== 1) return;
      startY = e.touches[0].clientY;
      armed = sc.scrollTop <= 0;
      dragging = false;
    };
    const onMove = (e: TouchEvent) => {
      const y = e.touches[0].clientY;
      if (!dragging) {
        if (armed && y - startY > 6 && sc.scrollTop <= 0) {
          dragging = beginDrag(y);
        }
        if (!dragging) return;
      }
      if (e.cancelable) e.preventDefault();
      moveDrag(y);
    };
    const onEnd = () => {
      if (dragging) endDrag();
      dragging = false;
      armed = false;
    };
    sc.addEventListener("touchstart", onStart, { passive: true });
    sc.addEventListener("touchmove", onMove, { passive: false });
    sc.addEventListener("touchend", onEnd, { passive: true });
    sc.addEventListener("touchcancel", onEnd, { passive: true });
    return () => {
      sc.removeEventListener("touchstart", onStart);
      sc.removeEventListener("touchmove", onMove);
      sc.removeEventListener("touchend", onEnd);
      sc.removeEventListener("touchcancel", onEnd);
    };
  }, [beginDrag, moveDrag, endDrag]);

  useEffect(() => {
    lockBody();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") dismiss();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      unlockBody();
      window.removeEventListener("keydown", onKey);
    };
  }, [dismiss]);

  return (
    <SheetCloseContext.Provider value={dismiss}>
      <div
        ref={backdropRef}
        onClick={dismiss}
        className="backdrop-enter fixed inset-0 bg-ink/40 backdrop-blur-[3px]"
        style={{ zIndex: 999 + level * 10 }}
        aria-hidden
      />
      <div
        ref={sheetRef}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className="sheet-enter fixed inset-x-0 bottom-0 mx-auto flex w-full max-w-[560px] flex-col overflow-hidden rounded-t-[28px] bg-surface shadow-[0_-12px_48px_-12px_rgba(43,38,34,0.35)]"
        style={{
          zIndex: 1000 + level * 10,
          maxHeight: "85vh",
          height: tall ? "85vh" : undefined,
          willChange: "transform",
        }}
      >
        <div
          className="shrink-0 cursor-grab touch-none select-none active:cursor-grabbing"
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={onPointerUp}
          onPointerCancel={onPointerUp}
        >
          <div className="mx-auto mt-2.5 h-1 w-9 rounded-full bg-line" />
          <div className="flex min-h-14 items-center gap-3 px-5 pb-2 pt-2">
            <h2 className="min-w-0 flex-1 truncate font-display text-[22px] font-semibold">{title}</h2>
            <button type="button" className="icon-btn" onClick={dismiss} aria-label="Закрыть">
              <X size={20} strokeWidth={1.5} />
            </button>
          </div>
        </div>
        <div
          ref={scrollRef}
          className={`min-h-0 max-w-full flex-1 overflow-y-auto overflow-x-hidden overscroll-contain px-5 ${footer ? "pb-4" : "pb-safe"}`}
        >
          {children}
        </div>
        {footer && <div className="pb-safe shrink-0 border-t border-line bg-white px-5 pt-3">{footer}</div>}
      </div>
    </SheetCloseContext.Provider>
  );
}
