import { lazy, memo, Suspense, useCallback, useEffect, useRef, type ReactNode } from "react";
import { useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";
import { useUiStore } from "@/store/useUiStore";
import { BottomNav } from "./BottomNav";
import { Sidebar } from "./Sidebar";
import { RightPanel } from "./RightPanel";
import { ScreenScroll } from "./ScreenScroll";
import { ListSkeleton } from "./Skeleton";
import { Toasts } from "./Toasts";
import { tabFor } from "./nav";
import { SheetHost } from "@/sheets/SheetHost";
import Campaigns from "@/screens/Campaigns";
import Partners from "@/screens/Partners";
import Profile from "@/screens/Profile";
import { useDataStore } from "@/store/useDataStore";
import { useAuthStore } from "@/store/useAuthStore";
import { recoverInterrupted, runDueCampaigns } from "@/lib/sender";

const Subscribers = lazy(() => import("@/screens/Subscribers"));
const CampaignDetailScreen = lazy(() => import("@/screens/CampaignDetailScreen"));
const Admin = lazy(() => import("@/screens/Admin"));

const Fallback = (
  <div className="p-4">
    <ListSkeleton count={4} />
  </div>
);

function Lazy({ children }: { children: ReactNode }) {
  return <Suspense fallback={Fallback}>{children}</Suspense>;
}

const EASE: [number, number, number, number] = [0.32, 0.72, 0, 1];

export const AppLayout = memo(function AppLayout() {
  const { pathname } = useLocation();
  const tab = tabFor(pathname);
  const visited = useRef(new Set<string>(["/"]));
  visited.current.add(tab);

  const detailMatch = pathname.match(/^\/campaign\/([^/]+)/);
  const overlay: "detail" | "admin" | null = detailMatch ? "detail" : pathname === "/admin" ? "admin" : null;
  const detailId = detailMatch?.[1] ?? "";
  const fabVisible = tab === "/" && overlay === null;
  const openSheet = useUiStore((s) => s.openSheet);
  const createCampaign = useCallback(() => openSheet({ type: "wizard" }), [openSheet]);

  useEffect(() => {
    recoverInterrupted();
    useDataStore.getState().expireStale();
    void useAuthStore.getState().silentRefresh();
    const tick = setInterval(() => {
      useDataStore.getState().expireStale();
      runDueCampaigns();
    }, 10_000);
    runDueCampaigns();
    return () => clearInterval(tick);
  }, []);

  return (
    <div className="fixed inset-0 flex justify-center overflow-hidden" style={{ height: "100dvh", maxWidth: "100vw" }}>
      <div className="flex h-full w-full max-w-[1680px] overflow-hidden">
        <Sidebar />

        <main className="relative h-full min-w-0 flex-1 overflow-hidden">
          <ScreenScroll active={tab === "/"}>
            <Campaigns />
          </ScreenScroll>

          {visited.current.has("/base") && (
            <ScreenScroll active={tab === "/base"}>
              <Lazy>
                <Subscribers />
              </Lazy>
            </ScreenScroll>
          )}

          {visited.current.has("/partners") && (
            <ScreenScroll active={tab === "/partners"}>
              <Partners />
            </ScreenScroll>
          )}

          {visited.current.has("/profile") && (
            <ScreenScroll active={tab === "/profile"}>
              <Profile />
            </ScreenScroll>
          )}

          <button
            type="button"
            onClick={createCampaign}
            tabIndex={fabVisible ? 0 : -1}
            aria-hidden={!fabVisible}
            className="btn btn-primary absolute right-4 z-20 !h-14 !rounded-full !px-6 shadow-[0_16px_32px_-12px_rgba(184,147,74,0.9)] tab:right-6 tab:!bottom-6"
            style={{
              bottom: "calc(env(safe-area-inset-bottom, 0px) + 96px)",
              opacity: fabVisible ? 1 : 0,
              transform: fabVisible ? "translate3d(0,0,0)" : "translate3d(0,24px,0) scale(0.9)",
              pointerEvents: fabVisible ? "auto" : "none",
              transition: "opacity 200ms var(--ease-sheet), transform 200ms var(--ease-sheet)",
            }}
          >
            <Plus size={22} strokeWidth={1.5} />
            <span className="truncate">Создать рассылку</span>
          </button>

          <AnimatePresence>
            {overlay && (
              <motion.div
                key={overlay}
                className="absolute inset-0 z-30 bg-paper"
                initial={{ opacity: 0, x: 32 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 32 }}
                transition={{ duration: 0.2, ease: EASE }}
              >
                <ScreenScroll>
                  <Lazy>{overlay === "detail" ? <CampaignDetailScreen id={detailId} /> : <Admin />}</Lazy>
                </ScreenScroll>
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        <RightPanel />
      </div>

      <BottomNav hidden={overlay !== null} />
      <SheetHost />
      <Toasts />
    </div>
  );
});
