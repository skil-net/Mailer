import { memo } from "react";
import { cn } from "@/utils/cn";

export const Skeleton = memo(function Skeleton({ className }: { className?: string }) {
  return <div className={cn("shimmer rounded-[14px]", className)} aria-hidden />;
});

export const ListSkeleton = memo(function ListSkeleton({ count = 3, height = "h-28" }: { count?: number; height?: string }) {
  return (
    <div className="flex flex-col gap-3" aria-busy="true">
      {Array.from({ length: count }, (_, i) => (
        <Skeleton key={i} className={cn("w-full rounded-[20px]", height)} />
      ))}
    </div>
  );
});
