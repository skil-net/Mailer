import { memo } from "react";
import { Check, Users } from "lucide-react";
import type { Group } from "@/types";
import { formatNum } from "@/lib/format";
import { topicColor } from "@/lib/topics";
import { Avatar } from "./Avatar";

interface Props {
  group: Group;
  selected: boolean;
  onToggle: (id: string) => void;
}

export const GroupCard = memo(function GroupCard({ group, selected, onToggle }: Props) {
  const disabled = !!group.blocked || !group.tokenValid;
  return (
    <button
      type="button"
      role="checkbox"
      aria-checked={selected}
      disabled={disabled}
      onClick={() => onToggle(group.id)}
      className={`flex w-full min-w-0 items-center gap-3 overflow-hidden rounded-[20px] border bg-white p-3 text-left transition-[transform,border-color,background-color] duration-150 active:scale-[0.97] disabled:opacity-50 ${
        selected ? "border-gold bg-gold/5" : "border-line"
      }`}
    >
      <Avatar src={group.photoUrl} name={group.name} size={44} />
      <div className="min-w-0 flex-1">
        <div className="truncate text-[15px] font-bold">{group.name}</div>
        <div className="mt-1 flex min-w-0 items-center gap-2 text-[12px] text-mute">
          <span className="inline-flex shrink-0 items-center gap-1">
            <Users size={13} strokeWidth={1.5} />
            {formatNum(group.subscriberCount)}
          </span>
          {group.blocked ? (
            <span className="badge bg-bad/10 text-bad">Заблокирована</span>
          ) : !group.tokenValid ? (
            <span className="badge bg-bad/10 text-bad">Токен недействителен</span>
          ) : (
            <span className="badge" style={{ background: `${topicColor(group.topic)}1A`, color: topicColor(group.topic) }}>
              {group.topic}
            </span>
          )}
        </div>
      </div>
      <span
        className={`flex size-6 shrink-0 items-center justify-center rounded-lg border transition-colors duration-150 ${
          selected ? "border-gold bg-gold text-white" : "border-line bg-white text-transparent"
        }`}
      >
        <Check size={16} strokeWidth={2} />
      </span>
    </button>
  );
});
