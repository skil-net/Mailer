import { memo } from "react";
import { BarChart3, FileText, Image as ImageIcon, Link2, Mic2, Music, Newspaper, ShoppingBag, Video, X, type LucideIcon } from "lucide-react";
import { ATTACHMENT_TITLES, type AttachmentType } from "@/lib/attachments";

const ICONS: Record<AttachmentType, LucideIcon> = {
  photo: ImageIcon,
  video: Video,
  wall: Newspaper,
  doc: FileText,
  audio: Music,
  poll: BarChart3,
  link: Link2,
  market: ShoppingBag,
  artist: Mic2,
};

interface Props {
  index: number;
  type: AttachmentType;
  label: string;
  onRemove?: (index: number) => void;
}

export const AttachmentRow = memo(function AttachmentRow({ index, type, label, onRemove }: Props) {
  const Icon = ICONS[type];
  return (
    <div className="flex min-w-0 max-w-full items-center gap-3 overflow-hidden rounded-2xl border border-line bg-white p-2.5">
      <div className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-sand text-gold-dark">
        <Icon size={20} strokeWidth={1.5} />
      </div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-[13px] font-bold">{ATTACHMENT_TITLES[type]}</div>
        <div className="truncate text-[12px] text-mute">{label}</div>
      </div>
      {onRemove && (
        <button type="button" className="icon-btn !size-9" onClick={() => onRemove(index)} aria-label="Удалить вложение">
          <X size={16} strokeWidth={1.5} />
        </button>
      )}
    </div>
  );
});
