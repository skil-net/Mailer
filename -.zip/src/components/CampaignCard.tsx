import { memo, useMemo } from "react";
import { CalendarClock, ChevronRight, Layers } from "lucide-react";
import type { Campaign, CampaignStatus } from "@/types";
import { formatDateTime, formatNum, pluralGroups } from "@/lib/format";

const STATUS: Record<CampaignStatus, { label: string; cls: string }> = {
  draft: { label: "Черновик", cls: "bg-sand text-mute" },
  scheduled: { label: "Запланирована", cls: "bg-gold/20 text-gold-dark" },
  sending: { label: "Отправляется", cls: "bg-terra/15 text-terra" },
  paused: { label: "Пауза", cls: "bg-sand text-terra" },
  sent: { label: "Отправлена", cls: "bg-ok/15 text-ok" },
  failed: { label: "Ошибка", cls: "bg-bad/10 text-bad" },
};

export const StatusBadge = memo(function StatusBadge({ status }: { status: CampaignStatus }) {
  const s = STATUS[status];
  return <span className={`badge ${s.cls}`}>{s.label}</span>;
});

interface Props {
  campaign: Campaign;
  groupsLabel: string;
  onOpen: (id: string) => void;
}

export const CampaignCard = memo(function CampaignCard({ campaign: c, groupsLabel, onOpen }: Props) {
  const done = c.sentCount + c.failedCount;
  const pct = useMemo(() => (c.totalCount > 0 ? Math.min(100, Math.round((done / c.totalCount) * 100)) : 0), [done, c.totalCount]);
  const multi = c.groupIds.length > 1;
  const when = c.status === "scheduled" && c.scheduledAt ? c.scheduledAt : c.createdAt;

  return (
    <button
      type="button"
      onClick={() => onOpen(c.id)}
      className="card block w-full p-4 text-left transition-transform duration-150 active:scale-[0.97]"
    >
      <div className="flex min-w-0 items-center gap-2">
        <h3 className="min-w-0 flex-1 truncate font-display text-[17px] font-semibold">{c.title}</h3>
        <StatusBadge status={c.status} />
      </div>

      <div className="mt-1.5 flex min-w-0 items-center gap-2 text-[13px] text-mute">
        {multi && (
          <span className="badge gap-1 bg-gold/15 text-gold-dark">
            <Layers size={12} strokeWidth={1.5} />
            {pluralGroups(c.groupIds.length)}
          </span>
        )}
        <span className="min-w-0 flex-1 truncate">{groupsLabel}</span>
      </div>

      <div className="mt-3 flex items-baseline justify-between gap-3 text-[13px]">
        <span className="min-w-0 truncate font-bold tabular-nums">
          {formatNum(c.sentCount)} <span className="font-medium text-mute">/ {formatNum(c.totalCount)}</span>
        </span>
        <span className="shrink-0 font-semibold tabular-nums text-mute">{pct}%</span>
      </div>
      <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-sand">
        <div
          className="h-full origin-left rounded-full bg-gradient-to-r from-gold to-gold-dark transition-transform duration-500"
          style={{ transform: `scaleX(${pct / 100})` }}
        />
      </div>

      <div className="mt-3 flex min-w-0 items-center gap-1.5 text-[12px] text-mute">
        <CalendarClock size={14} strokeWidth={1.5} className="shrink-0" />
        <span className="min-w-0 flex-1 truncate">{formatDateTime(when)}</span>
        <ChevronRight size={16} strokeWidth={1.5} className="shrink-0" />
      </div>
    </button>
  );
});
