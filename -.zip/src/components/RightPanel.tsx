import { memo, useCallback, useMemo } from "react";
import { ArrowDownToLine, ArrowUpFromLine, Wallet } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { NumberTicker } from "./NumberTicker";
import { TransactionRow } from "./TransactionRow";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { formatNum } from "@/lib/format";

/** Правая колонка десктопного 3-колоночного макета (360 px). */
export const RightPanel = memo(function RightPanel() {
  const balance = useDataStore((s) => s.balance);
  const transactions = useDataStore(useShallow((s) => s.transactions));
  const campaigns = useDataStore(useShallow((s) => s.campaigns));
  const openSheet = useUiStore((s) => s.openSheet);
  const deposit = useCallback(() => openSheet({ type: "deposit" }), [openSheet]);
  const withdraw = useCallback(() => openSheet({ type: "withdraw" }), [openSheet]);

  const recent = useMemo(() => transactions.filter((t) => t.status !== "expired").slice(0, 5), [transactions]);
  const stats = useMemo(() => {
    let sent = 0;
    let active = 0;
    for (const c of campaigns) {
      sent += c.sentCount;
      if (c.status === "sending" || c.status === "scheduled") active++;
    }
    return { sent, active };
  }, [campaigns]);

  return (
    <aside className="hidden h-full w-[360px] shrink-0 flex-col gap-4 overflow-y-auto overflow-x-hidden border-l border-line bg-white/50 p-6 backdrop-blur desk:flex">
      <div className="card bg-gradient-to-br from-ink to-[#4a3f36] p-5 text-white">
        <div className="flex items-center gap-2 text-[13px] font-semibold text-white/70">
          <Wallet size={18} strokeWidth={1.5} /> Баланс
        </div>
        <div className="mt-2 truncate font-display text-[36px] font-bold leading-tight">
          <NumberTicker value={balance} suffix={"\u00A0₽"} />
        </div>
        <div className="mt-4 flex gap-2">
          <button type="button" className="btn btn-primary btn-sm flex-1" onClick={deposit}>
            <ArrowDownToLine size={16} strokeWidth={1.5} /> Пополнить
          </button>
          <button type="button" className="btn btn-sm flex-1 bg-white/10 text-white" onClick={withdraw}>
            <ArrowUpFromLine size={16} strokeWidth={1.5} /> Вывести
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="card p-4">
          <div className="truncate text-[12px] font-semibold text-mute">Отправлено</div>
          <div className="mt-1 truncate font-display text-2xl font-bold tabular-nums">{formatNum(stats.sent)}</div>
        </div>
        <div className="card p-4">
          <div className="truncate text-[12px] font-semibold text-mute">Активные</div>
          <div className="mt-1 truncate font-display text-2xl font-bold tabular-nums">{formatNum(stats.active)}</div>
        </div>
      </div>

      <section className="min-w-0">
        <h3 className="section-title mb-2 px-1">Последние операции</h3>
        <div className="card">
          {recent.length === 0 ? (
            <p className="px-4 py-6 text-center text-[13px] text-mute">Операций пока нет</p>
          ) : (
            recent.map((t) => <TransactionRow key={t.id} tx={t} />)
          )}
        </div>
      </section>
    </aside>
  );
});
