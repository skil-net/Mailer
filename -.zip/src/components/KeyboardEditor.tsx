import { memo, useCallback, useMemo, useState } from "react";
import { Plus, ExternalLink } from "lucide-react";
import type { KeyboardKind } from "@/types";
import {
  buildKeyboardJson,
  emptyButton,
  groupRows,
  KB_COLOR_HEX,
  KB_COLOR_LABELS,
  KB_COLS,
  KB_INLINE_MAX_BUTTONS,
  KB_LABEL_MAX,
  KB_MAX_ROWS,
  KB_TYPE_LABELS,
  validateKeyboard,
  type KbButton,
  type KbColor,
  type KbType,
} from "@/lib/keyboard";
import { ChipBar } from "./ChipBar";

const KIND_OPTIONS: ReadonlyArray<{ value: KeyboardKind; label: string }> = [
  { value: "inline", label: "Inline" },
  { value: "one_time", label: "One-time" },
];
const TYPE_OPTIONS = (Object.keys(KB_TYPE_LABELS) as KbType[]).map((v) => ({ value: v, label: KB_TYPE_LABELS[v] }));
const COLOR_OPTIONS = (Object.keys(KB_COLOR_LABELS) as KbColor[]).map((v) => ({ value: v, label: KB_COLOR_LABELS[v] }));

interface CellProps {
  row: number;
  col: number;
  label: string;
  color: KbColor | null;
  selected: boolean;
  onSelect: (row: number, col: number) => void;
}

const Cell = memo(function Cell({ row, col, label, color, selected, onSelect }: CellProps) {
  const filled = color !== null;
  return (
    <button
      type="button"
      onClick={() => onSelect(row, col)}
      className={`flex h-11 min-w-0 items-center justify-center overflow-hidden rounded-xl px-1 text-[11px] font-bold transition-transform duration-150 active:scale-[0.95] ${
        filled ? "" : "border border-dashed border-line bg-white text-mute"
      } ${selected ? "ring-2 ring-gold ring-offset-1" : ""}`}
      style={filled ? { background: KB_COLOR_HEX[color].bg, color: KB_COLOR_HEX[color].fg } : undefined}
      aria-label={filled ? label : "Добавить кнопку"}
    >
      {filled ? <span className="truncate">{label}</span> : <Plus size={16} strokeWidth={1.5} />}
    </button>
  );
});

export const KeyboardPreview = memo(function KeyboardPreview({ buttons }: { buttons: KbButton[] }) {
  const rows = useMemo(() => groupRows(buttons), [buttons]);
  if (!rows.length) return <p className="text-[13px] text-mute">Кнопок нет</p>;
  return (
    <div className="flex max-w-full flex-col gap-1.5 overflow-hidden rounded-2xl bg-sand p-2">
      {rows.map((row, i) => (
        <div key={i} className="flex gap-1.5">
          {row.map((b) => {
            const c = KB_COLOR_HEX[b.type === "open_link" ? "secondary" : b.color];
            return (
              <div
                key={b.col}
                className="flex h-9 min-w-0 flex-1 items-center justify-center gap-1 overflow-hidden rounded-lg px-2 text-[12px] font-semibold"
                style={{ background: c.bg, color: c.fg }}
              >
                <span className="truncate">{b.label}</span>
                {b.type === "open_link" && <ExternalLink size={12} strokeWidth={1.5} className="shrink-0" />}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
});

interface Props {
  kind: KeyboardKind;
  buttons: KbButton[];
  onKindChange: (k: KeyboardKind) => void;
  onChange: (b: KbButton[]) => void;
}

export const KeyboardEditor = memo(function KeyboardEditor({ kind, buttons, onKindChange, onChange }: Props) {
  const [sel, setSel] = useState<{ row: number; col: number } | null>(null);
  const [draft, setDraft] = useState<KbButton | null>(null);
  const [error, setError] = useState<string | null>(null);

  const byPos = useMemo(() => {
    const m = new Map<string, KbButton>();
    for (const b of buttons) m.set(`${b.row}:${b.col}`, b);
    return m;
  }, [buttons]);

  const rowCount = buttons.length ? Math.min(KB_MAX_ROWS, Math.max(...buttons.map((b) => b.row)) + 2) : 1;
  const json = useMemo(() => buildKeyboardJson(buttons, kind), [buttons, kind]);
  const validation = useMemo(() => validateKeyboard(buttons, kind), [buttons, kind]);

  const select = useCallback(
    (row: number, col: number) => {
      const ex = byPos.get(`${row}:${col}`);
      setSel({ row, col });
      setDraft(ex ? { ...ex } : emptyButton(row, col));
      setError(null);
    },
    [byPos]
  );

  const patch = (p: Partial<KbButton>) => setDraft((d) => (d ? { ...d, ...p } : d));

  const save = () => {
    if (!draft) return;
    if (!draft.label.trim()) return setError("Введите текст кнопки");
    if (draft.type === "open_link" && !/^https?:\/\//i.test(draft.url.trim())) return setError("Укажите ссылку, начиная с http(s)://");
    const exists = byPos.has(`${draft.row}:${draft.col}`);
    if (!exists && kind === "inline" && buttons.length >= KB_INLINE_MAX_BUTTONS)
      return setError(`Inline-клавиатура — не более ${KB_INLINE_MAX_BUTTONS} кнопок`);
    onChange([...buttons.filter((b) => !(b.row === draft.row && b.col === draft.col)), draft]);
    setSel(null);
    setDraft(null);
    setError(null);
  };

  const remove = () => {
    if (!draft) return;
    onChange(buttons.filter((b) => !(b.row === draft.row && b.col === draft.col)));
    setSel(null);
    setDraft(null);
  };

  return (
    <div className="flex max-w-full flex-col gap-3 overflow-hidden">
      <ChipBar options={KIND_OPTIONS} value={kind} onChange={onKindChange} />

      <div className="grid grid-cols-5 gap-1.5" role="grid" aria-label={`Сетка ${KB_COLS}×${rowCount}`}>
        {Array.from({ length: rowCount * KB_COLS }, (_, i) => {
          const row = Math.floor(i / KB_COLS);
          const col = i % KB_COLS;
          const b = byPos.get(`${row}:${col}`);
          return (
            <Cell
              key={i}
              row={row}
              col={col}
              label={b?.label ?? ""}
              color={b ? (b.type === "open_link" ? "secondary" : b.color) : null}
              selected={sel?.row === row && sel?.col === col}
              onSelect={select}
            />
          );
        })}
      </div>

      {draft && (
        <div className="anim-fade-up flex flex-col gap-3 overflow-hidden rounded-2xl border border-line bg-sand/60 p-3">
          <div>
            <label className="field-label">Текст кнопки</label>
            <input className="input" value={draft.label} maxLength={KB_LABEL_MAX} onChange={(e) => patch({ label: e.target.value })} placeholder="Например, Узнать больше" />
          </div>
          <div>
            <span className="field-label">Тип</span>
            <ChipBar options={TYPE_OPTIONS} value={draft.type} onChange={(v) => patch({ type: v })} />
          </div>
          {draft.type === "open_link" ? (
            <div>
              <label className="field-label">URL</label>
              <input className="input" inputMode="url" value={draft.url} onChange={(e) => patch({ url: e.target.value })} placeholder="https://" />
            </div>
          ) : (
            <>
              <div>
                <label className="field-label">Payload</label>
                <input className="input" value={draft.payload} onChange={(e) => patch({ payload: e.target.value })} placeholder="Текст или JSON" />
              </div>
              <div>
                <span className="field-label">Цвет</span>
                <ChipBar options={COLOR_OPTIONS} value={draft.color} onChange={(v) => patch({ color: v })} />
              </div>
            </>
          )}
          {error && <p className="text-[12px] font-semibold text-bad">{error}</p>}
          <div className="flex gap-2">
            <button type="button" className="btn btn-primary btn-sm flex-1" onClick={save}>
              Сохранить
            </button>
            {byPos.has(`${draft.row}:${draft.col}`) && (
              <button type="button" className="btn btn-danger btn-sm" onClick={remove}>
                Удалить
              </button>
            )}
            <button
              type="button"
              className="btn btn-outline btn-sm"
              onClick={() => {
                setSel(null);
                setDraft(null);
              }}
            >
              Отмена
            </button>
          </div>
        </div>
      )}

      {buttons.length > 0 && (
        <>
          <div>
            <span className="field-label">Превью клавиатуры</span>
            <KeyboardPreview buttons={buttons} />
          </div>
          {validation ? (
            <p className="text-[12px] font-semibold text-bad">{validation}</p>
          ) : (
            <div>
              <span className="field-label">JSON</span>
              <pre className="max-h-32 max-w-full overflow-auto whitespace-pre-wrap break-all rounded-xl bg-ink p-3 text-[11px] leading-relaxed text-white/90">{json}</pre>
            </div>
          )}
        </>
      )}
    </div>
  );
});
