import { useContext, useEffect, useLayoutEffect, useRef, useState, type ReactNode } from "react";
import { useVirtualizer } from "@tanstack/react-virtual";
import { ScrollContext } from "./ScreenScroll";

interface Props<T> {
  items: T[];
  renderItem: (item: T, index: number) => ReactNode;
  getKey: (item: T, index: number) => string;
  estimateSize: number;
  gap?: number;
  overscan?: number;
  onEndReached?: () => void;
}

/** Виртуализированный список внутри ближайшего ScreenScroll. Высота элементов измеряется. */
export function VirtualList<T>({ items, renderItem, getKey, estimateSize, gap = 12, overscan = 6, onEndReached }: Props<T>) {
  const scrollRef = useContext(ScrollContext);
  const listRef = useRef<HTMLDivElement>(null);
  const [margin, setMargin] = useState(0);

  useLayoutEffect(() => {
    const el = listRef.current;
    const sc = scrollRef.current;
    if (!el || !sc) return;
    const m = Math.round(el.getBoundingClientRect().top - sc.getBoundingClientRect().top + sc.scrollTop);
    if (m !== margin) setMargin(m);
  });

  const virtualizer = useVirtualizer({
    count: items.length,
    // Реф контейнера может быть временно отсоединён (React перемонтирует эффекты в режиме
    // разработки), поэтому контейнер прокрутки ищем и по DOM — иначе список останется пустым.
    getScrollElement: () => scrollRef.current ?? listRef.current?.closest<HTMLElement>(".screen") ?? null,
    estimateSize: () => estimateSize,
    gap,
    overscan,
    scrollMargin: margin,
    getItemKey: (i) => getKey(items[i], i),
  });

  const virtual = virtualizer.getVirtualItems();
  const lastIndex = virtual.length ? virtual[virtual.length - 1].index : -1;

  useEffect(() => {
    if (onEndReached && items.length > 0 && lastIndex >= items.length - 3) onEndReached();
  }, [lastIndex, items.length, onEndReached]);

  return (
    <div ref={listRef} className="relative w-full max-w-full" style={{ height: virtualizer.getTotalSize() }}>
      {virtual.map((vi) => (
        <div
          key={vi.key}
          data-index={vi.index}
          ref={virtualizer.measureElement}
          className="absolute left-0 top-0 w-full max-w-full"
          style={{ transform: `translate3d(0, ${vi.start - margin}px, 0)` }}
        >
          {renderItem(items[vi.index], vi.index)}
        </div>
      ))}
    </div>
  );
}
