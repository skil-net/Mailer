import { memo } from "react";
import { cn } from "@/utils/cn";

interface ChipProps<T extends string> {
  value: T;
  label: string;
  active: boolean;
  onSelect: (v: T) => void;
}

function ChipInner<T extends string>({ value, label, active, onSelect }: ChipProps<T>) {
  return (
    <button type="button" className="chip" data-active={active} onClick={() => onSelect(value)}>
      {label}
    </button>
  );
}
const Chip = memo(ChipInner) as typeof ChipInner;

interface Props<T extends string> {
  options: ReadonlyArray<{ value: T; label: string }>;
  value: T;
  onChange: (v: T) => void;
  className?: string;
}

/** Полоса чипов: горизонтальный скролл внутри своей полосы, без видимого скроллбара. */
function ChipBarInner<T extends string>({ options, value, onChange, className }: Props<T>) {
  return (
    <div className={cn("scrollbar-hidden flex max-w-full gap-2 overflow-x-auto overflow-y-hidden", className)}>
      {options.map((o) => (
        <Chip key={o.value} value={o.value} label={o.label} active={o.value === value} onSelect={onChange} />
      ))}
    </div>
  );
}

export const ChipBar = memo(ChipBarInner) as typeof ChipBarInner;
