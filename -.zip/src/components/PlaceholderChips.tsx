import { memo } from "react";
import { PLACEHOLDERS } from "@/lib/template";

interface ChipProps {
  token: string;
  onInsert: (token: string) => void;
}

const PlaceholderChip = memo(function PlaceholderChip({ token, onInsert }: ChipProps) {
  return (
    <button type="button" className="chip !bg-sand !text-ink" onClick={() => onInsert(token)}>
      {token}
    </button>
  );
});

interface Props {
  onInsert: (token: string) => void;
}

export const PlaceholderChips = memo(function PlaceholderChips({ onInsert }: Props) {
  return (
    <div className="max-w-full overflow-hidden">
      <div className="scrollbar-hidden flex max-w-full gap-2 overflow-x-auto pb-1">
        {PLACEHOLDERS.map((p) => (
          <PlaceholderChip key={p.key} token={p.token} onInsert={onInsert} />
        ))}
      </div>
      <ul className="mt-2 flex flex-col gap-1">
        {PLACEHOLDERS.map((p) => (
          <li key={p.key} className="flex min-w-0 items-baseline gap-2 text-[12px]">
            <span className="w-[96px] shrink-0 truncate font-semibold text-gold-dark">{p.token}</span>
            <span className="min-w-0 flex-1 truncate text-mute">{p.hint}</span>
          </li>
        ))}
      </ul>
    </div>
  );
});
