import { memo, useCallback, useMemo, useRef, useState } from "react";
import { Plus } from "lucide-react";
import type { AttachmentItem, KeyboardKind } from "@/types";
import type { KbButton } from "@/lib/keyboard";
import { parseAttachment } from "@/lib/attachments";
import { SAMPLE_CONTEXT } from "@/lib/template";
import { PlaceholderChips } from "./PlaceholderChips";
import { MessagePreview } from "./MessagePreview";
import { AttachmentRow } from "./AttachmentRow";
import { KeyboardEditor } from "./KeyboardEditor";

export interface WizardDraft {
  title: string;
  text: string;
  attachments: AttachmentItem[];
  kbKind: KeyboardKind;
  kbButtons: KbButton[];
}

export const MAX_TEXT = 4096;
const MAX_ATTACHMENTS = 10;

interface Props {
  draft: WizardDraft;
  groupName: string;
  onPatch: (p: Partial<WizardDraft>) => void;
}

export const WizardMessageStep = memo(function WizardMessageStep({ draft, groupName, onPatch }: Props) {
  const taRef = useRef<HTMLTextAreaElement>(null);
  const textRef = useRef(draft.text);
  textRef.current = draft.text;
  const attRef = useRef(draft.attachments);
  attRef.current = draft.attachments;

  const [attInput, setAttInput] = useState("");
  const [attError, setAttError] = useState<string | null>(null);

  const ctx = useMemo(() => ({ ...SAMPLE_CONTEXT, groupName: groupName || SAMPLE_CONTEXT.groupName }), [groupName]);

  const insert = useCallback(
    (token: string) => {
      const ta = taRef.current;
      const text = textRef.current;
      const start = ta?.selectionStart ?? text.length;
      const end = ta?.selectionEnd ?? start;
      const next = text.slice(0, start) + token + text.slice(end);
      if (next.length > MAX_TEXT) return;
      onPatch({ text: next });
      const pos = start + token.length;
      requestAnimationFrame(() => {
        ta?.focus();
        ta?.setSelectionRange(pos, pos);
      });
    },
    [onPatch]
  );

  const addAttachment = () => {
    const parsed = parseAttachment(attInput);
    if (!parsed) return setAttError("Неподдерживаемый формат ссылки");
    if (attRef.current.some((a) => a.attachment === parsed.attachment)) return setAttError("Это вложение уже добавлено");
    if (attRef.current.length >= MAX_ATTACHMENTS) return setAttError(`Не более ${MAX_ATTACHMENTS} вложений`);
    onPatch({ attachments: [...attRef.current, { type: parsed.type, attachment: parsed.attachment, label: parsed.label }] });
    setAttInput("");
    setAttError(null);
  };

  const removeAttachment = useCallback(
    (i: number) => onPatch({ attachments: attRef.current.filter((_, idx) => idx !== i) }),
    [onPatch]
  );
  const onKind = useCallback((k: KeyboardKind) => onPatch({ kbKind: k }), [onPatch]);
  const onButtons = useCallback((b: KbButton[]) => onPatch({ kbButtons: b }), [onPatch]);

  return (
    <div className="flex max-w-full flex-col gap-5">
      <div>
        <label className="field-label" htmlFor="cmp-title">
          Название рассылки
        </label>
        <input
          id="cmp-title"
          className="input"
          value={draft.title}
          maxLength={80}
          onChange={(e) => onPatch({ title: e.target.value })}
          placeholder="Например, Весенняя акция"
        />
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between gap-2">
          <label className="field-label !mb-0" htmlFor="cmp-text">
            Текст сообщения
          </label>
          <span className={`shrink-0 text-[12px] font-semibold tabular-nums ${draft.text.length > MAX_TEXT - 100 ? "text-terra" : "text-mute"}`}>
            {draft.text.length} / {MAX_TEXT}
          </span>
        </div>
        <textarea
          id="cmp-text"
          ref={taRef}
          className="input min-h-[132px]"
          rows={5}
          maxLength={MAX_TEXT}
          value={draft.text}
          onChange={(e) => onPatch({ text: e.target.value })}
          placeholder="{sex} {first_name}, у нас новости для вас!"
        />
      </div>

      <section>
        <h3 className="section-title mb-2">Плейсхолдеры</h3>
        <PlaceholderChips onInsert={insert} />
        <p className="mt-2 text-[12px] text-mute">Нажмите на переменную — она вставится в позицию курсора и подставится индивидуально для каждого получателя.</p>
      </section>

      <section>
        <h3 className="section-title mb-2">Предпросмотр</h3>
        <MessagePreview text={draft.text} ctx={ctx} />
      </section>

      <section>
        <h3 className="section-title mb-2">Вложения</h3>
        <div className="flex gap-2">
          <input
            className="input"
            value={attInput}
            inputMode="url"
            onChange={(e) => {
              setAttInput(e.target.value);
              setAttError(null);
            }}
            onKeyDown={(e) => e.key === "Enter" && addAttachment()}
            placeholder="Ссылка: vk.com/photo-1_2, wall, video, doc…"
          />
          <button type="button" className="btn btn-soft shrink-0 !px-4" onClick={addAttachment} disabled={!attInput.trim()}>
            <Plus size={18} strokeWidth={1.5} /> Добавить
          </button>
        </div>
        {attError && <div className="mt-2 rounded-xl bg-bad/10 px-3 py-2 text-[13px] font-semibold text-bad">{attError}</div>}
        {draft.attachments.length > 0 && (
          <div className="mt-3 flex flex-col gap-2">
            {draft.attachments.map((a, i) => (
              <AttachmentRow key={a.attachment} index={i} type={a.type} label={a.label} onRemove={removeAttachment} />
            ))}
          </div>
        )}
      </section>

      <section>
        <h3 className="section-title mb-2">Клавиатура</h3>
        <KeyboardEditor kind={draft.kbKind} buttons={draft.kbButtons} onKindChange={onKind} onChange={onButtons} />
      </section>
    </div>
  );
});
