import { memo } from "react";
import { Hourglass, Pencil, Send, Users } from "lucide-react";
import type { Group } from "@/types";
import { formatNum, formatRub } from "@/lib/format";
import { topicColor } from "@/lib/topics";
import { partnerNetPrice } from "@/lib/pricing";
import { Avatar } from "./Avatar";

interface Props {
  group: Group;
  variant: "market" | "own";
  commission: number;
  pending?: boolean;
  onAction: (id: string) => void;
  onSecondary?: (id: string) => void;
}

export const PartnerCard = memo(function PartnerCard({ group: g, variant, commission, pending, onAction, onSecondary }: Props) {
  const net = Math.ceil(partnerNetPrice(g));
  const color = topicColor(g.topic);
  return (
    <div className="card p-4">
      <div className="flex min-w-0 items-center gap-3">
        <Avatar src={g.photoUrl} name={g.name} size={48} />
        <div className="min-w-0 flex-1">
          <div className="truncate text-[16px] font-bold">{g.name}</div>
          <div className="mt-1 flex min-w-0 items-center gap-2 text-[12px] text-mute">
            <span className="badge" style={{ background: `${color}1A`, color }}>
              {g.topic}
            </span>
            <span className="inline-flex min-w-0 items-center gap-1 truncate">
              <Users size={13} strokeWidth={1.5} className="shrink-0" />
              {formatNum(g.subscriberCount)}
            </span>
          </div>
        </div>
        {g.partnerDiscount > 0 && <span className="badge bg-terra/15 text-terra">−{g.partnerDiscount}%</span>}
      </div>

      {g.partnerDescription && (
        <p className="mt-3 line-clamp-2 text-[13px] leading-relaxed text-mute [overflow-wrap:anywhere]">{g.partnerDescription}</p>
      )}

      <div className="mt-3 flex min-w-0 items-end justify-between gap-3">
        <div className="min-w-0">
          <div className="flex min-w-0 items-baseline gap-2">
            <span className="truncate text-[20px] font-extrabold tabular-nums">{formatRub(net)}</span>
            {g.partnerDiscount > 0 && (
              <span className="truncate text-[13px] text-mute tabular-nums line-through">{formatRub(g.partnerPriceRub)}</span>
            )}
          </div>
          <div className="truncate text-[11px] text-mute">за рассылку · комиссия {commission}%</div>
        </div>
      </div>

      <div className="mt-3 flex gap-2">
        {pending ? (
          <button type="button" className="btn btn-soft btn-sm flex-1" disabled>
            <Hourglass size={16} strokeWidth={1.5} /> На рассмотрении
          </button>
        ) : variant === "market" ? (
          <button type="button" className="btn btn-primary btn-sm flex-1" onClick={() => onAction(g.id)}>
            <Send size={16} strokeWidth={1.5} /> <span className="truncate">Выбрать для рассылки</span>
          </button>
        ) : (
          <>
            <button type="button" className="btn btn-soft btn-sm flex-1" onClick={() => onAction(g.id)}>
              <Pencil size={16} strokeWidth={1.5} /> Редактировать
            </button>
            {onSecondary && (
              <button type="button" className="btn btn-outline btn-sm" onClick={() => onSecondary(g.id)}>
                Снять
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
});
