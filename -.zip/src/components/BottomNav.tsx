import { memo, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { NAV_ITEMS, tabFor, type NavItem } from "./nav";

interface ItemProps {
  item: NavItem;
  active: boolean;
  onGo: (to: string) => void;
}

const NavButton = memo(function NavButton({ item, active, onGo }: ItemProps) {
  const Icon = item.icon;
  return (
    <button
      type="button"
      onClick={() => onGo(item.to)}
      aria-current={active ? "page" : undefined}
      className="relative flex h-14 min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-[22px] transition-transform duration-150 active:scale-[0.94]"
    >
      {active && (
        <motion.span
          layoutId="bottom-nav-pill"
          className="absolute inset-1 rounded-[18px] bg-gold/20"
          transition={{ type: "spring", stiffness: 520, damping: 38 }}
        />
      )}
      <Icon size={22} strokeWidth={1.5} className={`relative ${active ? "text-ink" : "text-mute"}`} />
      <span className={`relative max-w-full truncate px-1 text-[11px] font-semibold ${active ? "text-ink" : "text-mute"}`}>{item.label}</span>
    </button>
  );
});

export const BottomNav = memo(function BottomNav({ hidden }: { hidden: boolean }) {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const tab = tabFor(pathname);
  const go = useCallback((to: string) => navigate(to), [navigate]);

  return (
    <nav
      aria-label="Основная навигация"
      className="fixed inset-x-3 z-40 mx-auto flex max-w-[420px] gap-1 overflow-hidden rounded-[28px] border border-line bg-white/90 p-1.5 shadow-[0_16px_40px_-16px_rgba(43,38,34,0.35)] backdrop-blur-xl transition-[transform,opacity] duration-200 tab:hidden"
      style={{
        bottom: "calc(env(safe-area-inset-bottom, 0px) + 12px)",
        transitionTimingFunction: "var(--ease-sheet)",
        transform: hidden ? "translate3d(0, 140%, 0)" : "translate3d(0, 0, 0)",
        opacity: hidden ? 0 : 1,
        pointerEvents: hidden ? "none" : "auto",
      }}
    >
      {NAV_ITEMS.map((item) => (
        <NavButton key={item.to} item={item} active={item.to === tab} onGo={go} />
      ))}
    </nav>
  );
});
