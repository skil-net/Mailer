import { memo, useCallback, useState } from "react";
import { BottomSheet, useSheetClose } from "@/components/BottomSheet";
import { ChipBar } from "@/components/ChipBar";
import { useDataStore, WITHDRAW_FEE_PERCENT, WITHDRAW_MIN_RUB } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { formatRub, isPhoneComplete, maskPhone } from "@/lib/format";

interface Props {
  sheetKey: number;
  level: number;
}

const WithdrawBody = memo(function WithdrawBody() {
  const close = useSheetClose();
  const balance = useDataStore((s) => s.balance);
  const banks = useDataStore((s) => s.settings.banks);
  const toast = useUiStore((s) => s.toast);
  const [amount, setAmount] = useState("");
  const [phone, setPhone] = useState("+7");
  const [bank, setBank] = useState(banks[0] ?? "Другой");

  const bankOptions = banks.map((b) => ({ value: b, label: b }));
  const value = Number(amount) || 0;
  const fee = Math.ceil((value * WITHDRAW_FEE_PERCENT) / 100);
  const error =
    value > 0 && value < WITHDRAW_MIN_RUB
      ? `Минимальная сумма — ${WITHDRAW_MIN_RUB} ₽`
      : value > balance
        ? "Недостаточно средств на балансе"
        : null;
  const valid = value >= WITHDRAW_MIN_RUB && !error && isPhoneComplete(phone);

  const submit = () => {
    const r = useDataStore.getState().createWithdraw({ amountRub: value, phone, bankName: bank });
    if (!r.ok) return toast(r.error ?? "Не удалось создать заявку", "error");
    toast("Заявка на вывод создана", "success");
    close();
  };

  return (
    <div className="flex max-w-full flex-col gap-4">
      <div>
        <div className="mb-1.5 flex items-center justify-between gap-2">
          <label className="field-label !mb-0" htmlFor="wd-amount">
            Сумма, ₽ (мин. {WITHDRAW_MIN_RUB})
          </label>
          <button type="button" className="shrink-0 text-[12px] font-bold text-gold-dark" onClick={() => setAmount(String(Math.floor(balance)))}>
            Весь баланс · {formatRub(balance)}
          </button>
        </div>
        <input
          id="wd-amount"
          className="input !h-14 font-display !text-[24px] font-semibold"
          inputMode="numeric"
          value={amount}
          onChange={(e) => setAmount(e.target.value.replace(/\D/g, "").slice(0, 7))}
          placeholder="0"
        />
        {error && <p className="mt-1.5 text-[12px] font-semibold text-bad">{error}</p>}
      </div>

      <div>
        <label className="field-label" htmlFor="wd-phone">
          Телефон для СБП
        </label>
        <input id="wd-phone" className="input" inputMode="tel" value={phone} onChange={(e) => setPhone(maskPhone(e.target.value))} placeholder="+7 900 000-00-00" />
      </div>

      <div>
        <span className="field-label">Банк получателя</span>
        <ChipBar options={bankOptions} value={bank} onChange={setBank} />
      </div>

      <div className="card divide-y divide-line text-[14px]">
        <div className="flex justify-between gap-3 px-4 py-3">
          <span className="truncate text-mute">Комиссия {WITHDRAW_FEE_PERCENT}%</span>
          <span className="shrink-0 font-bold tabular-nums">{formatRub(fee)}</span>
        </div>
        <div className="flex justify-between gap-3 bg-sand/60 px-4 py-3">
          <span className="truncate font-bold">Вы получите</span>
          <span className="shrink-0 font-display text-[18px] font-bold tabular-nums">{formatRub(Math.max(0, value - fee))}</span>
        </div>
      </div>

      <button type="button" className="btn btn-primary w-full" disabled={!valid} onClick={submit}>
        Создать заявку
      </button>
      <p className="text-center text-[12px] text-mute">Выплата вручную через СБП после проверки администратором.</p>
    </div>
  );
});

export const WithdrawSheet = memo(function WithdrawSheet({ sheetKey, level }: Props) {
  const closeSheet = useUiStore((s) => s.closeSheet);
  const onClose = useCallback(() => closeSheet(sheetKey), [closeSheet, sheetKey]);
  return (
    <BottomSheet title="Вывод средств" level={level} onClose={onClose}>
      <WithdrawBody />
    </BottomSheet>
  );
});
