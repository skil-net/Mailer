import { memo, useCallback, useMemo, useState } from "react";
import { useShallow } from "zustand/react/shallow";
import { BottomSheet, useSheetClose } from "@/components/BottomSheet";
import { Avatar } from "@/components/Avatar";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { TOPICS, type Topic } from "@/lib/topics";
import { formatNum } from "@/lib/format";

const DESC_MAX = 200;

interface Props {
  sheetKey: number;
  level: number;
  mode: "edit" | "apply";
  groupId?: string;
}

const Body = memo(function Body({ mode, groupId }: { mode: "edit" | "apply"; groupId?: string }) {
  const close = useSheetClose();
  const toast = useUiStore((s) => s.toast);
  const groups = useDataStore(useShallow((s) => s.groups));
  const requests = useDataStore(useShallow((s) => s.partnerRequests));

  const candidates = useMemo(
    () => groups.filter((g) => !g.isPartner && !requests.some((r) => r.groupId === g.id && r.status === "pending")),
    [groups, requests]
  );
  const initial = groups.find((g) => g.id === groupId);

  const [selId, setSelId] = useState<string>(groupId ?? candidates[0]?.id ?? "");
  const group = groups.find((g) => g.id === selId);
  const [price, setPrice] = useState(initial && initial.partnerPriceRub ? String(initial.partnerPriceRub) : "");
  const [discount, setDiscount] = useState(initial ? String(initial.partnerDiscount) : "0");
  const [topic, setTopic] = useState<Topic>(initial?.topic ?? candidates[0]?.topic ?? "Другое");
  const [desc, setDesc] = useState(initial?.partnerDescription ?? "");

  const priceNum = Number(price) || 0;
  const discNum = Math.min(90, Number(discount) || 0);
  const valid = !!group && priceNum > 0;

  const onPickGroup = (id: string) => {
    setSelId(id);
    const g = groups.find((x) => x.id === id);
    if (g) setTopic(g.topic);
  };

  const save = () => {
    if (!group) return;
    const st = useDataStore.getState();
    if (mode === "edit") {
      st.updateGroup(group.id, { partnerPriceRub: priceNum, partnerDiscount: discNum, topic, partnerDescription: desc.trim() });
      toast("Изменения сохранены", "success");
    } else {
      st.submitPartnerRequest({ groupId: group.id, priceRub: priceNum, discount: discNum, topic, description: desc.trim() });
      toast("Заявка отправлена на рассмотрение", "success");
    }
    close();
  };

  if (mode === "apply" && candidates.length === 0) {
    return (
      <p className="py-8 text-center text-[14px] leading-relaxed text-mute">
        Нет доступных групп. Подключите группу при создании рассылки — затем сможете подать заявку.
      </p>
    );
  }

  return (
    <div className="flex max-w-full flex-col gap-4">
      {mode === "apply" ? (
        <div>
          <label className="field-label" htmlFor="pt-group">
            Группа
          </label>
          <select id="pt-group" className="input" value={selId} onChange={(e) => onPickGroup(e.target.value)}>
            {candidates.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name}
              </option>
            ))}
          </select>
        </div>
      ) : (
        group && (
          <div className="card flex items-center gap-3 p-3">
            <Avatar src={group.photoUrl} name={group.name} size={44} />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[15px] font-bold">{group.name}</div>
              <div className="truncate text-[12px] text-mute">{formatNum(group.subscriberCount)} участников</div>
            </div>
          </div>
        )
      )}

      <div className="grid grid-cols-2 gap-3">
        <div className="min-w-0">
          <label className="field-label" htmlFor="pt-price">
            Цена за рассылку, ₽
          </label>
          <input id="pt-price" className="input" inputMode="numeric" value={price} onChange={(e) => setPrice(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="0" />
        </div>
        <div className="min-w-0">
          <label className="field-label" htmlFor="pt-disc">
            Скидка, %
          </label>
          <input id="pt-disc" className="input" inputMode="numeric" value={discount} onChange={(e) => setDiscount(e.target.value.replace(/\D/g, "").slice(0, 2))} placeholder="0" />
        </div>
      </div>

      <div>
        <label className="field-label" htmlFor="pt-topic">
          Тематика
        </label>
        <select id="pt-topic" className="input" value={topic} onChange={(e) => setTopic(e.target.value as Topic)}>
          {TOPICS.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </select>
      </div>

      <div>
        <div className="mb-1.5 flex items-center justify-between gap-2">
          <label className="field-label !mb-0" htmlFor="pt-desc">
            Описание
          </label>
          <span className="shrink-0 text-[12px] font-semibold tabular-nums text-mute">
            {desc.length} / {DESC_MAX}
          </span>
        </div>
        <textarea id="pt-desc" className="input" rows={4} maxLength={DESC_MAX} value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Расскажите об аудитории сообщества" />
      </div>

      <button type="button" className="btn btn-primary w-full" disabled={!valid} onClick={save}>
        {mode === "edit" ? "Сохранить" : "Отправить заявку"}
      </button>
    </div>
  );
});

export const EditPartnerSheet = memo(function EditPartnerSheet({ sheetKey, level, mode, groupId }: Props) {
  const closeSheet = useUiStore((s) => s.closeSheet);
  const onClose = useCallback(() => closeSheet(sheetKey), [closeSheet, sheetKey]);
  return (
    <BottomSheet title={mode === "edit" ? "Партнёрская группа" : "Стать партнёром"} level={level} onClose={onClose}>
      <Body mode={mode} groupId={groupId} />
    </BottomSheet>
  );
});
