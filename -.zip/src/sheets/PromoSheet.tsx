import { memo, useCallback, useMemo, useState } from "react";
import { AlertCircle, CheckCircle2, Ticket } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { BottomSheet, useSheetClose } from "@/components/BottomSheet";
import { useAuthStore } from "@/store/useAuthStore";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { formatDateTime, formatRub } from "@/lib/format";
import { PROMO_CODE_MAX, normalizePromoCode } from "@/lib/promo";

interface Props {
  sheetKey: number;
  level: number;
}

interface Result {
  ok: boolean;
  text: string;
  amount?: string;
  code?: string;
}

const Body = memo(function Body() {
  const close = useSheetClose();
  const vkUserId = useAuthStore((s) => s.auth.vkId);
  const activations = useDataStore(useShallow((s) => s.promoActivations));
  const [code, setCode] = useState("");
  const [result, setResult] = useState<Result | null>(null);

  const history = useMemo(() => activations.slice(0, 10), [activations]);

  const redeem = () => {
    const r = useDataStore.getState().redeemPromoCode(code, vkUserId);
    if (r.ok) {
      setResult({ ok: true, text: "Сумма зачислена на баланс", amount: `+${formatRub(r.amountRub ?? 0)}`, code: normalizePromoCode(code) });
      setCode("");
    } else {
      setResult({ ok: false, text: r.error ?? "Не удалось активировать промокод" });
    }
  };

  return (
    <div className="flex max-w-full flex-col gap-4">
      {result?.ok ? (
        <div className="anim-pop card border-ok/30 bg-ok/5 p-5 text-center">
          <div className="mx-auto mb-3 flex size-14 items-center justify-center rounded-full bg-ok text-white">
            <CheckCircle2 size={30} strokeWidth={1.5} />
          </div>
          <div className="truncate font-display text-[32px] font-bold tabular-nums text-ok">{result.amount}</div>
          <div className="mt-1 truncate font-mono text-[15px] font-bold">{result.code}</div>
          <div className="mt-1 text-[13px] text-mute">{result.text}</div>
          <button type="button" className="btn btn-primary mt-5 w-full" onClick={close}>
            Готово
          </button>
        </div>
      ) : (
        <>
          <div>
            <label className="field-label" htmlFor="promo-input">
              Промокод
            </label>
            <input
              id="promo-input"
              className="input !h-14 font-mono !text-[22px] font-bold uppercase tracking-[0.12em]"
              value={code}
              maxLength={PROMO_CODE_MAX}
              onChange={(e) => {
                setCode(normalizePromoCode(e.target.value));
                setResult(null);
              }}
              onKeyDown={(e) => e.key === "Enter" && code && redeem()}
              placeholder="XXXX-XXXX"
              autoCapitalize="characters"
              autoComplete="off"
              autoCorrect="off"
              spellCheck={false}
            />
          </div>

          {result && !result.ok && (
            <div className="anim-fade-up flex items-start gap-2 rounded-2xl bg-bad/10 px-4 py-3 text-[13px] font-semibold text-bad">
              <AlertCircle size={18} strokeWidth={1.5} className="mt-0.5 shrink-0" />
              <span className="min-w-0">{result.text}</span>
            </div>
          )}

          <button type="button" className="btn btn-primary w-full" disabled={!code} onClick={redeem}>
            <Ticket size={20} strokeWidth={1.5} /> Активировать
          </button>
          <p className="text-center text-[12px] leading-relaxed text-mute">Сумма промокода зачисляется на баланс. Каждый промокод можно активировать один раз.</p>
        </>
      )}

      <section>
        <h3 className="section-title mb-2">Активированные</h3>
        <div className="card">
          {history.length === 0 ? (
            <p className="px-4 py-5 text-center text-[13px] text-mute">Вы ещё не активировали промокоды</p>
          ) : (
            history.map((a) => (
              <div key={a.id} className="flex h-14 items-center gap-3 overflow-hidden border-b border-line px-4 last:border-b-0">
                <Ticket size={20} strokeWidth={1.5} className="shrink-0 text-gold-dark" />
                <div className="min-w-0 flex-1">
                  <div className="truncate font-mono text-[14px] font-bold">{a.code}</div>
                  <div className="truncate text-[12px] text-mute">{formatDateTime(a.createdAt)}</div>
                </div>
                <span className="shrink-0 text-[14px] font-extrabold tabular-nums text-ok">+{formatRub(a.amountRub)}</span>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
});

export const PromoSheet = memo(function PromoSheet({ sheetKey, level }: Props) {
  const closeSheet = useUiStore((s) => s.closeSheet);
  const onClose = useCallback(() => closeSheet(sheetKey), [closeSheet, sheetKey]);
  return (
    <BottomSheet title="Промокод" level={level} onClose={onClose}>
      <Body />
    </BottomSheet>
  );
});
