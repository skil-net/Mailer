import { memo, useCallback } from "react";
import { CampaignWizard } from "@/components/CampaignWizard";
import { useUiStore } from "@/store/useUiStore";

interface Props {
  sheetKey: number;
  level: number;
  groupIds?: number[];
  partnerGroupId?: number;
  duplicateFrom?: string;
}

export const CampaignWizardSheet = memo(function CampaignWizardSheet({ sheetKey, level, groupIds, partnerGroupId, duplicateFrom }: Props) {
  const closeSheet = useUiStore((s) => s.closeSheet);
  const onClose = useCallback(() => closeSheet(sheetKey), [closeSheet, sheetKey]);
  return <CampaignWizard onClose={onClose} level={level} groupIds={groupIds} partnerGroupId={partnerGroupId} duplicateFrom={duplicateFrom} />;
});
