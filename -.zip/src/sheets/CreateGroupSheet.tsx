import { memo, useCallback, useState } from "react";
import { Loader2, ShieldCheck, Users } from "lucide-react";
import { BottomSheet, useSheetClose } from "@/components/BottomSheet";
import { Avatar } from "@/components/Avatar";
import { ChipBar } from "@/components/ChipBar";
import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { describeVkError, fetchGroupByToken, type GroupInfo } from "@/lib/vkApi";
import { TOPIC_OPTIONS, type Topic } from "@/lib/topics";
import { formatNum } from "@/lib/format";

interface Props {
  sheetKey: number;
  level: number;
}

const Body = memo(function Body() {
  const close = useSheetClose();
  const toast = useUiStore((s) => s.toast);
  const [token, setToken] = useState("");
  const [info, setInfo] = useState<GroupInfo | null>(null);
  const [topic, setTopic] = useState<Topic>("Другое");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const check = async () => {
    const t = token.trim();
    if (!t) return;
    setLoading(true);
    setError(null);
    try {
      setInfo(await fetchGroupByToken(t, true));
    } catch (e) {
      setInfo(null);
      setError(describeVkError(e));
    } finally {
      setLoading(false);
    }
  };

  const save = () => {
    if (!info) return;
    useDataStore.getState().addGroup({
      vkGroupId: info.vkGroupId,
      name: info.name,
      photoUrl: info.photoUrl,
      accessToken: token.trim(),
      tokenValid: true,
      topic,
      isPartner: false,
      partnerPriceRub: 0,
      partnerDiscount: 0,
      partnerDescription: "",
      subscriberCount: info.subscriberCount,
    });
    toast(`Группа «${info.name}» подключена`, "success");
    close();
  };

  return (
    <div className="flex max-w-full flex-col gap-4">
      <div>
        <label className="field-label" htmlFor="grp-token">
          Ключ доступа сообщества
        </label>
        <input
          id="grp-token"
          className="input"
          value={token}
          autoComplete="off"
          spellCheck={false}
          onChange={(e) => {
            setToken(e.target.value);
            setInfo(null);
            setError(null);
          }}
          placeholder="vk1.a.…"
        />
        <p className="mt-1.5 text-[12px] leading-relaxed text-mute">
          Управление сообществом → Работа с API → Ключи доступа. Нужны права на сообщения.
        </p>
      </div>

      {error && <div className="rounded-xl bg-bad/10 px-3 py-2 text-[13px] font-semibold text-bad">{error}</div>}

      {!info ? (
        <button type="button" className="btn btn-primary w-full" disabled={!token.trim() || loading} onClick={check}>
          {loading ? <Loader2 size={20} strokeWidth={1.5} className="animate-spin" /> : <ShieldCheck size={20} strokeWidth={1.5} />}
          Проверить токен
        </button>
      ) : (
        <div className="anim-fade-up flex flex-col gap-4">
          <div className="card flex items-center gap-3 p-3">
            <Avatar src={info.photoUrl} name={info.name} size={48} />
            <div className="min-w-0 flex-1">
              <div className="truncate text-[15px] font-bold">{info.name}</div>
              <div className="flex items-center gap-1 truncate text-[12px] text-mute">
                <Users size={13} strokeWidth={1.5} className="shrink-0" />
                {formatNum(info.subscriberCount)} участников
              </div>
            </div>
            <span className="badge bg-ok/15 text-ok">Токен верный</span>
          </div>
          <div>
            <span className="field-label">Тематика</span>
            <ChipBar options={TOPIC_OPTIONS} value={topic} onChange={setTopic} />
          </div>
          <button type="button" className="btn btn-primary w-full" onClick={save}>
            Подключить группу
          </button>
        </div>
      )}
    </div>
  );
});

export const CreateGroupSheet = memo(function CreateGroupSheet({ sheetKey, level }: Props) {
  const closeSheet = useUiStore((s) => s.closeSheet);
  const onClose = useCallback(() => closeSheet(sheetKey), [closeSheet, sheetKey]);
  return (
    <BottomSheet title="Подключить группу" level={level} onClose={onClose}>
      <Body />
    </BottomSheet>
  );
});
