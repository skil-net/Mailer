import { memo, useCallback, useMemo, useState } from "react";
import { AlertCircle, CheckCircle2, Copy, Landmark, Percent } from "lucide-react";
import { useShallow } from "zustand/react/shallow";
import { BottomSheet, useSheetClose } from "@/components/BottomSheet";
import { Timer } from "@/components/Timer";
import { TransactionRow } from "@/components/TransactionRow";
import { useDataStore, bestPromotion } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { bankColor } from "@/lib/banks";
import { formatRub, prettyPhone } from "@/lib/format";

const QUICK = [500, 1000, 5000];
const MIN_DEPOSIT = 100;

interface Props {
  sheetKey: number;
  level: number;
}

const DepositBody = memo(function DepositBody() {
  const close = useSheetClose();
  const settings = useDataStore((s) => s.settings);
  const promotions = useDataStore(useShallow((s) => s.promotions));
  const transactions = useDataStore(useShallow((s) => s.transactions));
  const toast = useUiStore((s) => s.toast);

  const [txId, setTxId] = useState<string | null>(() => {
    const now = Date.now();
    return useDataStore.getState().transactions.find((t) => t.type === "deposit" && t.status === "pending" && (t.timerExpiresAt ?? 0) > now)?.id ?? null;
  });
  const [amount, setAmount] = useState("1000");

  const tx = useMemo(() => transactions.find((t) => t.id === txId) ?? null, [transactions, txId]);
  const history = useMemo(() => transactions.filter((t) => t.type === "deposit").slice(0, 8), [transactions]);
  const value = Number(amount.replace(/\D/g, "")) || 0;
  const promo = useMemo(() => bestPromotion(promotions, value), [promotions, value]);

  const proceed = () => {
    if (value < MIN_DEPOSIT) return toast(`Минимальная сумма — ${MIN_DEPOSIT} ₽`, "error");
    setTxId(useDataStore.getState().createDeposit(value).id);
  };

  const onExpire = useCallback(() => {
    if (txId) useDataStore.getState().expireTransaction(txId);
  }, [txId]);

  const paid = () => {
    if (!tx) return;
    if (!useDataStore.getState().markPaid(tx.id)) toast("Время оплаты истекло", "error");
  };

  const copy = (text: string) => {
    void navigator.clipboard?.writeText(text).then(
      () => toast("Скопировано", "success"),
      () => toast("Не удалось скопировать", "error")
    );
  };

  const history_ = history.length > 0 && (
    <section className="mt-6">
      <h3 className="section-title mb-2">История пополнений</h3>
      <div className="card">
        {history.map((t) => (
          <TransactionRow key={t.id} tx={t} />
        ))}
      </div>
    </section>
  );

  /* 1. ввод суммы */
  if (!tx) {
    return (
      <div className="max-w-full">
        <label className="field-label" htmlFor="dep-amount">
          Сумма пополнения, ₽
        </label>
        <input
          id="dep-amount"
          className="input !h-14 font-display !text-[24px] font-semibold"
          inputMode="numeric"
          value={amount}
          onChange={(e) => setAmount(e.target.value.replace(/\D/g, "").slice(0, 7))}
          placeholder="0"
        />
        <div className="scrollbar-hidden mt-3 flex gap-2 overflow-x-auto">
          {QUICK.map((q) => (
            <button key={q} type="button" className="chip" data-active={value === q} onClick={() => setAmount(String(q))}>
              {formatRub(q)}
            </button>
          ))}
        </div>

        {promo && (
          <div className="anim-fade-up mt-4 flex items-center gap-2 rounded-2xl bg-gold/15 px-4 py-3 text-[13px] font-bold text-gold-dark">
            <Percent size={18} strokeWidth={1.5} className="shrink-0" />
            <span className="min-w-0 truncate">
              +{promo.bonusPercent}% к пополнению · {promo.title}
            </span>
          </div>
        )}

        <button type="button" className="btn btn-primary mt-5 w-full" disabled={value < MIN_DEPOSIT} onClick={proceed}>
          Продолжить
        </button>
        <p className="mt-2 text-center text-[12px] text-mute">Минимум {MIN_DEPOSIT} ₽. На оплату даётся {settings.paymentTimerMinutes} минут.</p>
        {history_}
      </div>
    );
  }

  const expired = tx.status === "expired";
  const awaiting = tx.status === "awaiting_confirmation";
  const bonus = tx.bonusPercent ?? 0;

  return (
    <div className="max-w-full">
      {bonus > 0 && !expired && (
        <div className="mb-3 flex items-center gap-2 rounded-2xl bg-gold/15 px-4 py-3 text-[13px] font-bold text-gold-dark">
          <Percent size={18} strokeWidth={1.5} className="shrink-0" />
          <span className="min-w-0 truncate">+{bonus}% к пополнению</span>
        </div>
      )}

      {tx.status === "confirmed" || tx.status === "rejected" ? (
        <div className="anim-fade-up rounded-2xl bg-sand px-4 py-4 text-center text-[14px] font-semibold">
          {tx.status === "confirmed" ? "Пополнение зачислено" : "Заявка отклонена"}
          <button type="button" className="btn btn-soft btn-sm mt-3 w-full" onClick={() => setTxId(null)}>
            Новая заявка
          </button>
        </div>
      ) : (
        <div className="card p-4">
          <div className="flex items-center justify-between gap-3">
            <span className="min-w-0 truncate text-[13px] font-semibold text-mute">{expired ? "Время вышло" : "Осталось на оплату"}</span>
            {tx.timerExpiresAt && !expired && !awaiting ? (
              <Timer expiresAt={tx.timerExpiresAt} onExpire={onExpire} className="shrink-0 text-[20px]" />
            ) : null}
          </div>

          <p className="mt-4 text-balance text-[16px] font-semibold leading-snug [overflow-wrap:anywhere]">
            Переведите <span className="whitespace-nowrap font-extrabold">{formatRub(tx.amountRub)}</span> на номер{" "}
            <span className="whitespace-nowrap font-extrabold">{prettyPhone(tx.phone ?? settings.depositPhone)}</span>
          </p>

          <div className="mt-3 flex items-center gap-2 rounded-2xl bg-sand px-3 py-3 text-[14px]">
            <Landmark size={20} strokeWidth={1.5} className="shrink-0" style={{ color: bankColor(tx.bankName) }} />
            <span className="shrink-0 text-mute">Банк:</span>
            <span className="min-w-0 flex-1 truncate font-bold" style={{ color: bankColor(tx.bankName) }}>
              {tx.bankName}
            </span>
          </div>

          <div className="mt-3">
            <div className="mb-1.5 text-[12px] font-semibold text-mute">В комментарии к переводу укажите:</div>
            <button
              type="button"
              onClick={() => copy(tx.id)}
              className="flex w-full min-w-0 items-center gap-2 rounded-2xl border border-dashed border-gold bg-gold/5 px-3 py-3 text-left transition-transform duration-150 active:scale-[0.97]"
            >
              <span className="min-w-0 flex-1 truncate font-mono text-[14px] font-bold">{tx.id}</span>
              <Copy size={18} strokeWidth={1.5} className="shrink-0 text-gold-dark" />
            </button>
          </div>
        </div>
      )}

      {expired && (
        <div className="anim-fade-up mt-3 flex items-start gap-2 rounded-2xl bg-bad/10 px-4 py-3 text-[13px] font-semibold text-bad">
          <AlertCircle size={18} strokeWidth={1.5} className="mt-0.5 shrink-0" />
          <span className="min-w-0">Время оплаты истекло. Создайте новую заявку</span>
        </div>
      )}

      {awaiting && (
        <div className="anim-fade-up mt-3 flex items-start gap-2 rounded-2xl bg-ok/10 px-4 py-3 text-[13px] font-semibold text-ok">
          <CheckCircle2 size={18} strokeWidth={1.5} className="mt-0.5 shrink-0" />
          <span className="min-w-0">Заявка отправлена. Админ подтвердит после проверки операции</span>
        </div>
      )}

      <div className="mt-4 flex flex-col gap-2">
        {!awaiting && tx.status !== "confirmed" && tx.status !== "rejected" && (
          <button type="button" className="btn btn-primary w-full" disabled={expired || tx.status !== "pending"} onClick={paid}>
            Я оплатил
          </button>
        )}
        {(expired || awaiting) && (
          <button type="button" className={`btn w-full ${expired ? "btn-soft" : "btn-outline"}`} onClick={() => (awaiting ? close() : setTxId(null))}>
            {expired ? "Создать новую заявку" : "Закрыть"}
          </button>
        )}
      </div>
      {history_}
    </div>
  );
});

export const DepositSheet = memo(function DepositSheet({ sheetKey, level }: Props) {
  const closeSheet = useUiStore((s) => s.closeSheet);
  const onClose = useCallback(() => closeSheet(sheetKey), [closeSheet, sheetKey]);
  return (
    <BottomSheet title="Пополнение" level={level} onClose={onClose}>
      <DepositBody />
    </BottomSheet>
  );
});
