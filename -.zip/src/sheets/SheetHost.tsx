import { memo } from "react";
import { useShallow } from "zustand/react/shallow";
import { useUiStore, type SheetEntry } from "@/store/useUiStore";
import { CampaignWizardSheet } from "./CampaignWizardSheet";
import { DepositSheet } from "./DepositSheet";
import { WithdrawSheet } from "./WithdrawSheet";
import { CreateGroupSheet } from "./CreateGroupSheet";
import { EditPartnerSheet } from "./EditPartnerSheet";
import { PromoSheet } from "./PromoSheet";

const SheetSwitch = memo(function SheetSwitch({ entry, level }: { entry: SheetEntry; level: number }) {
  switch (entry.type) {
    case "wizard":
      return <CampaignWizardSheet sheetKey={entry.key} level={level} groupIds={entry.groupIds} partnerGroupId={entry.partnerGroupId} duplicateFrom={entry.duplicateFrom} />;
    case "deposit":
      return <DepositSheet sheetKey={entry.key} level={level} />;
    case "withdraw":
      return <WithdrawSheet sheetKey={entry.key} level={level} />;
    case "createGroup":
      return <CreateGroupSheet sheetKey={entry.key} level={level} />;
    case "promo":
      return <PromoSheet sheetKey={entry.key} level={level} />;
    case "editPartner":
      return <EditPartnerSheet sheetKey={entry.key} level={level} mode={entry.mode} groupId={entry.groupId} />;
  }
});

/** Стек bottom sheet'ов: каждый следующий лист получает более высокий z-index (level). */
export const SheetHost = memo(function SheetHost() {
  const sheets = useUiStore(useShallow((s) => s.sheets));
  return (
    <>
      {sheets.map((s, i) => (
        <SheetSwitch key={s.key} entry={s} level={i} />
      ))}
    </>
  );
});
