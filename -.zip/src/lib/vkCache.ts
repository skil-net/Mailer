export const CACHE_TTL_MS = 24 * 60 * 60 * 1000;
export const PROFILE_CACHE_KEY = "vk-profile-cache";

interface Entry<T> {
  ts: number;
  data: T;
}

export function cacheGet<T>(key: string, ttl = CACHE_TTL_MS): T | null {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    const e = JSON.parse(raw) as Entry<T>;
    if (!e || typeof e.ts !== "number" || Date.now() - e.ts > ttl) {
      localStorage.removeItem(key);
      return null;
    }
    return e.data;
  } catch {
    return null;
  }
}

export function cacheSet<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify({ ts: Date.now(), data } satisfies Entry<T>));
  } catch {
    /* хранилище переполнено — кэш не критичен */
  }
}

export function cacheDel(key: string): void {
  try {
    localStorage.removeItem(key);
  } catch {
    /* noop */
  }
}

/** Лёгкий хэш, чтобы токен не лежал в имени ключа кэша. */
export function hashKey(s: string): string {
  let h = 5381;
  for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0;
  return (h >>> 0).toString(36);
}
