import type { Group, Settings } from "@/types";

export interface PriceLine {
  vkGroupId: number;
  name: string;
  priceRub: number;
  partner: boolean;
}

/** Цена партнёрской группы после скидки (без комиссии). */
export const partnerNetPrice = (g: Pick<Group, "partnerPriceRub" | "partnerDiscount">): number =>
  Math.max(0, g.partnerPriceRub * (1 - g.partnerDiscount / 100));

/** Итоговая цена партнёрской группы с комиссией сервиса. */
export const partnerFinalPrice = (g: Pick<Group, "partnerPriceRub" | "partnerDiscount">, commissionPercent: number): number =>
  Math.ceil(partnerNetPrice(g) * (1 + commissionPercent / 100));

export function calcCampaignPrice(
  groups: Group[],
  partnerGroupId: number | undefined,
  settings: Settings
): { total: number; lines: PriceLine[] } {
  const lines: PriceLine[] = groups.map((g) => {
    const partner = partnerGroupId !== undefined && g.vkGroupId === partnerGroupId && g.isPartner;
    return {
      vkGroupId: g.vkGroupId,
      name: g.name,
      partner,
      priceRub: partner
        ? partnerFinalPrice(g, settings.serviceCommissionPercent)
        : settings.baseCampaignPriceRub,
    };
  });
  return { total: lines.reduce((s, l) => s + l.priceRub, 0), lines };
}
