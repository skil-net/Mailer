import { cacheDel, cacheGet, cacheSet, hashKey, PROFILE_CACHE_KEY } from "./vkCache";
import { randomId32 } from "./id";
import { initials } from "./format";
import { excludeReasonFromConversation } from "./exclusion";
import type { ExcludeReason, Group, Profile, Sex } from "@/types";

const API = "https://api.vk.com/method/";
const VERSION = "5.199";
export const VK_ADMIN_ID = 494048514;
const SERVICE_TOKEN = (import.meta.env.VITE_VK_SERVICE_TOKEN as string | undefined) ?? "";

export const VK_NETWORK = -1;
export const VK_TIMEOUT = -2;
export const VK_NO_TOKEN = -3;
export const VK_HTTP = -4;

export class VkError extends Error {
  code: number;
  constructor(code: number, message: string) {
    super(message);
    this.name = "VkError";
    this.code = code;
  }
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

class RateLimiter {
  private next = 0;
  constructor(private interval: number) {}
  async wait(): Promise<void> {
    const now = Date.now();
    const at = Math.max(now, this.next);
    this.next = at + this.interval;
    if (at > now) await sleep(at - now);
  }
}

const conversationsLimiter = new RateLimiter(334); // 3 req/s
const sendLimiter = new RateLimiter(50); // 20 req/s

type Params = Record<string, string | number | undefined>;

function jsonp<T>(url: string, timeout: number): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const cb = `__vk_cb_${randomId32().toString(36)}`;
    const w = window as unknown as Record<string, unknown>;
    const script = document.createElement("script");
    const cleanup = () => {
      clearTimeout(timer);
      delete w[cb];
      script.remove();
    };
    const timer = setTimeout(() => {
      cleanup();
      reject(new VkError(VK_TIMEOUT, "Превышено время ожидания"));
    }, timeout);
    w[cb] = (data: T) => {
      cleanup();
      resolve(data);
    };
    script.onerror = () => {
      cleanup();
      reject(new VkError(VK_NETWORK, "Сеть недоступна"));
    };
    script.src = `${url}&callback=${cb}`;
    document.head.appendChild(script);
  });
}

async function request<T>(method: string, params: Params, token: string, timeout: number): Promise<T> {
  if (!token) throw new VkError(VK_NO_TOKEN, "Не задан токен");
  const body = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) if (v !== undefined && v !== "") body.set(k, String(v));
  body.set("v", VERSION);
  body.set("access_token", token);

  const started = Date.now();
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeout);
  let json: { response?: unknown; error?: { error_code: number; error_msg: string } };
  try {
    const res = await fetch(API + method, { method: "POST", body, signal: ctrl.signal });
    if (!res.ok) throw new VkError(VK_HTTP, `HTTP ${res.status}`);
    json = await res.json();
  } catch (e) {
    if (e instanceof VkError) throw e;
    if (ctrl.signal.aborted) throw new VkError(VK_TIMEOUT, "Превышено время ожидания");
    // Браузерные ограничения CORS: пробуем JSONP-транспорт
    const url = `${API}${method}?${body.toString()}`;
    const left = timeout - (Date.now() - started);
    if (url.length > 7500 || left < 300) throw new VkError(VK_NETWORK, "Сеть недоступна");
    json = await jsonp(url, left);
  } finally {
    clearTimeout(timer);
  }
  if (json?.error) throw new VkError(json.error.error_code, json.error.error_msg);
  return json.response as T;
}

/* ───────── users.get — профиль @samadluk (кэш 24ч, таймаут 5с) ───────── */

interface VkUser {
  id: number;
  first_name: string;
  last_name: string;
  photo_200?: string;
  photo_100?: string;
  screen_name?: string;
  sex?: number;
  /** banned / deleted — страница заблокирована или удалена */
  deactivated?: string;
}

export function invalidateProfileCache(): void {
  cacheDel(PROFILE_CACHE_KEY);
}

export function readCachedProfile(): Profile | null {
  return cacheGet<Profile>(PROFILE_CACHE_KEY);
}

export async function fetchAdminProfile(force = false): Promise<Profile> {
  if (!force) {
    const cached = readCachedProfile();
    if (cached) return cached;
  }
  const res = await request<VkUser[]>(
    "users.get",
    { user_ids: VK_ADMIN_ID, fields: "photo_200,photo_100,screen_name" },
    SERVICE_TOKEN,
    5000
  );
  const u = Array.isArray(res) ? res[0] : undefined;
  if (!u) throw new VkError(0, "Пустой ответ VK");
  const profile: Profile = {
    firstName: u.first_name,
    lastName: u.last_name,
    photo200: u.photo_200 ?? u.photo_100 ?? null,
    screenName: u.screen_name || "samadluk",
    monogram: initials(u.first_name, u.last_name),
  };
  cacheSet(PROFILE_CACHE_KEY, profile);
  return profile;
}

/* ───────── groups.getById — валидация токена группы (кэш 24ч) ───────── */

export interface GroupInfo {
  vkGroupId: number;
  name: string;
  photoUrl: string | null;
  subscriberCount: number;
}

interface VkGroup {
  id: number;
  name: string;
  photo_100?: string;
  photo_200?: string;
  members_count?: number;
}

export async function fetchGroupByToken(token: string, force = false): Promise<GroupInfo> {
  const key = `vk-cache:group:${hashKey(token)}`;
  if (!force) {
    const cached = cacheGet<GroupInfo>(key);
    if (cached) return cached;
  }
  const res = await request<VkGroup[] | { groups?: VkGroup[] }>(
    "groups.getById",
    { fields: "members_count" },
    token,
    15000
  );
  const g = Array.isArray(res) ? res[0] : res?.groups?.[0];
  if (!g) throw new VkError(0, "Токен не относится к сообществу");
  const info: GroupInfo = {
    vkGroupId: g.id,
    name: g.name,
    photoUrl: g.photo_100 ?? g.photo_200 ?? null,
    subscriberCount: g.members_count ?? 0,
  };
  cacheSet(key, info);
  return info;
}

/* ───────── messages.getConversations — сбор базы (без кэша, 3 req/s) ───────── */

export interface RawSubscriber {
  vkUserId: number;
  firstName: string;
  lastName: string;
  screenName?: string;
  sex: Sex;
  photo100: string | null;
  lastMessageAt: number;
  /** Причина, по которой получатель не учитывается в базе; null — отправлять можно */
  excluded: ExcludeReason | null;
}

interface CanWrite {
  allowed?: boolean;
  reason?: number;
}

interface ConversationsResponse {
  count: number;
  items: Array<{
    conversation?: { peer?: { id: number; type: string }; can_write?: CanWrite };
    last_message?: { date: number };
  }>;
  profiles?: VkUser[];
}

const MAX_PAGES = 50;

export async function collectBase(group: Pick<Group, "accessToken">): Promise<RawSubscriber[]> {
  const map = new Map<number, RawSubscriber>();
  let offset = 0;
  for (let page = 0; page < MAX_PAGES; page++) {
    await conversationsLimiter.wait();
    const res = await request<ConversationsResponse>(
      "messages.getConversations",
      { count: 200, offset, extended: 1, fields: "photo_100,sex,screen_name" },
      group.accessToken,
      15000
    );
    const profiles = new Map<number, VkUser>((res.profiles ?? []).map((p) => [p.id, p]));
    for (const it of res.items ?? []) {
      const conv = it.conversation;
      const peer = conv?.peer;
      if (!peer || peer.id > 2000000000 || peer.id <= 0 || peer.type !== "user") continue; // пропускаем беседы
      if (map.has(peer.id)) continue;
      const p = profiles.get(peer.id);
      map.set(peer.id, {
        vkUserId: peer.id,
        firstName: p?.first_name ?? "",
        lastName: p?.last_name ?? "",
        screenName: p?.screen_name,
        sex: (p?.sex === 1 || p?.sex === 2 ? p.sex : 0) as Sex,
        photo100: p?.photo_100 ?? null,
        lastMessageAt: (it.last_message?.date ?? 0) * 1000,
        // закрыл сообщения, в чёрном списке, заблокирован или удалён — не учитываем в базе
        excluded: excludeReasonFromConversation(conv?.can_write, p?.deactivated),
      });
    }
    offset += 200;
    if (!res.items || res.items.length < 200 || offset >= (res.count ?? 0)) break;
  }
  return [...map.values()];
}

/* ───────── messages.send — отправка (20 req/s, ошибки 6/9/900/901/902) ───────── */

export interface SendParams {
  token: string;
  userId: number;
  message: string;
  attachment?: string;
  keyboard?: string;
}

export const VK_ERR_TOO_MANY = 6;
export const VK_ERR_FLOOD = 9;
export const VK_ERR_DELETED = 18;
export const VK_ERR_AUTH = 5;
export const VK_ERR_BLACKLIST = 900;
export const VK_ERR_DENIED = 901;
export const VK_ERR_PRIVACY = 902;

export async function sendMessage(p: SendParams): Promise<number> {
  await sendLimiter.wait();
  return request<number>(
    "messages.send",
    {
      user_id: p.userId,
      random_id: randomId32(),
      message: p.message,
      attachment: p.attachment,
      keyboard: p.keyboard,
    },
    p.token,
    15000
  );
}

export function describeVkError(e: unknown): string {
  if (e instanceof VkError) {
    switch (e.code) {
      case VK_ERR_TOO_MANY:
        return "Слишком много запросов — повторите позже";
      case VK_ERR_FLOOD:
        return "Достигнут лимит сообщений VK (flood control)";
      case VK_ERR_DELETED:
        return "Страница получателя заблокирована или удалена";
      case VK_ERR_BLACKLIST:
        return "Получатель в чёрном списке сообщества";
      case VK_ERR_DENIED:
        return "Получатель запретил сообщения от сообщества";
      case VK_ERR_PRIVACY:
        return "Получатель закрыл сообщения настройками приватности";
      case VK_ERR_AUTH:
        return "Токен недействителен";
      case VK_TIMEOUT:
        return "Превышено время ожидания ответа VK";
      case VK_NETWORK:
        return "Нет соединения с VK";
      case VK_NO_TOKEN:
        return "Не задан токен";
      default:
        return e.message || "Ошибка VK API";
    }
  }
  return "Неизвестная ошибка";
}
