import { useDataStore } from "@/store/useDataStore";
import { useUiStore } from "@/store/useUiStore";
import { genId } from "@/lib/id";
import { renderTemplate } from "@/lib/template";
import { isMediaAttachment } from "@/lib/attachments";
import { excludeReasonFromCode } from "@/lib/exclusion";
import {
  collectBase,
  describeVkError,
  sendMessage,
  VkError,
  VK_ERR_AUTH,
  VK_ERR_FLOOD,
  VK_ERR_TOO_MANY,
} from "@/lib/vkApi";
import type { Campaign, GroupStat, OutboxItem, Subscriber, TargetSex } from "@/types";

interface Controller {
  abort: boolean;
}
const controllers = new Map<string, Controller>();
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** База диалогов считается устаревшей через сутки — перед отправкой она пересобирается */
const BASE_TTL_MS = 24 * 60 * 60 * 1000;

export const isRunning = (id: string) => controllers.has(id);

/** Получатели группы: с согласием и без запрета на сообщения. Порядок детерминирован (для возобновления). */
export function recipientsOf(subs: Subscriber[], groupId: number, sex: TargetSex): Subscriber[] {
  const want = sex === "female" ? 1 : sex === "male" ? 2 : 0;
  return subs.filter((s) => s.groupId === groupId && s.consent && !s.excluded && (want === 0 || s.sex === want));
}

/** Оценка аудитории: по собранной базе, а при её отсутствии — по числу участников. */
export function estimateRecipients(
  subs: Subscriber[],
  group: { vkGroupId: number; subscriberCount: number },
  sex: TargetSex
): number {
  const has = subs.some((s) => s.groupId === group.vkGroupId);
  if (has) return recipientsOf(subs, group.vkGroupId, sex).length;
  return Math.round(group.subscriberCount * (sex === "all" ? 1 : 0.5));
}

export function pauseCampaign(id: string): void {
  const c = controllers.get(id);
  if (c) c.abort = true;
  else useDataStore.getState().patchCampaign(id, { status: "paused" });
}

/** Помечает прерванные перезагрузкой рассылки как приостановленные. */
export function recoverInterrupted(): void {
  const st = useDataStore.getState();
  for (const c of st.campaigns) if (c.status === "sending" && !controllers.has(c.id)) st.patchCampaign(c.id, { status: "paused" });
}

export interface StartResult {
  ok: boolean;
  needFunds?: number;
  error?: string;
}

export async function startCampaign(id: string): Promise<StartResult> {
  const store = useDataStore.getState();
  const c = store.campaigns.find((x) => x.id === id);
  if (!c) return { ok: false, error: "Рассылка не найдена" };
  if (controllers.has(id)) return { ok: true };

  if (!c.paid) {
    if (!store.spend(c.priceRub, `Рассылка «${c.title}»`)) return { ok: false, needFunds: c.priceRub - store.balance };
    store.patchCampaign(id, { paid: true });
  }
  const ctl: Controller = { abort: false };
  controllers.set(id, ctl);
  void run(id, ctl).finally(() => controllers.delete(id));
  return { ok: true };
}

/** Запускает запланированные рассылки, время которых наступило. */
export function runDueCampaigns(): void {
  const now = Date.now();
  for (const c of useDataStore.getState().campaigns) {
    if (c.status === "scheduled" && c.scheduledAt !== null && c.scheduledAt <= now) void startCampaign(c.id);
  }
}

function buildPayload(c: Campaign) {
  const media = c.attachments.filter((a) => isMediaAttachment(a.type)).map((a) => a.attachment);
  const links = c.attachments
    .filter((a) => !isMediaAttachment(a.type))
    .map((a) => (a.type === "artist" ? `https://vk.com/${a.attachment}` : a.attachment));
  return { attachment: media.join(","), links };
}

async function sendWithRetry(args: Parameters<typeof sendMessage>[0]): Promise<void> {
  for (let attempt = 1; ; attempt++) {
    try {
      await sendMessage(args);
      return;
    } catch (e) {
      if (e instanceof VkError && e.code === VK_ERR_TOO_MANY && attempt < 4) {
        await sleep(1100 * attempt);
        continue;
      }
      throw e;
    }
  }
}

async function run(id: string, ctl: Controller): Promise<void> {
  const get = () => useDataStore.getState();
  const initial = get().campaigns.find((c) => c.id === id);
  if (!initial) return;

  const stats: Record<number, GroupStat> = {};
  for (const gid of initial.groupIds) stats[gid] = { ...(initial.groupStats[gid] ?? { total: 0, sent: 0, failed: 0 }) };
  let sentCount = initial.sentCount;
  let failedCount = initial.failedCount;
  let excludedCount = initial.excludedCount ?? 0;
  let lastError: string | undefined;
  let buffer: OutboxItem[] = [];

  const commit = () => {
    const totalCount = Object.values(stats).reduce((s, x) => s + x.total, 0);
    const copy: Record<number, GroupStat> = {};
    for (const [k, v] of Object.entries(stats)) copy[Number(k)] = { ...v };
    get().pushOutbox(buffer);
    buffer = [];
    get().patchCampaign(id, { sentCount, failedCount, totalCount, groupStats: copy, lastError, excludedCount });
  };

  get().patchCampaign(id, { status: "sending", lastError: undefined });
  const { attachment, links } = buildPayload(initial);
  let stopped = false;

  outer: for (const gid of initial.groupIds) {
    const group = get().groups.find((g) => g.vkGroupId === gid);
    if (!group || group.blocked || !group.tokenValid) {
      lastError = group?.blocked ? "Группа заблокирована" : "Токен группы недействителен";
      continue;
    }

    // База собирается перед первой отправкой в группу и обновляется раз в сутки:
    // так получатели, закрывшие сообщения, отсеиваются заранее, а не в момент отправки.
    const untouched = stats[gid].sent + stats[gid].failed === 0;
    const hasBase = get().subscribers.some((s) => s.groupId === gid);
    const fresh = !!group.baseUpdatedAt && Date.now() - group.baseUpdatedAt < BASE_TTL_MS;
    if (untouched && (!hasBase || !fresh)) {
      try {
        get().applyCollectedBase(gid, await collectBase(group));
      } catch (e) {
        if (!hasBase) {
          lastError = `${group.name}: ${describeVkError(e)}`;
          if (e instanceof VkError && e.code === VK_ERR_AUTH) get().updateGroup(group.id, { tokenValid: false });
          continue;
        }
        lastError = `${group.name}: база не обновлена — используется собранная ранее`;
      }
      if (ctl.abort) {
        stopped = true;
        break outer;
      }
    }

    const recipients = recipientsOf(get().subscribers, gid, initial.targetSex);
    stats[gid].total = recipients.length;
    commit();

    for (let i = stats[gid].sent + stats[gid].failed; i < recipients.length; i++) {
      if (ctl.abort) {
        stopped = true;
        break outer;
      }
      const sub = recipients[i];
      const rendered = renderTemplate(initial.messageText, {
        firstName: sub.firstName,
        lastName: sub.lastName,
        screenName: sub.screenName,
        userId: sub.vkUserId,
        sex: sub.sex,
        groupName: group.name,
      });
      const text = [rendered, ...links].filter(Boolean).join("\n");
      const item: OutboxItem = {
        id: genId("out", 6),
        campaignId: id,
        groupId: gid,
        vkUserId: sub.vkUserId,
        status: "sent",
        renderedText: text,
        sentAt: Date.now(),
      };
      try {
        await sendWithRetry({
          token: group.accessToken,
          userId: sub.vkUserId,
          message: text,
          attachment: attachment || undefined,
          keyboard: initial.keyboardJson || undefined,
        });
        stats[gid].sent++;
        sentCount++;
      } catch (e) {
        item.status = "failed";
        item.error = describeVkError(e);
        const vkCode = e instanceof VkError ? e.code : 0;
        if (vkCode === VK_ERR_FLOOD) {
          // лимит сообщений VK: останавливаем, при продолжении этот получатель будет повторён
          lastError = describeVkError(e);
          stopped = true;
          buffer.push(item);
          commit();
          break outer;
        }
        if (vkCode === VK_ERR_AUTH) {
          // токен группы недействителен — эту группу пропускаем
          get().updateGroup(group.id, { tokenValid: false });
          lastError = `${group.name}: ${describeVkError(e)}`;
          stats[gid].failed++;
          failedCount++;
          buffer.push(item);
          commit();
          continue outer;
        }
        const reason = excludeReasonFromCode(vkCode);
        if (reason) {
          // получить сообщение нельзя (запрет, приватность, чёрный список, блокировка):
          // исключаем из базы и убираем из аудитории кампании
          get().excludeSubscriber(gid, sub.vkUserId, reason);
          stats[gid].total = Math.max(0, stats[gid].total - 1);
          excludedCount++;
        } else {
          stats[gid].failed++;
          failedCount++;
        }
      }
      buffer.push(item);
      if (buffer.length >= 5) commit();
    }
    commit();
  }

  commit();
  const finalStatus: Campaign["status"] = stopped
    ? "paused"
    : sentCount > 0 || (failedCount === 0 && !lastError)
      ? "sent"
      : "failed";
  get().patchCampaign(id, { status: finalStatus });
  const title = initial.title;
  useUiStore
    .getState()
    .toast(
      finalStatus === "sent"
        ? `Рассылка «${title}» завершена`
        : finalStatus === "paused"
          ? `Рассылка «${title}» приостановлена`
          : `Рассылка «${title}» не доставлена`,
      finalStatus === "sent" ? "success" : "error"
    );
}
