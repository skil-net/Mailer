export type AttachmentType =
  | "photo"
  | "video"
  | "wall"
  | "doc"
  | "audio"
  | "poll"
  | "link"
  | "market"
  | "artist";

export interface ParsedAttachment {
  type: AttachmentType;
  attachment: string;
  previewUrl: string;
  label: string;
}

export const ATTACHMENT_TITLES: Record<AttachmentType, string> = {
  photo: "Фото",
  video: "Видео",
  wall: "Запись",
  doc: "Документ",
  audio: "Аудио",
  poll: "Опрос",
  link: "Ссылка",
  market: "Товар",
  artist: "Исполнитель",
};

const VK_HOST = /(^|\.)(vk\.com|vk\.ru|vkvideo\.ru|vk\.cc)$/i;
const OBJECT_RE = /(photo|video|clip|wall|doc|audio|poll|market|product)(-?\d+)_(\d+)/i;
const DIRECT_RE = /^(photo|video|clip|wall|doc|audio|poll|market|product)(-?\d+_\d+)(?:_[a-z0-9]+)?$/i;

function normalizeType(t: string): AttachmentType {
  const l = t.toLowerCase();
  if (l === "clip") return "video";
  if (l === "product") return "market";
  return l as AttachmentType;
}

function build(type: AttachmentType, ids: string): ParsedAttachment {
  const attachment = `${type}${ids}`;
  return {
    type,
    attachment,
    previewUrl: `https://vk.com/${attachment}`,
    label: `${ATTACHMENT_TITLES[type]} ${ids}`,
  };
}

/**
 * Разбирает ссылку или «сырое» вложение VK. Возвращает null, если формат не распознан.
 */
export function parseAttachment(input: string): ParsedAttachment | null {
  const raw = (input ?? "").trim();
  if (!raw || /\s/.test(raw)) return null;

  const direct = raw.match(DIRECT_RE);
  if (direct) return build(normalizeType(direct[1]), direct[2]);

  let candidate = raw;
  if (!/^https?:\/\//i.test(candidate)) {
    if (/^[\w-]+(\.[\w-]+)+(\/|$)/.test(candidate)) candidate = "https://" + candidate;
    else return null;
  }

  let url: URL;
  try {
    url = new URL(candidate);
  } catch {
    return null;
  }
  if (!/^https?:$/.test(url.protocol) || !url.hostname.includes(".")) return null;

  if (VK_HOST.test(url.hostname.replace(/^m\./i, ""))) {
    let hay = url.pathname + url.search;
    try {
      hay = decodeURIComponent(hay);
    } catch {
      /* оставляем как есть */
    }
    const artist = hay.match(/\/artist\/([\w.\-%]+)/i);
    if (artist) {
      return {
        type: "artist",
        attachment: `artist/${artist[1]}`,
        previewUrl: `https://vk.com/artist/${artist[1]}`,
        label: `${ATTACHMENT_TITLES.artist} ${artist[1]}`,
      };
    }
    const m = hay.match(OBJECT_RE);
    if (m) return build(normalizeType(m[1]), `${m[2]}_${m[3]}`);
  }

  const short = (url.hostname + url.pathname).replace(/\/$/, "");
  return {
    type: "link",
    attachment: url.toString(),
    previewUrl: url.toString(),
    label: short.length > 48 ? short.slice(0, 47) + "…" : short,
  };
}

/** Типы, которые уходят в messages.send как media-attachment. Остальные — ссылкой в тексте. */
export const isMediaAttachment = (t: AttachmentType) => t !== "link" && t !== "artist";
