import type { PromoCode } from "@/types";
import { formatDate } from "./format";

export const PROMO_CODE_MIN = 3;
export const PROMO_CODE_MAX = 24;

// без похожих символов (O/0, I/1, Л-подобных)
const ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";

export type PromoStatusKey = "active" | "disabled" | "expired" | "exhausted";

export interface PromoStatus {
  key: PromoStatusKey;
  label: string;
  cls: string;
}

/** Приводит ввод к формату промокода: заглавные латиница и цифры, «-» и «_». */
export function normalizePromoCode(input: string): string {
  return (input ?? "").toUpperCase().replace(/[^A-Z0-9_-]/g, "").slice(0, PROMO_CODE_MAX);
}

export const promoCodeValid = (code: string): boolean => /^[A-Z0-9_-]{3,24}$/.test(code);

/** Случайный код вида RS-7K3M-9QFX */
export function generatePromoCode(): string {
  const arr = new Uint8Array(8);
  crypto.getRandomValues(arr);
  let body = "";
  for (let i = 0; i < arr.length; i++) body += ALPHABET[arr[i] % ALPHABET.length];
  return `RS-${body.slice(0, 4)}-${body.slice(4)}`;
}

export function promoStatus(c: PromoCode, now = Date.now()): PromoStatus {
  if (!c.active) return { key: "disabled", label: "Отключён", cls: "bg-sand text-mute" };
  if (c.expiresAt !== null && c.expiresAt < now) return { key: "expired", label: "Истёк", cls: "bg-bad/10 text-bad" };
  if (c.maxActivations > 0 && c.activatedCount >= c.maxActivations)
    return { key: "exhausted", label: "Лимит исчерпан", cls: "bg-gold/20 text-gold-dark" };
  return { key: "active", label: "Активен", cls: "bg-ok/15 text-ok" };
}

export const activationsLabel = (c: PromoCode): string =>
  c.maxActivations > 0 ? `${c.activatedCount} / ${c.maxActivations}` : `${c.activatedCount} / ∞`;

export const promoExpiryLabel = (c: PromoCode): string => (c.expiresAt ? `До ${formatDate(c.expiresAt)}` : "Без срока");
