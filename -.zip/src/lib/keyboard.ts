import type { KeyboardKind } from "@/types";

export type KbType = "text" | "callback" | "open_link";
export type KbColor = "primary" | "secondary" | "negative" | "positive";

export interface KbButton {
  row: number;
  col: number;
  label: string;
  type: KbType;
  payload: string;
  url: string;
  color: KbColor;
}

export const KB_COLS = 5;
export const KB_MAX_ROWS = 10;
export const KB_INLINE_MAX_BUTTONS = 6;
export const KB_LABEL_MAX = 40;

export const KB_COLOR_LABELS: Record<KbColor, string> = {
  primary: "Синяя",
  secondary: "Серая",
  negative: "Красная",
  positive: "Зелёная",
};

export const KB_COLOR_HEX: Record<KbColor, { bg: string; fg: string }> = {
  primary: { bg: "#5181B8", fg: "#FFFFFF" },
  secondary: { bg: "#E8E4DC", fg: "#2B2622" },
  negative: { bg: "#C0392B", fg: "#FFFFFF" },
  positive: { bg: "#3E8E5A", fg: "#FFFFFF" },
};

export const KB_TYPE_LABELS: Record<KbType, string> = {
  text: "Текст",
  callback: "Callback",
  open_link: "Ссылка",
};

export function emptyButton(row: number, col: number): KbButton {
  return { row, col, label: "", type: "text", payload: "", url: "", color: "secondary" };
}

export function groupRows(buttons: KbButton[]): KbButton[][] {
  const rows = new Map<number, KbButton[]>();
  for (const b of buttons) {
    if (!rows.has(b.row)) rows.set(b.row, []);
    rows.get(b.row)!.push(b);
  }
  return [...rows.entries()]
    .sort((a, b) => a[0] - b[0])
    .map(([, list]) => list.sort((a, b) => a.col - b.col));
}

function toPayload(raw: string): string {
  const v = raw.trim();
  if (!v) return JSON.stringify({ button: "1" });
  try {
    JSON.parse(v);
    return v;
  } catch {
    return JSON.stringify({ button: v });
  }
}

export function validateKeyboard(buttons: KbButton[], kind: KeyboardKind): string | null {
  if (!buttons.length) return null;
  if (kind === "inline" && buttons.length > KB_INLINE_MAX_BUTTONS)
    return `Inline-клавиатура — не более ${KB_INLINE_MAX_BUTTONS} кнопок`;
  for (const b of buttons) {
    if (!b.label.trim()) return "У каждой кнопки должен быть текст";
    if (b.type === "open_link" && !/^https?:\/\//i.test(b.url.trim())) return "Для кнопки-ссылки укажите URL с http(s)://";
  }
  return null;
}

/** JSON клавиатуры VK. Пустая строка, если кнопок нет или клавиатура невалидна. */
export function buildKeyboardJson(buttons: KbButton[], kind: KeyboardKind): string {
  if (!buttons.length || validateKeyboard(buttons, kind)) return "";
  const rows = groupRows(buttons).map((row) =>
    row.map((b) => {
      const label = b.label.trim().slice(0, KB_LABEL_MAX);
      if (b.type === "open_link") return { action: { type: "open_link", label, link: b.url.trim() } };
      return {
        action: { type: b.type, label, payload: toPayload(b.payload) },
        color: b.color,
      };
    })
  );
  return JSON.stringify(
    kind === "inline" ? { inline: true, buttons: rows } : { one_time: true, inline: false, buttons: rows }
  );
}

export function parseKeyboardJson(json: string): { kind: KeyboardKind; buttons: KbButton[] } {
  const fallback = { kind: "inline" as KeyboardKind, buttons: [] as KbButton[] };
  if (!json) return fallback;
  try {
    const data = JSON.parse(json) as {
      inline?: boolean;
      buttons?: Array<Array<{ action: { type: KbType; label: string; payload?: string; link?: string }; color?: KbColor }>>;
    };
    const buttons: KbButton[] = [];
    (data.buttons ?? []).forEach((row, r) =>
      row.forEach((b, c) => {
        let payload = b.action.payload ?? "";
        try {
          const o = JSON.parse(payload) as { button?: string };
          if (o && typeof o === "object" && typeof o.button === "string") payload = o.button;
        } catch {
          /* raw */
        }
        buttons.push({
          row: r,
          col: c,
          label: b.action.label,
          type: b.action.type,
          payload,
          url: b.action.link ?? "",
          color: b.color ?? "secondary",
        });
      })
    );
    return { kind: data.inline ? "inline" : "one_time", buttons };
  } catch {
    return fallback;
  }
}
