import type { ExcludeReason } from "@/types";

export interface ExcludeMeta {
  /** Короткая подпись для бейджа в списке */
  label: string;
  /** Полное пояснение */
  detail: string;
}

export const EXCLUDE_META: Record<ExcludeReason, ExcludeMeta> = {
  no_permission: { label: "Запретил сообщения", detail: "Запретил сообщения от сообщества" },
  privacy: { label: "Закрыт приватностью", detail: "Сообщения закрыты настройками приватности" },
  blacklisted: { label: "В чёрном списке", detail: "Внесён в чёрный список сообщества" },
  blocked: { label: "Заблокирован", detail: "Страница заблокирована или удалена" },
  unavailable: { label: "Недоступен", detail: "Отправка сообщений недоступна" },
};

/**
 * Коды VK, после которых получатель не учитывается в базе.
 * Они же приходят в conversation.can_write.reason из messages.getConversations.
 */
const CODE_TO_REASON: Record<number, ExcludeReason> = {
  18: "blocked",
  900: "blacklisted",
  901: "no_permission",
  902: "privacy",
  915: "unavailable",
  916: "unavailable",
  917: "unavailable",
  918: "unavailable",
  203: "unavailable",
};

export function excludeReasonFromCode(code: number): ExcludeReason | null {
  return CODE_TO_REASON[code] ?? null;
}

/** Оценка диалога из messages.getConversations: можно ли писать пользователю. */
export function excludeReasonFromConversation(
  canWrite: { allowed?: boolean; reason?: number } | undefined | null,
  deactivated?: string
): ExcludeReason | null {
  if (deactivated) return "blocked";
  if (!canWrite || canWrite.allowed !== false) return null;
  return excludeReasonFromCode(canWrite.reason ?? 0) ?? "no_permission";
}
