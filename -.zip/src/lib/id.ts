export type IdPrefix = "cmp" | "sub" | "txn" | "grp" | "out" | "prm" | "req" | "pmt" | "act";

/** Криптостойкий hex-идентификатор вида prefix_xxxxxxxxxxxxxxxx */
export function genId(prefix: IdPrefix, bytes = 8): string {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  let hex = "";
  for (let i = 0; i < arr.length; i++) hex += arr[i].toString(16).padStart(2, "0");
  return `${prefix}_${hex}`;
}

/** Положительный int32 для messages.send random_id */
export function randomId32(): number {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return arr[0] & 0x7fffffff;
}
