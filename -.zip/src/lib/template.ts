export interface TemplateContext {
  firstName?: string;
  lastName?: string;
  screenName?: string;
  userId?: number | string;
  sex?: number;
  groupName?: string;
}

export interface PlaceholderInfo {
  key: string;
  token: string;
  hint: string;
}

export const PLACEHOLDERS: ReadonlyArray<PlaceholderInfo> = [
  { key: "name", token: "{name}", hint: "Полное имя: имя и фамилия получателя" },
  { key: "first_name", token: "{first_name}", hint: "Только имя получателя" },
  { key: "last_name", token: "{last_name}", hint: "Только фамилия получателя" },
  { key: "userid", token: "{userid}", hint: "VK ID получателя" },
  { key: "screen_name", token: "{screen_name}", hint: "Короткое имя, если нет — VK ID" },
  { key: "sex", token: "{sex}", hint: "Обращение по полу: Дорогой / Дорогая" },
  { key: "group", token: "{group}", hint: "Название сообщества-отправителя" },
];

const KNOWN = new Set(PLACEHOLDERS.map((p) => p.key));
const RE = /\{([A-Za-z_][A-Za-z0-9_]*)\}/g;

export const SAMPLE_CONTEXT: TemplateContext = {
  firstName: "Иван",
  lastName: "Иванов",
  screenName: "ivan_ivanov",
  userId: 12345678,
  sex: 2,
  groupName: "Моё сообщество",
};

function greeting(sex?: number): string {
  if (sex === 2) return "Дорогой";
  if (sex === 1) return "Дорогая";
  return "Здравствуйте";
}

function valueFor(key: string, ctx: TemplateContext): string {
  const first = (ctx.firstName ?? "").trim();
  const last = (ctx.lastName ?? "").trim();
  const uid = ctx.userId === undefined || ctx.userId === null ? "" : String(ctx.userId);
  switch (key) {
    case "name":
      return [first, last].filter(Boolean).join(" ");
    case "first_name":
      return first;
    case "last_name":
      return last;
    case "userid":
      return uid;
    case "screen_name":
      return (ctx.screenName ?? "").trim() || uid;
    case "sex":
      return greeting(ctx.sex);
    case "group":
      return (ctx.groupName ?? "").trim();
    default:
      return "";
  }
}

/**
 * Безопасная подстановка плейсхолдеров. Отсутствующие значения → пустая строка,
 * неизвестные {переменные} остаются как есть. Никогда не бросает исключений.
 */
export function renderTemplate(text: string, ctx: TemplateContext): string {
  if (!text) return "";
  try {
    const safe = ctx ?? {};
    return text.replace(RE, (match, key: string) => (KNOWN.has(key) ? valueFor(key, safe) : match));
  } catch {
    return text;
  }
}

export interface TemplateSegment {
  type: "text" | "var" | "unknown";
  value: string;
}

/** Разбор для предпросмотра: подсветка подставленных и неизвестных переменных. */
export function segmentTemplate(text: string, ctx: TemplateContext): TemplateSegment[] {
  const out: TemplateSegment[] = [];
  if (!text) return out;
  let last = 0;
  const re = new RegExp(RE.source, "g");
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push({ type: "text", value: text.slice(last, m.index) });
    if (KNOWN.has(m[1])) {
      const v = valueFor(m[1], ctx ?? {});
      if (v) out.push({ type: "var", value: v });
    } else {
      out.push({ type: "unknown", value: m[0] });
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push({ type: "text", value: text.slice(last) });
  return out;
}

export function findUnknownPlaceholders(text: string): string[] {
  const res = new Set<string>();
  const re = new RegExp(RE.source, "g");
  let m: RegExpExecArray | null;
  while ((m = re.exec(text ?? ""))) if (!KNOWN.has(m[1])) res.add(m[0]);
  return [...res];
}
