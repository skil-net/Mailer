export const TOPICS = [
  "Бизнес",
  "Маркетинг",
  "Игры",
  "Образование",
  "Красота",
  "Технологии",
  "Юмор",
  "Музыка",
  "Спорт",
  "Другое",
] as const;

export type Topic = (typeof TOPICS)[number];
export type TopicFilter = "all" | Topic;

export const TOPIC_FILTER_OPTIONS: ReadonlyArray<{ value: TopicFilter; label: string }> = [
  { value: "all", label: "Все" },
  ...TOPICS.map((t) => ({ value: t as TopicFilter, label: t })),
];

export const TOPIC_OPTIONS: ReadonlyArray<{ value: Topic; label: string }> = TOPICS.map((t) => ({
  value: t,
  label: t,
}));

const TOPIC_COLORS: Record<Topic, string> = {
  Бизнес: "#2F6F8F",
  Маркетинг: "#C25E3A",
  Игры: "#6B54B8",
  Образование: "#3E8E5A",
  Красота: "#C0507A",
  Технологии: "#3558C8",
  Юмор: "#B8860B",
  Музыка: "#8A4FB0",
  Спорт: "#2C8C8C",
  Другое: "#7A6F63",
};

export const topicColor = (t: Topic): string => TOPIC_COLORS[t] ?? "#7A6F63";
