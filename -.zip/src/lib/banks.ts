export const DEFAULT_DEPOSIT_BANKS = ["ВТБ", "Сбербанк", "Т-Банк"];
export const ALL_BANKS = ["ВТБ", "Сбербанк", "Т-Банк", "Альфа", "Райффайзен", "Другой"];

const BANK_COLORS: Record<string, string> = {
  ВТБ: "#0A2896",
  Сбербанк: "#21A038",
  "Т-Банк": "#E3B100",
  Альфа: "#EF3124",
  Райффайзен: "#9C8700",
  Другой: "#7A6F63",
};

export const bankColor = (name?: string): string => (name && BANK_COLORS[name]) || "#7A6F63";

/** Случайный выбор банка для реквизитов пополнения */
export function pickRandomBank(banks: string[]): string {
  const list = banks.length ? banks : DEFAULT_DEPOSIT_BANKS;
  return list[Math.floor(Math.random() * list.length)];
}
