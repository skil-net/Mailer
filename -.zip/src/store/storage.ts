import type { PersistStorage } from "zustand/middleware";

/**
 * Единый ключ localStorage `rassylka-storage` со ПЛОСКОЙ схемой:
 * { auth, onboarded, balance, groups, subscribers, campaigns, outbox, transactions, promotions, settings }.
 * Несколько Zustand-сторов пишут в него свои поля; запись дебаунсится (300 мс) и
 * сбрасывается при сворачивании/закрытии вкладки.
 */
export const STORAGE_KEY = "rassylka-storage";

let blob: Record<string, unknown> | null = null;
let timer: ReturnType<typeof setTimeout> | undefined;

function read(): Record<string, unknown> {
  if (blob) return blob;
  try {
    blob = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") as Record<string, unknown>;
  } catch {
    blob = {};
  }
  return blob;
}

export function flushStorage(): void {
  if (timer) clearTimeout(timer);
  timer = undefined;
  if (!blob) return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(blob));
  } catch (e) {
    console.warn("rassylka-storage: не удалось сохранить", e);
  }
}

function schedule(): void {
  if (timer) clearTimeout(timer);
  timer = setTimeout(flushStorage, 300);
}

if (typeof window !== "undefined") {
  window.addEventListener("pagehide", flushStorage);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") flushStorage();
  });
}

export function createSharedStorage<T extends object>(keys: ReadonlyArray<keyof T & string>): PersistStorage<T> {
  return {
    getItem: () => {
      const data = read();
      const state: Record<string, unknown> = {};
      let found = false;
      for (const k of keys) {
        if (k in data) {
          state[k] = data[k];
          found = true;
        }
      }
      return found ? { state: state as T, version: 0 } : null;
    },
    setItem: (_name, value) => {
      const data = read();
      for (const k of keys) data[k] = (value.state as Record<string, unknown>)[k];
      schedule();
    },
    removeItem: () => {
      const data = read();
      for (const k of keys) delete data[k];
      schedule();
    },
  };
}

export function exportStorageJson(): string {
  flushStorage();
  return JSON.stringify(read(), null, 2);
}
