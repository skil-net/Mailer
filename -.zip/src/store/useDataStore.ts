import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  Campaign,
  ExcludeReason,
  Group,
  OutboxItem,
  PartnerRequest,
  PromoActivation,
  PromoCode,
  Promotion,
  Settings,
  Subscriber,
  Transaction,
} from "@/types";
import { createSharedStorage } from "./storage";
import { genId } from "@/lib/id";
import { DEFAULT_DEPOSIT_BANKS, ALL_BANKS, pickRandomBank } from "@/lib/banks";
import { normalizePromoCode, promoCodeValid, promoStatus } from "@/lib/promo";
import type { RawSubscriber } from "@/lib/vkApi";

export const DEFAULT_SETTINGS: Settings = {
  baseCampaignPriceRub: 10,
  serviceCommissionPercent: 10,
  depositPhone: "+79383478302",
  depositBanks: DEFAULT_DEPOSIT_BANKS,
  paymentTimerMinutes: 15,
  banks: ALL_BANKS,
};

const OUTBOX_LIMIT = 1500;
export const WITHDRAW_MIN_RUB = 500;
export const WITHDRAW_FEE_PERCENT = 1;

export function bestPromotion(promotions: Promotion[], amount: number): Promotion | null {
  let best: Promotion | null = null;
  for (const p of promotions) {
    if (!p.active || amount < p.minAmountRub) continue;
    if (!best || p.bonusPercent > best.bonusPercent) best = p;
  }
  return best;
}

export interface PromoCodeInput {
  id?: string;
  code: string;
  amountRub: number;
  maxActivations: number;
  expiresAt: number | null;
}

export interface RedeemResult {
  ok: boolean;
  error?: string;
  amountRub?: number;
}

interface DataState {
  balance: number;
  groups: Group[];
  subscribers: Subscriber[];
  campaigns: Campaign[];
  outbox: OutboxItem[];
  transactions: Transaction[];
  promotions: Promotion[];
  settings: Settings;
  partnerRequests: PartnerRequest[];
  promocodes: PromoCode[];
  promoActivations: PromoActivation[];

  addGroup: (g: Omit<Group, "id" | "createdAt">) => Group;
  updateGroup: (id: string, patch: Partial<Group>) => void;
  removeGroup: (id: string) => void;
  setSubscribers: (vkGroupId: number, raw: RawSubscriber[]) => void;
  /** Сохраняет собранную базу и отмечает время обновления группы */
  applyCollectedBase: (vkGroupId: number, raw: RawSubscriber[]) => void;
  setSubscriberConsent: (id: string, consent: boolean) => void;
  /** Исключает получателя из базы (запретил сообщения, заблокирован и т.п.) */
  excludeSubscriber: (groupId: number, vkUserId: number, reason: ExcludeReason) => void;

  addCampaign: (c: Omit<Campaign, "id" | "createdAt">) => Campaign;
  patchCampaign: (id: string, patch: Partial<Campaign>) => void;
  removeCampaign: (id: string) => void;
  pushOutbox: (items: OutboxItem[]) => void;

  spend: (amountRub: number, title: string) => boolean;
  refund: (amountRub: number, title: string) => void;
  createDeposit: (amountRub: number) => Transaction;
  markPaid: (id: string) => boolean;
  expireTransaction: (id: string) => void;
  expireStale: () => void;
  confirmDeposit: (id: string, operationId: string) => boolean;
  rejectTransaction: (id: string, comment: string) => void;
  createWithdraw: (p: { amountRub: number; phone: string; bankName: string }) => { ok: boolean; error?: string };
  completeWithdraw: (id: string) => void;

  upsertPromotion: (p: Omit<Promotion, "id" | "createdAt"> & { id?: string }) => void;
  removePromotion: (id: string) => void;

  /** Создаёт или обновляет промокод. false — невалидный код или такой уже есть */
  upsertPromoCode: (p: PromoCodeInput) => boolean;
  removePromoCode: (id: string) => void;
  setPromoCodeActive: (id: string, active: boolean) => void;
  /** Активирует промокод и зачисляет сумму на баланс */
  redeemPromoCode: (code: string, vkUserId: number) => RedeemResult;

  updateSettings: (patch: Partial<Settings>) => void;
  submitPartnerRequest: (r: Omit<PartnerRequest, "id" | "createdAt" | "status">) => void;
  resolvePartnerRequest: (id: string, approve: boolean) => void;
  setGroupBlocked: (id: string, blocked: boolean) => void;
}

const PERSIST_KEYS = [
  "balance",
  "groups",
  "subscribers",
  "campaigns",
  "outbox",
  "transactions",
  "promotions",
  "settings",
  "partnerRequests",
  "promocodes",
  "promoActivations",
] as const;

type Persisted = Pick<DataState, (typeof PERSIST_KEYS)[number]>;

export const useDataStore = create<DataState>()(
  persist(
    (set, get) => ({
      balance: 0,
      groups: [],
      subscribers: [],
      campaigns: [],
      outbox: [],
      transactions: [],
      promotions: [],
      settings: DEFAULT_SETTINGS,
      partnerRequests: [],
      promocodes: [],
      promoActivations: [],

      /* ── группы ── */
      addGroup: (g) => {
        const existing = get().groups.find((x) => x.vkGroupId === g.vkGroupId);
        if (existing) {
          const merged = { ...existing, ...g, id: existing.id, createdAt: existing.createdAt };
          set((s) => ({ groups: s.groups.map((x) => (x.id === existing.id ? merged : x)) }));
          return merged;
        }
        const group: Group = { ...g, id: genId("grp"), createdAt: Date.now() };
        set((s) => ({ groups: [group, ...s.groups] }));
        return group;
      },
      updateGroup: (id, patch) => set((s) => ({ groups: s.groups.map((g) => (g.id === id ? { ...g, ...patch } : g)) })),
      removeGroup: (id) =>
        set((s) => {
          const g = s.groups.find((x) => x.id === id);
          return {
            groups: s.groups.filter((x) => x.id !== id),
            subscribers: g ? s.subscribers.filter((x) => x.groupId !== g.vkGroupId) : s.subscribers,
          };
        }),

      /* ── подписчики ── */
      setSubscribers: (vkGroupId, raw) =>
        set((s) => {
          const prev = new Map<number, Subscriber>();
          for (const x of s.subscribers) if (x.groupId === vkGroupId) prev.set(x.vkUserId, x);
          const seen = new Set<number>();
          const next: Subscriber[] = [];
          const now = Date.now();
          for (const r of raw) {
            if (seen.has(r.vkUserId)) continue; // дедупликация
            seen.add(r.vkUserId);
            const old = prev.get(r.vkUserId);
            const excluded = r.excluded ?? null;
            next.push({
              id: old?.id ?? genId("sub", 6),
              groupId: vkGroupId,
              vkUserId: r.vkUserId,
              firstName: r.firstName,
              lastName: r.lastName,
              screenName: r.screenName,
              sex: r.sex,
              photo100: r.photo100,
              lastMessageAt: r.lastMessageAt,
              consent: old?.consent ?? true,
              excluded,
              excludedAt: excluded ? old?.excludedAt ?? now : undefined,
            });
          }
          return { subscribers: [...s.subscribers.filter((x) => x.groupId !== vkGroupId), ...next] };
        }),
      applyCollectedBase: (vkGroupId, raw) => {
        get().setSubscribers(vkGroupId, raw);
        const g = get().groups.find((x) => x.vkGroupId === vkGroupId);
        if (g) get().updateGroup(g.id, { baseUpdatedAt: Date.now() });
      },
      setSubscriberConsent: (id, consent) =>
        set((s) => ({ subscribers: s.subscribers.map((x) => (x.id === id ? { ...x, consent } : x)) })),
      excludeSubscriber: (groupId, vkUserId, reason) =>
        set((s) => {
          let changed = false;
          const subscribers = s.subscribers.map((x) => {
            if (x.groupId !== groupId || x.vkUserId !== vkUserId || x.excluded === reason) return x;
            changed = true;
            return { ...x, excluded: reason, excludedAt: Date.now() };
          });
          return changed ? { subscribers } : s;
        }),

      /* ── кампании ── */
      addCampaign: (c) => {
        const campaign: Campaign = { ...c, id: genId("cmp"), createdAt: Date.now() };
        set((s) => ({ campaigns: [campaign, ...s.campaigns] }));
        return campaign;
      },
      patchCampaign: (id, patch) =>
        set((s) => ({ campaigns: s.campaigns.map((c) => (c.id === id ? { ...c, ...patch } : c)) })),
      removeCampaign: (id) =>
        set((s) => ({
          campaigns: s.campaigns.filter((c) => c.id !== id),
          outbox: s.outbox.filter((o) => o.campaignId !== id),
        })),
      pushOutbox: (items) =>
        set((s) => {
          if (!items.length) return s;
          const merged = [...s.outbox, ...items];
          return { outbox: merged.length > OUTBOX_LIMIT ? merged.slice(merged.length - OUTBOX_LIMIT) : merged };
        }),

      /* ── деньги ── */
      spend: (amountRub, title) => {
        if (amountRub <= 0) return true;
        if (get().balance < amountRub) return false;
        const tx: Transaction = {
          id: genId("txn"),
          type: "spend",
          amountRub,
          feeRub: 0,
          status: "confirmed",
          title,
          createdAt: Date.now(),
          processedAt: Date.now(),
        };
        set((s) => ({ balance: s.balance - amountRub, transactions: [tx, ...s.transactions] }));
        return true;
      },
      refund: (amountRub, title) => {
        if (amountRub <= 0) return;
        const tx: Transaction = {
          id: genId("txn"),
          type: "refund",
          amountRub,
          feeRub: 0,
          status: "confirmed",
          title,
          createdAt: Date.now(),
          processedAt: Date.now(),
        };
        set((s) => ({ balance: s.balance + amountRub, transactions: [tx, ...s.transactions] }));
      },
      createDeposit: (amountRub) => {
        const { settings, promotions } = get();
        const promo = bestPromotion(promotions, amountRub);
        const now = Date.now();
        const tx: Transaction = {
          id: genId("txn"),
          type: "deposit",
          amountRub,
          feeRub: 0,
          status: "pending",
          title: "Пополнение баланса",
          bankName: pickRandomBank(settings.depositBanks),
          phone: settings.depositPhone,
          bonusPercent: promo?.bonusPercent ?? 0,
          timerExpiresAt: now + settings.paymentTimerMinutes * 60_000,
          createdAt: now,
        };
        set((s) => ({ transactions: [tx, ...s.transactions] }));
        return tx;
      },
      markPaid: (id) => {
        const tx = get().transactions.find((t) => t.id === id);
        if (!tx || tx.status !== "pending" || (tx.timerExpiresAt ?? 0) <= Date.now()) return false;
        set((s) => ({
          transactions: s.transactions.map((t) => (t.id === id ? { ...t, status: "awaiting_confirmation" } : t)),
        }));
        return true;
      },
      expireTransaction: (id) =>
        set((s) => ({
          transactions: s.transactions.map((t) =>
            t.id === id && t.status === "pending" ? { ...t, status: "expired", processedAt: Date.now() } : t
          ),
        })),
      expireStale: () => {
        const now = Date.now();
        const stale = get().transactions.some(
          (t) => t.type === "deposit" && t.status === "pending" && (t.timerExpiresAt ?? Infinity) <= now
        );
        if (!stale) return;
        set((s) => ({
          transactions: s.transactions.map((t) =>
            t.type === "deposit" && t.status === "pending" && (t.timerExpiresAt ?? Infinity) <= now
              ? { ...t, status: "expired", processedAt: now }
              : t
          ),
        }));
      },
      confirmDeposit: (id, operationId) => {
        const op = operationId.trim();
        const tx = get().transactions.find((t) => t.id === id);
        if (!op || !tx || tx.type !== "deposit") return false;
        if (tx.status !== "awaiting_confirmation" && tx.status !== "pending") return false;
        const bonusRub = Math.floor((tx.amountRub * (tx.bonusPercent ?? 0)) / 100);
        set((s) => ({
          balance: s.balance + tx.amountRub + bonusRub,
          transactions: s.transactions.map((t) =>
            t.id === id ? { ...t, status: "confirmed", operationId: op, bonusRub, processedAt: Date.now() } : t
          ),
        }));
        return true;
      },
      rejectTransaction: (id, comment) =>
        set((s) => {
          const tx = s.transactions.find((t) => t.id === id);
          if (!tx) return s;
          const refundHold = tx.type === "withdraw" && tx.status === "pending" ? tx.amountRub : 0;
          return {
            balance: s.balance + refundHold,
            transactions: s.transactions.map((t) =>
              t.id === id ? { ...t, status: "rejected", adminComment: comment.trim(), processedAt: Date.now() } : t
            ),
          };
        }),
      createWithdraw: ({ amountRub, phone, bankName }) => {
        if (amountRub < WITHDRAW_MIN_RUB) return { ok: false, error: `Минимальная сумма вывода — ${WITHDRAW_MIN_RUB} ₽` };
        if (amountRub > get().balance) return { ok: false, error: "Недостаточно средств на балансе" };
        const tx: Transaction = {
          id: genId("txn"),
          type: "withdraw",
          amountRub,
          feeRub: Math.ceil((amountRub * WITHDRAW_FEE_PERCENT) / 100),
          status: "pending",
          title: "Вывод средств (СБП)",
          bankName,
          phone,
          createdAt: Date.now(),
        };
        set((s) => ({ balance: s.balance - amountRub, transactions: [tx, ...s.transactions] }));
        return { ok: true };
      },
      completeWithdraw: (id) =>
        set((s) => ({
          transactions: s.transactions.map((t) =>
            t.id === id && t.type === "withdraw" ? { ...t, status: "confirmed", processedAt: Date.now() } : t
          ),
        })),

      /* ── админка: акции ── */
      upsertPromotion: (p) =>
        set((s) => {
          if (p.id && s.promotions.some((x) => x.id === p.id)) {
            return { promotions: s.promotions.map((x) => (x.id === p.id ? { ...x, ...p, id: x.id } : x)) };
          }
          const promo: Promotion = {
            id: genId("prm"),
            title: p.title,
            bonusPercent: p.bonusPercent,
            minAmountRub: p.minAmountRub,
            active: p.active,
            createdAt: Date.now(),
          };
          return { promotions: [promo, ...s.promotions] };
        }),
      removePromotion: (id) => set((s) => ({ promotions: s.promotions.filter((p) => p.id !== id) })),

      /* ── админка: промокоды ── */
      upsertPromoCode: (p) => {
        const code = normalizePromoCode(p.code);
        const st = get();
        if (!promoCodeValid(code)) return false;
        if (st.promocodes.some((c) => c.code === code && c.id !== p.id)) return false;
        if (p.id && st.promocodes.some((c) => c.id === p.id)) {
          set((s) => ({
            promocodes: s.promocodes.map((c) =>
              c.id === p.id ? { ...c, code, amountRub: p.amountRub, maxActivations: p.maxActivations, expiresAt: p.expiresAt } : c
            ),
          }));
          return true;
        }
        const item: PromoCode = {
          id: genId("pmt"),
          code,
          amountRub: p.amountRub,
          maxActivations: p.maxActivations,
          activatedCount: 0,
          expiresAt: p.expiresAt,
          active: true,
          createdAt: Date.now(),
        };
        set((s) => ({ promocodes: [item, ...s.promocodes] }));
        return true;
      },
      removePromoCode: (id) => set((s) => ({ promocodes: s.promocodes.filter((c) => c.id !== id) })),
      setPromoCodeActive: (id, active) =>
        set((s) => ({ promocodes: s.promocodes.map((c) => (c.id === id ? { ...c, active } : c)) })),
      redeemPromoCode: (input, vkUserId) => {
        const code = normalizePromoCode(input);
        if (!code) return { ok: false, error: "Введите промокод" };
        const st = get();
        const c = st.promocodes.find((x) => x.code === code);
        if (!c) return { ok: false, error: "Промокод не найден" };
        const status = promoStatus(c);
        if (status.key === "disabled") return { ok: false, error: "Промокод отключён" };
        if (status.key === "expired") return { ok: false, error: "Срок действия промокода истёк" };
        if (st.promoActivations.some((a) => a.promoId === c.id && a.vkUserId === vkUserId))
          return { ok: false, error: "Вы уже активировали этот промокод" };
        if (status.key === "exhausted") return { ok: false, error: "Лимит активаций промокода исчерпан" };
        const now = Date.now();
        const activation: PromoActivation = { id: genId("act"), promoId: c.id, code: c.code, amountRub: c.amountRub, vkUserId, createdAt: now };
        const tx: Transaction = {
          id: genId("txn"),
          type: "promo",
          amountRub: c.amountRub,
          feeRub: 0,
          status: "confirmed",
          title: `Промокод ${c.code}`,
          createdAt: now,
          processedAt: now,
        };
        set((s) => ({
          balance: s.balance + c.amountRub,
          promocodes: s.promocodes.map((x) => (x.id === c.id ? { ...x, activatedCount: x.activatedCount + 1 } : x)),
          promoActivations: [activation, ...s.promoActivations],
          transactions: [tx, ...s.transactions],
        }));
        return { ok: true, amountRub: c.amountRub };
      },

      /* ── админка: прочее ── */
      updateSettings: (patch) => set((s) => ({ settings: { ...s.settings, ...patch } })),
      submitPartnerRequest: (r) =>
        set((s) => ({
          partnerRequests: [
            { ...r, id: genId("req"), status: "pending", createdAt: Date.now() },
            ...s.partnerRequests,
          ],
        })),
      resolvePartnerRequest: (id, approve) =>
        set((s) => {
          const req = s.partnerRequests.find((r) => r.id === id);
          if (!req) return s;
          return {
            partnerRequests: s.partnerRequests.map((r) =>
              r.id === id ? { ...r, status: approve ? "approved" : "rejected" } : r
            ),
            groups: approve
              ? s.groups.map((g) =>
                  g.id === req.groupId
                    ? {
                        ...g,
                        isPartner: true,
                        partnerPriceRub: req.priceRub,
                        partnerDiscount: req.discount,
                        partnerDescription: req.description,
                        topic: req.topic,
                      }
                    : g
                )
              : s.groups,
          };
        }),
      setGroupBlocked: (id, blocked) =>
        set((s) => ({ groups: s.groups.map((g) => (g.id === id ? { ...g, blocked } : g)) })),
    }),
    {
      name: "data",
      storage: createSharedStorage<Persisted>(PERSIST_KEYS),
      partialize: (s): Persisted => ({
        balance: s.balance,
        groups: s.groups,
        subscribers: s.subscribers,
        campaigns: s.campaigns,
        outbox: s.outbox,
        transactions: s.transactions,
        promotions: s.promotions,
        settings: s.settings,
        partnerRequests: s.partnerRequests,
        promocodes: s.promocodes,
        promoActivations: s.promoActivations,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<Persisted>;
        // данные, сохранённые до появления исключений, считаем актуальными
        const subscribers = (p.subscribers ?? []).map((s) => ({ ...s, excluded: s.excluded ?? null }));
        return { ...current, ...p, subscribers, settings: { ...DEFAULT_SETTINGS, ...(p.settings ?? {}) } };
      },
    }
  )
);

export const selectActiveGroups = (s: DataState) => s.groups;
