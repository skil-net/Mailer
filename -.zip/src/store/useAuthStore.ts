import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AuthState, Profile } from "@/types";
import { createSharedStorage } from "./storage";
import { fetchAdminProfile, invalidateProfileCache, readCachedProfile, VK_ADMIN_ID } from "@/lib/vkApi";
import { useUiStore } from "./useUiStore";

export const FALLBACK_PROFILE: Profile = {
  firstName: "Самад",
  lastName: "Лукманов",
  photo200: null,
  screenName: "samadluk",
  monogram: "СЛ",
};

interface AuthStore {
  auth: AuthState;
  onboarded: boolean;
  loading: boolean;
  completeOnboarding: () => void;
  login: () => Promise<void>;
  refreshProfile: () => Promise<void>;
  silentRefresh: () => Promise<void>;
  logout: () => void;
}

type Persisted = Pick<AuthStore, "auth" | "onboarded">;

const initialAuth: AuthState = {
  isAuthenticated: false,
  vkId: VK_ADMIN_ID,
  role: "admin",
  profileSource: null,
  profile: null,
};

export const useAuthStore = create<AuthStore>()(
  persist(
    (set, get) => {
      const apply = (profile: Profile, source: "vk" | "local") =>
        set((s) => ({
          auth: { ...s.auth, isAuthenticated: true, vkId: VK_ADMIN_ID, role: "admin", profileSource: source, profile },
        }));

      const load = async (force: boolean) => {
        set({ loading: true });
        try {
          const p = await fetchAdminProfile(force);
          apply(p, "vk");
          return true;
        } catch {
          // Любая ошибка (нет токена, сеть, VK API, не-2xx, таймаут 5с) → локальный профиль, вход не блокируется
          apply(FALLBACK_PROFILE, "local");
          return false;
        } finally {
          set({ loading: false });
        }
      };

      return {
        auth: initialAuth,
        onboarded: false,
        loading: false,
        completeOnboarding: () => set({ onboarded: true }),
        login: async () => {
          await load(false);
        },
        refreshProfile: async () => {
          invalidateProfileCache();
          const ok = await load(true);
          useUiStore
            .getState()
            .toast(ok ? "Профиль обновлён из ВКонтакте" : "Не удалось связаться с VK — используется локальный профиль", ok ? "success" : "info");
        },
        silentRefresh: async () => {
          const st = get();
          if (!st.auth.isAuthenticated || readCachedProfile()) return;
          try {
            const p = await fetchAdminProfile(true);
            apply(p, "vk");
          } catch {
            /* оставляем текущий профиль */
          }
        },
        logout: () => set({ auth: { ...initialAuth } }),
      };
    },
    {
      name: "auth",
      storage: createSharedStorage<Persisted>(["auth", "onboarded"]),
      partialize: (s): Persisted => ({ auth: s.auth, onboarded: s.onboarded }),
    }
  )
);
