import { create } from "zustand";

export type SheetDescriptor =
  | { type: "wizard"; groupIds?: number[]; partnerGroupId?: number; duplicateFrom?: string }
  | { type: "deposit" }
  | { type: "withdraw" }
  | { type: "createGroup" }
  | { type: "promo" }
  | { type: "editPartner"; mode: "edit" | "apply"; groupId?: string };

export type SheetEntry = SheetDescriptor & { key: number };
export type ToastKind = "info" | "success" | "error";
export interface Toast {
  id: number;
  message: string;
  kind: ToastKind;
}

interface UiState {
  sheets: SheetEntry[];
  toasts: Toast[];
  openSheet: (s: SheetDescriptor) => void;
  closeSheet: (key: number) => void;
  toast: (message: string, kind?: ToastKind) => void;
}

let seq = 1;

export const useUiStore = create<UiState>()((set) => ({
  sheets: [],
  toasts: [],
  openSheet: (s) => set((st) => ({ sheets: [...st.sheets, { ...s, key: seq++ }] })),
  closeSheet: (key) => set((st) => ({ sheets: st.sheets.filter((x) => x.key !== key) })),
  toast: (message, kind = "info") => {
    const id = seq++;
    set((st) => ({ toasts: [...st.toasts.slice(-2), { id, message, kind }] }));
    setTimeout(() => set((st) => ({ toasts: st.toasts.filter((t) => t.id !== id) })), 3200);
  },
}));
